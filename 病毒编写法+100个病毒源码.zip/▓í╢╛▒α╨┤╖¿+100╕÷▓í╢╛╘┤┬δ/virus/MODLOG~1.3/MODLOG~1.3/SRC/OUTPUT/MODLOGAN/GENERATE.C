/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: generate.c,v 1.18 2001/01/11 22:30:17 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>


#include "mconfig.h"
#include "mstate.h"
#include "mlocale.h"
#include "mhash.h"
#include "mlist.h"
#include "mdatatypes.h"
#include "mplugins.h"

#include "pictures.h"
#include "plugin_config.h"

#define HIGHLIGHT	1
#define GROUPING	2
#define VISITS		4
#define INDEX		8
#define BROKEN_LINK	16
#define PERCENT		32

/* tla -> Three Letter Abbreviation */
char *get_month_string(int m, int tla) {
	static char monthname[255];
	
	struct tm *tm;
	time_t t = time(NULL);
	
	tm = localtime(&t);
	
	tm->tm_mon = m > 0 ? m - 1 : 11;
	
	strftime(monthname, sizeof(monthname)-1, tla ? "%b" : "%B", tm);
	return monthname;
}

char *htmlencode(const char *s) {
	char *p;
	char *q = NULL;
	int q_len = 0;
	if (!s) return NULL;
	
	q_len = strlen(s) * 2 + 1;
	q = malloc(q_len);

	p = q;
	*p = '\0';
	
	while (*s) {
		switch(*s) {
			case '<':
				*p = '&';
				*(++p) = 'l';
				*(++p) = 't';
				*(++p) = ';';
				break;
			case '>':
				*p = '&';
				*(++p) = 'g';
				*(++p) = 't';
				*(++p) = ';';
				break;
			default:
				*p = *s;
				break;
		}
		*(++p) = '\0';
		s++;
		
		if (strlen(q) > (q_len - 4)) {
			q_len += 128;
			q = realloc(q, q_len);
			
			p = q + strlen(q);
		}
	}
	
	return q;
}


int mhash_get_value(mhash *h[], const char *key) {
	int c = 0, i;
	if (!h) return 0;
	
	for ( i = 0; i < HASH_SIZE; i++) {
		mlist *l = h[i]->list;
		while (l) {
			if (l->data) {
				data_StrInt *data = (data_StrInt *)l->data;
				
				if (!strcmp(key, data->string)) {
					c = data->count;
					break;
				}
			}
			l = l->next;
		}
		if (c != 0) break;
	}
	
	return c;
}

long mlist_sumup(mlist *l) {
	int c = 0;
	if (!l) return 0;
	
	while (l) {
		if (l->data) c += ((data_StrInt*)l->data)->count;
		l = l->next;
	}
	
	return c;
}

long mhash_sumup(mhash *h[]) {
	int i, c = 0;
	if (!h) return 0;
	
	for ( i = 0; i < HASH_SIZE; i++) {
		c += mlist_sumup(h[i]->list);
	}
	
	return c;
}

int show_mhash (mconfig *ext_conf, FILE *f, mhash *h[], int count, int opt) {
	mlist *l, *first;
	int i = 0;
	config_output *conf = ext_conf->output;
	long sum = 0;
	
	if (!h) return 0;
	
	first = l = mlist_init();
	
	sum = mhash_sumup(h);
	
	mhash_unfold_sorted_limited(h, l, count);
	
	while (l && (i++ < count)) {
		data_StrInt *data = (data_StrInt *)l->data;
		
		if (data) {
			char *enc_url = NULL;
			int cut_url = 0;
			
			if (!conf->dont_escape_entities) {
				enc_url = htmlencode(data->string);
			} else {	
				enc_url = malloc(strlen(data->string)+1);
				strcpy(enc_url, data->string);
			}
			
			cut_url = (strlen(enc_url) > 40) && !conf->dont_cut_urls;
			
			if (cut_url) {
				enc_url[40] = '\0';
			}
			
			fprintf(f,"<TR>");
			
			if (opt & INDEX) {
				fprintf(f,"<TD width=\"5%%\" align=right>%d</TD>", i);
			}
			
			fprintf(f,"<TD width=\"15%%\" align=right>%d</TD>", data->count);
			
			if (opt & PERCENT && sum) {
				fprintf(f,"<TD width=\"5%%\" align=right>%.2f</TD>", data->count * 100.0 / sum);
			}
			
			if (opt & VISITS) {
				data_Str3Int *_data = (data_Str3Int *)l->data;
				fprintf(f,"<TD width=\"15%%\" align=right>%d</TD>", _data->vcount);
			}
			if ((opt & GROUPING) && data->type == M_GROUP) {
				fprintf(f,"<TD class=\"grouping\">%s%s</TD>", enc_url, cut_url ? "..." : "");
			} else {
				if (opt & HIGHLIGHT) {
					if (conf->assumedprotocol == NULL || strstr(data->string, "://")) {
						fprintf(f,"<TD><a href=\"%s\">%s</a>%s</TD>", data->string, enc_url, cut_url ? "..." : "");
					} else {
						fprintf(f,"<TD><a href=\"%s://%s%s%s\">%s</a>%s</TD>", conf->assumedprotocol, conf->hostname, *data->string == '/' ? "" : "/", data->string, enc_url, cut_url ? "..." : "");
					}
				} else {
					fprintf(f,"<TD>%s%s</TD>", enc_url, cut_url ? "..." : "");
				}
			}
			if (opt & BROKEN_LINK) {
				data_BrokenLink *_data = l->data;
				struct tm *_tm;
				char timebuf[32] = "";
				
				if (strcmp(_data->referrer, "-")) {
					free(enc_url);
					enc_url = htmlencode(_data->referrer);
					cut_url = strlen(enc_url) > 40;
			
					if (cut_url) {
						enc_url[40] = '\0';
					}
					fprintf(f,"<TD><a href=\"%s\">%s</a>%s</TD>", _data->referrer, enc_url, cut_url ? "..." : "");
				} else {
					fprintf(f,"<TD>%s</TD>", _data->referrer);
				}
				
				_tm = localtime(&(_data->timestamp));
				if (strftime(timebuf, sizeof(timebuf)-1, "%x", _tm) == 0) {
					fprintf(stderr, "output::modlogan.show_mhash: strftime failed\n");
				}
				fprintf(f,"<TD>%s</TD>", timebuf);
			}
			fprintf(f,"</TR>\n");
			
			free(enc_url);
		}
		
		l = l->next;
	}
	
	mlist_free(first);

	return 0;
}

int mhash_status_unfold_sorted_limited(mhash *h[], mlist *l, int count ) {
	int i, j;
	data_StrInt *data, *ins_data;
	char __dummy__[] = "999";
	char __dummy_2_[] = "";
	char *max, *last = __dummy_2_;
	
	for ( j = 0; j < count; j++) {
		data = NULL;
		
		max = __dummy__;
		
		for ( i = 0; i < HASH_SIZE; i++) {
			if (h[i]->list) {
				mlist *hl;
			
				hl = h[i]->list;
				while (hl) {
					if (hl->data) {
						if ( strcmp(((data_StrInt *)hl->data)->string, max) < 0 &&
							strcmp(((data_StrInt *)hl->data)->string, last) > 0) {
							max = ((data_StrInt *)hl->data)->string;
							data = (data_StrInt *)hl->data;
						}
					}
					hl = hl->next;
				}
			}
		}
		
		if (data) {
			ins_data = createStrInt(data->string, data->count);
			
			mlist_insert(l, ins_data);
			
			last = data->string;
		}
	}
	
	return 0;
}

int show_status_mhash (FILE *f, mhash *h[], int count) {
	mlist *l, *first;
	int i = 0;
	
	if (!h) return 0;
	
	first = l = mlist_init();
	
	mhash_status_unfold_sorted_limited(h, l, count);
	
	while (l && (i++ < count)) {
		data_StrInt *data = (data_StrInt *)l->data;
		
		if (data)
			fprintf(f,"<TR><TD width=\"15%%\" align=right>%d</TD><TD>%s - %s</TD></TR>\n", data->count, data->string, mhttpcodes(strtol(data->string, NULL, 10)));
		
		l = l->next;
	}
	
	mlist_free(first);

	return 0;
}

void table_start(FILE *f, char *str, int colspan) {
	fprintf(f,"<P><CENTER><TABLE BORDER=1 WIDTH=\"%s\" BGCOLOR=\"#eeeeee\"><TR><TH colspan=%d>%s</TH></TR>\n", colspan < 0 ? "100%": "400", colspan < 0 ? -colspan : colspan, str);
}

void table_end(FILE *f) {
	fprintf(f,"</TABLE></CENTER><P>");
}

void file_start(FILE *f, mconfig *ext_conf, time_t timestamp) {
	char buf[255];
	struct tm *_tm;
	time_t t;
	config_output *conf = ext_conf->output;
	int show_default = 1;
	
	if (conf->html_header) {
		FILE *inf = fopen (conf->html_header, "r");
		
		if (inf == NULL) {
			fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't open page header"),strerror(errno));
		} else {
			char buf[255];
			
			while (fgets(buf, sizeof(buf)-1, inf)) {
				if (fputs(buf, f) == EOF) {
					fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't write header"),strerror(errno));
					break;
				}
			}
			
			show_default = 0;
			fclose(inf);
		}
	} 
	
	if (show_default) {
		fprintf(f, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n\n");
		fprintf(f, "<HTML><HEAD><TITLE>%s</TITLE>", _("Statistics"));
		fprintf(f, "<LINK REL=STYLESHEET HREF=\"modlogan.css\" type=\"text/css\">");
		fprintf(f, "<META http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">", conf->cont_charset);
		fprintf(f, "<META http-equiv=\"Content-Language\" content=\"%s\">", conf->cont_language);
		fprintf(f, "</HEAD>\n");
		fprintf(f, "<BODY bgcolor=\"%s\">\n", conf->col_body);
	
		fprintf(f, "<H1>%s %s</H1>\n", _("Statistics for"), conf->hostname);
		if (timestamp != 0) {
			t = timestamp;
			_tm = localtime(&t);
			strftime(buf, sizeof(buf), "%X %x", _tm);
			fprintf(f, "<b>%s: </b>%s<br>\n", _("Last record"), buf);
		}
		t = time(NULL);
		_tm = localtime(&t);
		strftime(buf, sizeof(buf), "%X %x", _tm);
		fprintf(f, "<b>%s: </b>%s<br>\n", _("Generated at"), buf);
		fprintf(f, "<HR><br>\n");
	}
	
	fprintf(f, "<TABLE class=\"menu\" width=\"100%%\"><TR valign=top><TD>\n");
}

void file_end(FILE *f, mconfig *ext_conf) {
	config_output *conf = ext_conf->output;
	int show_default = 1;
	
	fprintf(f, "</TD></TR></TABLE>\n");
	
	if (conf->html_footer) {
		FILE *inf = fopen (conf->html_footer, "r");
		
		if (inf == NULL) {
			fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't open page footer"),strerror(errno));
		} else {
			char buf[255];
			
			while (fgets(buf, sizeof(buf)-1, inf)) {
				if (fputs(buf, f) == EOF) {
					fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't write footer"),strerror(errno));
					break;
				}
			}
			
			show_default = 0;
			fclose(inf);
		}
	}
	
	if (show_default) {

		fprintf(f, "<HR>");
		
		if (conf->show_validation_links) {
/* Tell the users that this is valid HTML 4.0  :) */
			fprintf(f, "<a href=\"http://validator.w3.org/check/referer\"><img border=0 "\
				"src=\"http://validator.w3.org/images/vh40\" "\
				"alt=\"Valid HTML 4.0!\" height=31 width=88 align=\"right\"></a>");
/* Tell the users that this is even valid CSS  :) */
			fprintf(f, "<A HREF=\"http://jigsaw.w3.org/css-validator/check/referer/\"><IMG border=0 width=\"88\" height=\"31\"");
			fprintf(f, "SRC=\"http://jigsaw.w3.org/css-validator/images/vcss.gif\" ALT=\"Valid CSS!\" align=\"right\"></A>");
		}
		
		fprintf(f, "%s <a href=\"%s\">%s %s</a>\n", _("Output generated by"),"http://www.kneschke.de/projekte/modlogan/", PACKAGE, VERSION);
		fprintf(f, "</BODY></HTML>\n");
	}
}

void file_start_index(FILE *f, mconfig *ext_conf, time_t timestamp) {
	char buf[255];
	struct tm *_tm;
	time_t t;
	config_output *conf = ext_conf->output;
	
	int show_default = 1;
	
	if (conf->html_header) {
		FILE *inf = fopen (conf->html_header, "r");
		
		if (inf == NULL) {
			fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't open page header"),strerror(errno));
		} else {
			char buf[255];
			
			while (fgets(buf, sizeof(buf)-1, inf)) {
				if (fputs(buf, f) == EOF) {
					fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't write header"),strerror(errno));
					break;
				}
			}
			
			show_default = 0;
			fclose(inf);
		}
	} 
	
	if (show_default) {
		fprintf(f, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n\n");
		fprintf(f, "<HTML><HEAD><TITLE>Statistics</TITLE>");
		fprintf(f, "<LINK REL=STYLESHEET HREF=\"modlogan.css\" type=\"text/css\">");
		fprintf(f, "<META http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">", conf->cont_charset);
		fprintf(f, "<META http-equiv=\"Content-Language\" content=\"%s\">", conf->cont_language);
		fprintf(f, "</HEAD>\n");
		fprintf(f, "<BODY bgcolor=\"%s\">\n", conf->col_body);
	
		fprintf(f, "<H1>%s %s</H1>\n", _("Statistics for"), conf->hostname);
		if (timestamp != 0) {
			t = timestamp;
			_tm = localtime(&t);
			strftime(buf, sizeof(buf), "%X %x", _tm);
			fprintf(f, "<b>%s: </b>%s<br>\n", _("Last record"), buf);
		}
		t = time(NULL);
		_tm = localtime(&t);
		strftime(buf, sizeof(buf), "%X %x", _tm);
		fprintf(f, "<b>%s: </b>%s<br>\n", _("Generated at"), buf);
		fprintf(f, "<HR><br>\n");
	}
}

void file_end_index(FILE *f, mconfig *ext_conf) {
	config_output *conf = ext_conf->output;
	int show_default = 1;
	
	if (conf->html_footer) {
		FILE *inf = fopen (conf->html_footer, "r");
		
		if (inf == NULL) {
			fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't open page footer"),strerror(errno));
		} else {
			char buf[255];
			
			while (fgets(buf, sizeof(buf)-1, inf)) {
				if (fputs(buf, f) == EOF) {
					fprintf(stderr, "%s.%d: %s: %s", __FILE__, __LINE__, _("Can't write footer"),strerror(errno));
					break;
				}
			}
			
			show_default = 0;
			fclose(inf);
		}
	}
	
	if (show_default) {
/* Tell the users that this is valid HTML 4.0  :) */
		fprintf(f, "<HR>");
		if (conf->show_validation_links) {
			fprintf(f, "<a href=\"http://validator.w3.org/check/referer\"><img border=0 "\
				"src=\"http://validator.w3.org/images/vh40\" "\
				"alt=\"Valid HTML 4.0!\" height=31 width=88 align=\"right\"></a>");
/* Tell the users that this is even valid CSS  :) */
			fprintf(f, "<A HREF=\"http://jigsaw.w3.org/css-validator/check/referer/\"><IMG border=0 width=\"88\" height=\"31\"");
			fprintf(f, "SRC=\"http://jigsaw.w3.org/css-validator/images/vcss.gif\" ALT=\"Valid CSS!\" align=\"right\"></A>");
		}
		fprintf(f, "%s <a href=\"%s\">%s %s</a>\n", _("Output generated by"),"http://www.kneschke.de/projekte/modlogan/", PACKAGE, VERSION);
		fprintf(f, "</BODY></HTML>\n");
	}
}

char *table_header(int maxcount, int count, char *str) {
	static char trans_buf[255];
	
	sprintf(trans_buf, "%d %s %d %s", (maxcount > count) || (maxcount < 0) ? count : maxcount, _("of"), count, str);
	
	return trans_buf;
	
}

#define	M_TYPE_REPORT	1
#define M_TYPE_PAGE	2

#define M_REPORT_REQ_URL	1
#define M_REPORT_REF_URL	2
#define M_REPORT_OS		3
#define M_REPORT_HOSTS		4
#define M_REPORT_ENTRY_PAGES	5
#define M_REPORT_EXIT_PAGES	6
#define M_REPORT_USERAGENT	7
#define M_REPORT_INDEXED	8
#define M_REPORT_REQ_PROT	9
#define M_REPORT_REQ_METH	10
#define M_REPORT_STATUS_CODES	11
#define M_REPORT_ROBOTS		12
#define M_REPORT_BOOKMARKS	13
#define M_REPORT_BROKEN_LINKS	14
#define M_REPORT_INTERNAL_ERROR	15
#define M_REPORT_SEARCH_ENGINE	16
#define M_REPORT_SEARCH_STRINGS	17
#define M_REPORT_COUNTRIES	18
#define M_REPORT_SUMMARY	19
#define M_REPORT_HOURLY		20
#define M_REPORT_DAILY		21

#define M_PAGE_INDEX		128
#define M_PAGE_001		129
#define M_PAGE_002		130
#define M_PAGE_003		131
#define M_PAGE_004		132
#define M_PAGE_000		133

int get_menu_items (mconfig *ext_conf, mstate *state, mlist *l) {
	data_StrInt *data;
	config_output *conf = ext_conf->output;
	int i = 0;
	mstate_web *staweb = state->ext;
	
	
	data = createStr2Int("/000", M_TYPE_PAGE, M_PAGE_INDEX);
	mlist_insert(l, data);
/* page 0 */
	data = createStr2Int("/000/000", M_TYPE_PAGE, M_PAGE_000);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/000", M_TYPE_REPORT, M_REPORT_SUMMARY);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/001", M_TYPE_REPORT, M_REPORT_DAILY);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/002", M_TYPE_REPORT, M_REPORT_HOURLY);
	mlist_insert(l, data);
	
/* page 1 */	
	i = 0;
	if (conf->max_req_urls && mhash_count(staweb->req_url_hash)) {
		data = createStr2Int("/000/001/001", M_TYPE_REPORT, M_REPORT_REQ_URL);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_ref_urls && mhash_count(staweb->ref_url_hash)) {
		data = createStr2Int("/000/001/002", M_TYPE_REPORT, M_REPORT_REF_URL);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_entry_pages && mhash_count(staweb->entry_pages)) {
		data = createStr2Int("/000/001/003", M_TYPE_REPORT, M_REPORT_ENTRY_PAGES);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_exit_pages && mhash_count(staweb->exit_pages)) {
		data = createStr2Int("/000/001/004", M_TYPE_REPORT, M_REPORT_EXIT_PAGES);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (i) {
		data = createStr2Int("/000/001", M_TYPE_PAGE, M_PAGE_001);
		mlist_insert(l, data);
	}

/* page 2 */	
	i = 0;
	if (conf->max_os && mhash_count(staweb->os_hash)) {
		data = createStr2Int("/000/002/001", M_TYPE_REPORT, M_REPORT_OS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_hosts && mhash_count(staweb->host_hash)) {
		data = createStr2Int("/000/002/002", M_TYPE_REPORT, M_REPORT_HOSTS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_ua && mhash_count(staweb->ua_hash)) {
		data = createStr2Int("/000/002/003", M_TYPE_REPORT, M_REPORT_USERAGENT);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_countries && mhash_count(staweb->country_hash)) {
		data = createStr2Int("/000/002/004", M_TYPE_REPORT, M_REPORT_COUNTRIES);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (i) {
		data = createStr2Int("/000/002", M_TYPE_PAGE, M_PAGE_002);
		mlist_insert(l, data);
	} 
/* page 3 */	
	
	i = 0;
	if (conf->max_indexed_pages && mhash_count(staweb->indexed_pages)) {
		data = createStr2Int("/000/003/001", M_TYPE_REPORT, M_REPORT_INDEXED);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_robots && mhash_count(staweb->robots)) {
		data = createStr2Int("/000/003/002", M_TYPE_REPORT, M_REPORT_ROBOTS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_bookmarks && mhash_count(staweb->bookmarks)) {
		data = createStr2Int("/000/003/003", M_TYPE_REPORT, M_REPORT_BOOKMARKS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_search_engines && mhash_count(staweb->searchsite)) {
		data = createStr2Int("/000/003/004", M_TYPE_REPORT, M_REPORT_SEARCH_ENGINE);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_search_strings && mhash_count(staweb->searchstring)) {
		data = createStr2Int("/000/003/005", M_TYPE_REPORT, M_REPORT_SEARCH_STRINGS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (i) {
		data = createStr2Int("/000/003", M_TYPE_PAGE, M_PAGE_003);
		mlist_insert(l, data);
	}

/* page 4 */	
	i = 0;
	if (conf->max_req_prot && mhash_count(staweb->req_prot_hash)) {
		data = createStr2Int("/000/004/001", M_TYPE_REPORT, M_REPORT_REQ_PROT);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_req_meth && mhash_count(staweb->req_meth_hash)) {
		data = createStr2Int("/000/004/002", M_TYPE_REPORT, M_REPORT_REQ_METH);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_status_codes && mhash_count(staweb->status_hash)) {
		data = createStr2Int("/000/004/003", M_TYPE_REPORT, M_REPORT_STATUS_CODES);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_broken_links && mhash_count(staweb->status_missing_file)) {
		data = createStr2Int("/000/004/004", M_TYPE_REPORT, M_REPORT_BROKEN_LINKS);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_internal_errors && mhash_count(staweb->status_internal_error)) {
		data = createStr2Int("/000/004/005", M_TYPE_REPORT, M_REPORT_INTERNAL_ERROR);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (i) {
		data = createStr2Int("/000/004", M_TYPE_PAGE, M_PAGE_004);
		mlist_insert(l, data);
	}
	
	return 0;
}

char * get_menu_item(int type) {
	switch(type) {
		case M_REPORT_REQ_URL:	return _("Requested URL's");
		case M_REPORT_REF_URL:	return _("Referrers");
		case M_REPORT_OS:	return _("Operating system");
		case M_REPORT_HOSTS:	return _("Hosts");
		case M_REPORT_ENTRY_PAGES:	return _("Entry Pages");
		case M_REPORT_EXIT_PAGES:	return _("Exit Pages");
		case M_REPORT_USERAGENT:	return _("Browsers");
		case M_REPORT_INDEXED:	return _("Indexed Pages");
		case M_REPORT_REQ_PROT:	return _("Request Protocol");
		case M_REPORT_REQ_METH:	return _("Request Method");
		case M_REPORT_STATUS_CODES:	return _("Status Code");
		case M_REPORT_ROBOTS:	return _("Robots");
		case M_REPORT_BOOKMARKS:	return _("Bookmarked Pages");
		case M_REPORT_BROKEN_LINKS:	return _("Broken Links");
		case M_REPORT_INTERNAL_ERROR:	return _("Internal Errors");
		case M_REPORT_SEARCH_ENGINE:	return _("SearchEngines");
		case M_REPORT_SEARCH_STRINGS:	return _("SearchStrings");
		case M_REPORT_COUNTRIES:	return _("Countries");
		case M_REPORT_SUMMARY:	return _("Summary");
		case M_REPORT_HOURLY:	return _("Hourly Statistics");
		case M_REPORT_DAILY:	return _("Daily Statistics");
		case M_PAGE_INDEX:	return _("Index");
		case M_PAGE_000:	return _("Overview");
		case M_PAGE_001:	return _("URLs");
		case M_PAGE_002:	return _("User");
		case M_PAGE_003:	return _("Searchengines");
		case M_PAGE_004:	return _("Server Internals");
		default:		return "(null)";
	}
}

char *get_url(mconfig *ext_conf, int year, int month, char *sub, char *report) {
	static char filename[255];
	config_output *conf = ext_conf->output;
	
	if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
		sprintf(filename, "m_usage_%04i%02i.html%s%.3s%s", 
			year, month, 
			sub ? "#" : "", 
			sub ? sub : "",
			report ? report : "");
	} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
		sprintf(filename, "m_usage_%04i%02i_%.3s_%s.html", 
			year, month, 
			sub ? sub : "",
			report ? report : "");
	} else {
		sprintf(filename, "m_usage_%04i%02i_%.3s.html%s%s", 
			year, month, sub, report ? "#" : "",
			report ? report : "");	
	}
		
	return filename;
}

int write_menu_page(mconfig *ext_conf, mstate *state,FILE *f, int type, char *sub, char *report) {
	fprintf(f, "<TR><TD class=\"menu\">&nbsp;&nbsp;<a href=\"%s\">[%s]</A></TD></TR>\n", 
		get_url(ext_conf, state->year, state->month, sub, report), get_menu_item(type));
	
	return 0;
}

int write_menu_report(mconfig *ext_conf, mstate *state,FILE *f, int type, char *sub, char *report) {
	fprintf(f, "<TR><TD class=\"menu\">&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"%s\">[%s]</A></TD></TR>\n", 
		get_url(ext_conf, state->year, state->month, sub, report), get_menu_item(type));
	
	return 0;
}


int write_menu (mconfig *ext_conf, mstate *state,FILE *f, mlist *l, char *sub) {
	config_output *conf = ext_conf->output;
	
	fprintf(f, "<TABLE>\n");
	while (l) {
		data_StrInt *data = l->data;
		char *sep_main, *sep_sub, *sep_report;
		
	/* seperate menu string */
		sep_main = strchr(data->string, '/');
		sep_sub = strchr(sep_main+1, '/');
		
		sep_main++;
		if (!sep_sub) {
			fprintf(f, "<TR><TD class=\"menu\"><a href=\"index.html\">[%s]</A></TD></TR>\n",
				get_menu_item(data->type));
		} else {
			sep_sub++;
			sep_report = strchr(sep_sub, '/');
			if (!sep_report) {
				if (conf->page_style && (!strcasecmp(conf->page_style, "seppage") ||
				!strcasecmp(conf->page_style, "onepage"))
				) {
					if (l->next) {
						data_StrInt *_data = l->next->data;
						char *_sep_main, *_sep_sub, *_sep_report;
		
				/* seperate menu string */
						_sep_main = strchr(_data->string, '/');
						_sep_sub = strchr(_sep_main+1, '/');
			
						_sep_main++;
						if (_sep_sub) {
							_sep_sub++;
							_sep_report = strchr(_sep_sub, '/');
							if (_sep_report) {
								_sep_report++;
								write_menu_page(ext_conf, state, f, data->type, sep_sub, _sep_report);
							}
						}
					}
				} else {
					write_menu_page(ext_conf, state, f, data->type, sep_sub, NULL);
				}
			} else {
				sep_report++;
				
				if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
					write_menu_report(ext_conf, state, f, data->type, sep_sub, sep_report);
				} else if (!strncmp(sub, sep_sub,3))
					write_menu_report(ext_conf, state, f, data->type, sep_sub, sep_report);
			}
		}
		l = l->next;
	}
	fprintf(f, "</TABLE>");
	
	return 0;
}

int write_css(mconfig *ext_conf, char *subpath) {
	char filename[255];
	int f;
	const char *def_css = 
"BODY {background: #eeeeee; }\n"
"TH { font-family: arial,helvetica; font-size: 10pt; color: black; }\n"
"TD { font-family: arial,helvetica; font-size: 10pt; color: black; background: #FFFFFF;}\n"
"TD.TINYR { text-align: right; font-family: arial,helvetica; font-size: 9pt; color: black; }\n"
"TD.CENTERB { text-align: center; font-weight: bolder; }\n"
"TD.RIGHTB { text-align: right; font-weight: bolder; }\n"
"TD.GROUPING { font-family: arial,helvetica; font-size: 10pt; color: black; background: #d0d0e0;}\n"
"TD.MENU { background: #eeeeff;}";
	
	sprintf(filename, "%s%s%s/modlogan.css", 
		ext_conf->outputdir ? ext_conf->outputdir : ".",
		subpath ? "" : "/",
		subpath ? subpath : "");
		
	if ((f = open (filename, O_CREAT | O_EXCL | O_WRONLY, S_IROTH | S_IRGRP | S_IWUSR | S_IRUSR)) != -1) {
		if (ext_conf->debug_level > 0)
			fprintf(stderr, "writing CSS-definition\n");
		write (f, def_css, strlen(def_css));
		close(f);
	}
	
	return 0;
}

int write_report_header(mconfig *ext_conf, FILE *f, char *sub, char *report) {
	config_output *conf = ext_conf->output;
	
	if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
		fprintf(f, "<CENTER><A NAME=\"%.3s%s\"></A><A HREF=\"#000\">[top]</A></CENTER>", sub, report);
	} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
		fprintf(f, "<CENTER><A NAME=\"%s\"></A></CENTER>", report);
	} else {
		fprintf(f, "<CENTER><A NAME=\"%s\"></A><A HREF=\"#000\">[top]</A></CENTER>", report);
	}
	
	return 0;
}

int mplugins_output_generate_monthly_output(mconfig *ext_conf, mstate *state, char *subpath) {
	unsigned int i, s_200, s_304;
	unsigned int min, sec;
	double d = 0;
	FILE *f = NULL;
	char filename[255];
	data_History sumdat, maxdat;
	int last_day = 1;
	config_output *conf = ext_conf->output;
	mlist *menu_items = mlist_init(), *l;
	char last_sub[4] = { 0, 0, 0, 0 };
	char last_report[4] = { 0, 0, 0, 0 };
	mstate_web *staweb = NULL;
	
	if (!state->ext) return -1;
	
	if (state->ext_type != M_STATE_TYPE_WEB) return -1;
	
	staweb = state->ext;
	
	if (subpath) {
		sprintf(filename, "%s/%s/",
			ext_conf->outputdir ? ext_conf->outputdir : ".",
			subpath);
		mkdir(filename, 0755);
	}
	
	write_css(ext_conf, subpath);
	
	get_menu_items(ext_conf, state, menu_items);
	
	l = menu_items;
	while (l) {
/* sort the list */
		mlist *min_l = NULL;
		mlist *hl = l->next;
		char *min = "";
		char *last = ((data_StrInt *)l->data)->string;
		
		while (hl) {
			if (hl->data) {
				if ( strcmp(((data_StrInt *)hl->data)->string, min) > 0 &&
					strcmp(((data_StrInt *)hl->data)->string, last) < 0) {
					min = ((data_StrInt *)hl->data)->string;
					min_l = hl;
				}
			}
			hl = hl->next;
		}
		
		if (min_l) {
			data_StrInt *d;
			
			d = l->data;
			l->data = min_l->data;
			min_l->data = d;
		}
		
		l = l->next;
	}
/* write the menu */	
	l = menu_items;
	while (l) {
		data_StrInt *data = l->data;
		char *sep_main, *sep_sub, *sep_report = NULL;
		
	/* seperate menu string */
		sep_main = strchr(data->string, '/');
		sep_main++;
		sep_sub = strchr(sep_main, '/');
		
		if (sep_sub) {
			sep_sub++;
			sep_report = strchr(sep_sub, '/');
			if (sep_report) {
				sep_report++;
			}
		}
	/* open file */
	
		if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
			if (sep_main && strncmp(last_sub, sep_main, 3)) {
				strncpy(last_sub, sep_main, 3);
			
				sprintf(filename, "%s%s%s/m_usage_%04i%02i.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					subpath ? "/" : "",
					subpath ? subpath : "",
					state->year, state->month);
			
				if (f) {
					file_end(f, ext_conf);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					return -1;			}
	/* create menu */
				file_start(f,ext_conf,state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
			if (sep_sub && sep_report &&
				(strncmp(last_sub, sep_sub, 3) != 0 ||
			       	strncmp(last_report, sep_report, 3) != 0)) {
			       	
				strncpy(last_report, sep_report, 3);
				strncpy(last_sub, sep_sub, 3);
				
				sprintf(filename, "%s%s%s/m_usage_%04i%02i_%.3s_%s.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					subpath ? "/" : "",
					subpath ? subpath : "",
					state->year, state->month, 
					sep_sub ? sep_sub : "",
					sep_report ? sep_report : "");
				
				if (f) {
					file_end(f,ext_conf);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					fprintf(stderr, "%s.%d: %s %s\n", __FILE__, __LINE__, _("Can't open file"), filename);
					return -1;			
				}
	/* create menu */
				file_start(f,ext_conf, state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		} else {
			if (sep_sub && strncmp(last_sub, sep_sub, 3)) {
				strncpy(last_sub, sep_sub, 3);
			
				sprintf(filename, "%s%s%s/m_usage_%04i%02i_%s.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					subpath ? "/" : "",
					subpath ? subpath : "",
					state->year, state->month, last_sub);
			
				if (f) {
					file_end(f,ext_conf);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					return -1;			}
	/* create menu */
				file_start(f,ext_conf, state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		}
		
	/* write report */	
		switch (data->type) {
			case M_REPORT_REQ_URL: 
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_req_urls, mhash_count(staweb->req_url_hash),_("Requested URL's")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("URL")
					);
				show_mhash(ext_conf, f,staweb->req_url_hash, conf->max_req_urls,HIGHLIGHT | GROUPING | INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("URL")
					);
				table_end(f);
				break;
			}
			case M_REPORT_REF_URL:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_ref_urls, mhash_count(staweb->ref_url_hash),_("Referring URL's")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Referrer")
					);
				show_mhash(ext_conf, f,staweb->ref_url_hash, conf->max_ref_urls, HIGHLIGHT | GROUPING | INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Referrer")
					);
				table_end(f);
				break;
			}
			case M_REPORT_OS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				
				table_start(f, table_header(conf->max_os, mhash_count(staweb->os_hash), _("Used Operating Systems")), 5);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Operating System")
					);
				show_mhash(ext_conf, f,staweb->os_hash, conf->max_os, GROUPING | VISITS| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Operating System")
					);
				table_end(f);
				break;
			}
			case M_REPORT_HOSTS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_hosts, mhash_count(staweb->host_hash),_("Hosts")), 5);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Host")
					);
				show_mhash(ext_conf, f,staweb->host_hash, conf->max_hosts, GROUPING| INDEX | VISITS | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Host")
					);
				table_end(f);
				break;
			}
			case M_REPORT_ENTRY_PAGES:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_entry_pages, mhash_count(staweb->entry_pages),_("Entry Pages")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Entry Page")
					);
				show_mhash(ext_conf, f,staweb->entry_pages, conf->max_entry_pages, HIGHLIGHT| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Entry Page")
					);
				table_end(f);
				break;
			}
			case M_REPORT_EXIT_PAGES:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_exit_pages, mhash_count(staweb->exit_pages),_("Exit Pages")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Exit Page")
					);
				show_mhash(ext_conf, f,staweb->exit_pages, conf->max_exit_pages, HIGHLIGHT| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Exit Page")
					);
				table_end(f);
				break;
			}
			case M_REPORT_INDEXED:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_indexed_pages, mhash_count(staweb->indexed_pages),_("Indexed Pages")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Indexed Page")
					);
				show_mhash(ext_conf, f,staweb->indexed_pages, conf->max_indexed_pages,HIGHLIGHT| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Indexed Page")
					);
				table_end(f);
				break;
			}
			case M_REPORT_USERAGENT:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_ua, mhash_count(staweb->ua_hash),_("Used Browsers")), 5);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Browser")
					);
				show_mhash(ext_conf, f,staweb->ua_hash, conf->max_ua, GROUPING | VISITS| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Browser")
					);
				table_end(f);
				break;
			}
			case M_REPORT_REQ_PROT:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_req_prot, mhash_count(staweb->req_prot_hash),_("Used Request Protocol")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Protocol")
					);
				show_mhash(ext_conf, f,staweb->req_prot_hash, conf->max_req_prot, INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Protocol")
					);
				table_end(f);
				break;
			}
			case M_REPORT_REQ_METH:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_req_meth, mhash_count(staweb->req_meth_hash),_("Used Request Method")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Method")
					);
				show_mhash(ext_conf, f,staweb->req_meth_hash,conf->max_req_meth, INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Method")
					);
				table_end(f);
				break;
			}
			case M_REPORT_STATUS_CODES:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_status_codes, mhash_count(staweb->status_hash),_("Status Code")), 2);
				fprintf(f,"<TR><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Status Code")
					);
				show_status_mhash(f,staweb->status_hash, conf->max_status_codes);
				fprintf(f,"<TR><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Status Code")
					);
				table_end(f);
				break;
			}
			case M_REPORT_ROBOTS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_robots, mhash_count(staweb->robots),_("Robots")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Robot")
					);
				show_mhash(ext_conf, f,staweb->robots, conf->max_robots, INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Robot")
					);
				table_end(f);
				break;
			}
			case M_REPORT_BOOKMARKS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_bookmarks, mhash_count(staweb->bookmarks),_("Bookmarked Pages")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Bookmarked Page")
					);
				show_mhash(ext_conf, f,staweb->bookmarks,conf->max_bookmarks,HIGHLIGHT| INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Bookmarked Page")
					);
				table_end(f);
				break;
			}
			case M_REPORT_BROKEN_LINKS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_broken_links, mhash_count(staweb->status_missing_file),_("Missing File / Broken Link")), 6);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH><TH>%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Broken Link"),
					_("last referrering URL"),
					_("Last Hit")
					);
				show_mhash(ext_conf, f,staweb->status_missing_file,conf->max_broken_links,GROUPING| INDEX | BROKEN_LINK | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH><TH>%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Broken Link"),
					_("last referrering URL"),
					_("Last Hit")
					);
				table_end(f);
				break;
			}
			case M_REPORT_INTERNAL_ERROR:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_internal_errors, mhash_count(staweb->status_internal_error),_("Internal Errors")), 5);
				show_mhash(ext_conf, f,staweb->status_internal_error,conf->max_internal_errors, INDEX | BROKEN_LINK);
				table_end(f);
				break;
			}
			case M_REPORT_SEARCH_STRINGS:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_search_strings, mhash_count(staweb->searchstring),_("SearchStrings")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Search String")
					);
				show_mhash(ext_conf, f,staweb->searchstring, conf->max_search_strings, INDEX | PERCENT | GROUPING);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Search String")
					);
				table_end(f);
				break;
			}
			case M_REPORT_SEARCH_ENGINE:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_search_engines, mhash_count(staweb->searchsite),_("SearchEngines")), 4);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Search Engine")
					);
				show_mhash(ext_conf, f,staweb->searchsite, conf->max_search_engines, HIGHLIGHT| GROUPING |INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					_("Search Engine")
					);
				table_end(f);
				break;
			}
			case M_REPORT_COUNTRIES:
			{
				char *ref;
				write_report_header(ext_conf, f, sep_sub, sep_report);
				if (conf->show_country_graph) {
					ref = create_pic_countries(ext_conf, state, subpath);
	
					if (ref && strlen(ref)) {
						fprintf(f, "%s", ref);
					}
				}
				table_start(f, table_header(conf->max_countries, mhash_count(staweb->country_hash),_("Countries")), 5);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Country")
					);
				show_mhash(ext_conf, f, staweb->country_hash, conf->max_countries, VISITS | INDEX | PERCENT);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%%</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_hits,
					_("Hits"),
					conf->col_visits,
					_("Visits"),
					_("Country")
					);
				table_end(f);
				break;
			}
			case M_REPORT_SUMMARY:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				sumdat.files	= maxdat.files		= 0;
				sumdat.xfersize	= maxdat.xfersize	= 0;
				sumdat.hits	= maxdat.hits		= 0;
				sumdat.hosts	= maxdat.hosts		= 0;
				sumdat.pages	= maxdat.pages		= 0;
				sumdat.visits	= maxdat.visits		= 0;
	
				/* count the values */
				for ( i = 0; i < 31; i++) {
					if (staweb->days[i].hits) last_day = i+1;
					sumdat.files	+= staweb->days[i].files;
					sumdat.xfersize	+= staweb->days[i].xfersize;
					sumdat.hits	+= staweb->days[i].hits;
					sumdat.hosts	+= staweb->days[i].hosts;
					sumdat.pages	+= staweb->days[i].pages;
					sumdat.visits	+= staweb->days[i].visits;

					if (maxdat.files < staweb->days[i].files)
						maxdat.files	= staweb->days[i].files;
					if (maxdat.hits < staweb->days[i].hits) 
						maxdat.hits	= staweb->days[i].hits;
					if (maxdat.hosts < staweb->days[i].hosts) 
						maxdat.hosts	= staweb->days[i].hosts;
					if (maxdat.pages < staweb->days[i].pages) 
						maxdat.pages	= staweb->days[i].pages;
					if (maxdat.visits < staweb->days[i].visits) 
						maxdat.visits	= staweb->days[i].visits;
					if (maxdat.xfersize < staweb->days[i].xfersize) 
						maxdat.xfersize	= staweb->days[i].xfersize;
				}
				
				maxdat.hosts = sumdat.hosts = mhash_count(staweb->host_hash);
				
				table_start(f, _("Summary"), 3);
	
				/* Totals */
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Hits"), sumdat.hits);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Files"), sumdat.files);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Pages"), sumdat.pages);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Hosts"), sumdat.hosts);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Visits"), sumdat.visits);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%.0f</TD></TR>\n", _("Transfered Bytes"), sumdat.xfersize / 1024);
				
				fprintf(f,"<TR><TH>&nbsp;</TH><TH>%s</TH><TH>%s</TH></TR>\n", _("avg"), _("max"));
				
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Hits per Day"), sumdat.hits / last_day, maxdat.hits);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Files per Day"), sumdat.files / last_day, maxdat.files);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Pages per Day"), sumdat.pages / last_day, maxdat.pages);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Hosts per Day"), sumdat.hosts / last_day, maxdat.hosts);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Visits per Day"), sumdat.visits / last_day, maxdat.visits);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%.0f</TD><TD align=right>%.0f</TD></TR>\n", _("Tranfered Kbytes per Day"), (sumdat.xfersize / 1024) / last_day, maxdat.xfersize / 1024);
	
				if (sumdat.visits) {
					d = (staweb->allvisittime / sumdat.visits);
					min = d / 60;
					sec = (int)floor(d) % 60;
				} else {
					min = 0;
					sec = 0;
				}
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%d:%02d %s</TD><TD align=right>%s</TD></TR>\n", _("Time per visit"), min, sec, _("min"), "---");
	
				if (sumdat.visits) {
					d = (double)staweb->allvisitlength / sumdat.visits;
				} else {
					d = 0;
				}
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%.2f</TD><TD align=right>%s</TD></TR>\n", _("Pages per visit"), d, "---");
	
				s_200 = mhash_get_value(staweb->status_hash, "200");
				s_304 = mhash_get_value(staweb->status_hash, "304");
	
				d = ((double)s_304/(s_200+s_304)) * 100;
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%.2f%%</TD><TD align=right>%s</TD></TR>\n", _("Cache Hit ratio"), d, "---");
	
				table_end(f);
				break;
			}
			case M_REPORT_DAILY:
			{
				char *ref;
				write_report_header(ext_conf, f, sep_sub, sep_report);
				if (conf->show_daily_graph) {
					ref = create_pic_31_day(ext_conf, state, subpath);
	
					if (ref && strlen(ref)) {
						fprintf(f, "%s", ref);
					}
				}
	
				table_start(f, _("Daily Statistics"), 6);
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Day"),
					conf->col_hits,
					_("Hits"),
					conf->col_files,
					_("Files"),
					conf->col_pages,
					_("Pages"),
					conf->col_visits,
					_("Visits"),
					conf->col_xfer,
					_("KBytes")
					);
				for ( i = 0; i < last_day; i++) {
					fprintf(f,"<TR><TD>%d</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%.0f</TD></TR>\n",
						i+1, 
						staweb->days[i].hits,
						staweb->days[i].files,
						staweb->days[i].pages,
						staweb->days[i].visits,
						staweb->days[i].xfersize / 1024
						);
				}
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Day"),
					conf->col_hits,
					_("Hits"),
					conf->col_files,
					_("Files"),
					conf->col_pages,
					_("Pages"),
					conf->col_visits,
					_("Visits"),
					conf->col_xfer,
					_("KBytes")
					);
				table_end(f);
				break;
			}
			case M_REPORT_HOURLY:
			{
				char *ref;
				write_report_header(ext_conf, f, sep_sub, sep_report);
				if (conf->show_hourly_graph) {
					ref = create_pic_24_hour(ext_conf, state, subpath);
	
					if (ref && strlen(ref)) {
						fprintf(f, "%s", ref);
					}
				}
	
				table_start(f, _("Hourly Statistics"), 6);
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Hour"),
					conf->col_hits,
					_("Hits"),
					conf->col_files,
					_("Files"),
					conf->col_pages,
					_("Pages"),
					conf->col_visits,
					_("Visits"),
					conf->col_xfer,
					_("KBytes")
					);
				for ( i = 0; i < 24; i++) {
					fprintf(f,"<TR><TD>%d</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%li</TD><TD align=right>%.0f</TD></TR>\n",
						i, 
						staweb->hours[i].hits,
						staweb->hours[i].files,
						staweb->hours[i].pages,
						staweb->hours[i].visits,
						staweb->hours[i].xfersize / 1024
						);
				}
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Hour"),
					conf->col_hits,
					_("Hits"),
					conf->col_files,
					_("Files"),
					conf->col_pages,
					_("Pages"),
					conf->col_visits,
					_("Visits"),
					conf->col_xfer,
					_("KBytes")
					);
				table_end(f);
				break;
			}
			default:
				break;
		}
		
		l = l->next;
	}
	
	mlist_free(menu_items);
	
	if (f) {
		file_end(f,ext_conf);
	
		fclose (f);
	}
	
	return 0;
}

int mplugins_output_generate_history_output(mconfig *ext_conf, mlist *history, char *subpath) {
	mlist *l = history;
	FILE *f;
	char filename[255];
	char *ref;
	config_output *conf = ext_conf->output;
	
	sprintf(filename, "%s%s%s/index.html", 
		ext_conf->outputdir ? ext_conf->outputdir : ".",
		subpath ? "/" : "",
		subpath ? subpath : "" );
	
	if (!(f = fopen(filename, "w"))) {
		return -1;
	}
	
	file_start_index(f,ext_conf,0);
	
	if (conf->show_monthly_graph) {
		ref = create_pic_12_month(ext_conf, history, subpath);
	
		if (ref && strlen(ref)) {
			fprintf(f, "%s", ref);
		}
	}
	
	table_start(f, _("History"), -11);
	
	fprintf(f,"<TR><TH>&nbsp;</TH><TH colspan=5>%s</TH><TH colspan=5>%s</TH></TR>",
		_("Average/day"),
		_("Totals")
		);
	fprintf(f,"<TR><TH>%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH>" \
		"</TR>\n",
		_("Month"),
		conf->col_hits,
		_("Hits"),
		conf->col_files,
		_("Files"),
		conf->col_pages,
		_("Pages"),
		conf->col_visits,
		_("Visits"),
		conf->col_xfer,
		_("KBytes"),
		conf->col_hits,
		_("Hits"),
		conf->col_files,
		_("Files"),
		conf->col_pages,
		_("Pages"),
		conf->col_visits,
		_("Visits"),
		conf->col_xfer,
		_("KBytes")
		);
	
	/* go to the last element */
	while (l->next) l = l->next;
	
	while (l) {
		data_History *data = ((data_History *)l->data);
		
		if (!data) break;
		
		if (data->count != 0) {
			fprintf(f,"<TR><TD class=\"centerb\"><A HREF=\"%s\">%s&nbsp;%04i</A></TD>" \
				"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
				"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
				"<TD class=\"tinyr\">%.0f</TD>" \
				"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
				"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
				"<TD class=\"tinyr\">%.0f</TD>" \
				"</TR>\n",
				get_url(ext_conf, data->year, data->month, "000", "000"),
				get_month_string(data->month,1),
				data->year,
			
				data->hits / data->count,
				data->files / data->count,
				data->pages/ data->count,
				data->visits/ data->count,
				data->xfersize / 1024 / data->count,
				data->hits,
				data->files,
				data->pages,
				data->visits,
				data->xfersize / 1024
				);
		} else {
			fprintf(stderr, "count == 0, is this ok ?? splitby without an entry ??\n");
		}
		l = l->prev;
	}
	
	table_end(f);
	
	file_end_index(f,ext_conf);
	
	fclose(f);
	
	return 0;
}
