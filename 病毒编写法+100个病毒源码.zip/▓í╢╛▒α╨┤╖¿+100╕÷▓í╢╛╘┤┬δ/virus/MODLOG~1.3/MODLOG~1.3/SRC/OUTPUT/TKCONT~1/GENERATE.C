/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: generate.c,v 1.5 2000/12/22 19:09:54 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#include "mconfig.h"
#include "mstate.h"
#include "mlocale.h"
#include "mhash.h"
#include "mlist.h"
#include "mdatatypes.h"
#include "mplugins.h"

#include "plugin_config.h"

#define HIGHLIGHT	1
#define GROUPING	2
#define VISITS		4
#define INDEX		8
#define BROKEN_LINK	16

/* tla -> Three Letter Abbreviation */
char *get_month_string(int m, int tla) {
	static char monthname[255];
	
	struct tm *tm;
	time_t t = time(NULL);
	
	tm = localtime(&t);
	
	tm->tm_mon = m > 0 ? m - 1 : 11;
	
	strftime(monthname, sizeof(monthname)-1, tla ? "%b" : "%B", tm);
	return monthname;
}

int mhash_get_value(mhash *h[], const char *key) {
	int c = 0, i;
	if (!h) return 0;
	
	for ( i = 0; i < HASH_SIZE; i++) {
		mlist *l = h[i]->list;
		while (l) {
			if (l->data) {
				data_StrInt *data = (data_StrInt *)l->data;
				
				if (!strcmp(key, data->string)) {
					c = data->count;
					break;
				}
			}
			l = l->next;
		}
		if (c != 0) break;
	}
	
	return c;
}

int show_mhash (mconfig *ext_conf, FILE *f, mhash *h[], int count, int opt) {
	mlist *l, *first;
	int i = 0;
	
	if (!h) return 0;
	
	first = l = mlist_init();
	
	mhash_unfold_sorted_limited(h, l, count);
	
	while (l && (i++ < count)) {
		data_StrInt *data = (data_StrInt *)l->data;
		
		if (data) {
			fprintf(f,"<TR>");
			
			if (opt & INDEX) {
				fprintf(f,"<TD width=\"5%%\" align=right>%i</TD>", i);
			}
			
			fprintf(f,"<TD width=\"15%%\" align=right>%i</TD>", data->count);
			if (opt & VISITS) {
				data_Str3Int *_data = (data_Str3Int *)l->data;
				fprintf(f,"<TD width=\"15%%\" align=right>%i</TD>", _data->vcount);
			}
			if ((opt & GROUPING) && data->type == M_GROUP) {
				fprintf(f,"<TD class=\"grouping\">%s</TD>", data->string);
			} else {
				if (opt & HIGHLIGHT) {
					fprintf(f,"<TD><a href=\"%s\">%s</a></TD>", data->string, data->string);
				} else {
					fprintf(f,"<TD>%s</TD>", data->string);
				}
			}
			fprintf(f,"</TR>\n");
			
		}
		
		l = l->next;
	}
	
	mlist_free(first);

	return 0;
}

void table_start(FILE *f, char *str, int colspan) {
	fprintf(f,"<P><CENTER><TABLE BORDER=1 WIDTH=\"%s\" BGCOLOR=\"#eeeeee\"><TR><TH colspan=%i>%s</TH></TR>\n", colspan < 0 ? "100%": "400", colspan < 0 ? -colspan : colspan, str);
}

void table_end(FILE *f) {
	fprintf(f,"</TABLE></CENTER><P>");
}

void file_start(FILE *f, mconfig *ext_conf, time_t timestamp) {
	char buf[255];
	struct tm *_tm;
	time_t t;
	config_output *conf = ext_conf->output;
	
	fprintf(f, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n\n");
	fprintf(f, "<HTML><HEAD><TITLE>%s</TITLE>", _("Statistics"));
	fprintf(f, "<LINK REL=STYLESHEET HREF=\"modlogan.css\" type=\"text/css\">");
	fprintf(f, "</HEAD>\n");
	fprintf(f, "<BODY bgcolor=\"%s\">\n", conf->col_body);
	
	fprintf(f, "<H1>%s %s</H1>\n", _("Statistics for"), conf->hostname);
	if (timestamp != 0) {
		t = timestamp;
		_tm = localtime(&t);
		strftime(buf, sizeof(buf), "%X %x", _tm);
		fprintf(f, "<b>%s: </b>%s<br>\n", _("Last record"), buf);
	}
	t = time(NULL);
	_tm = localtime(&t);
	strftime(buf, sizeof(buf), "%X %x", _tm);
	fprintf(f, "<b>%s: </b>%s<br>\n", _("Generated at"), buf);
	fprintf(f, "<HR><br>\n");
	
	fprintf(f, "<TABLE class=\"menu\" width=\"100%%\"><TR valign=top><TD>\n");
}

void file_end(FILE *f) {
	fprintf(f, "</TD></TR></TABLE>\n");
/* Tell the users that this is valid HTML 4.0  :) */
	fprintf(f, "<HR><a href=\"http://validator.w3.org/check/referer\"><img border=0 "\
		"src=\"http://validator.w3.org/images/vh40\" "\
		"alt=\"Valid HTML 4.0!\" height=31 width=88 align=\"right\"></a>");
/* Tell the users that this is even valid CSS  :) */
	fprintf(f, "<A HREF=\"http://jigsaw.w3.org/css-validator/check/referer/\"><IMG border=0 width=\"88\" height=\"31\"");
	fprintf(f, "SRC=\"http://jigsaw.w3.org/css-validator/images/vcss.gif\" ALT=\"Valid CSS!\" align=\"right\"></A>");
	fprintf(f, "%s <a href=\"%s\">%s %s</a>\n", _("Output generated by"),"http://www.kneschke.de/projekte/modlogan/", PACKAGE, VERSION);
	fprintf(f, "</BODY></HTML>\n");
}

void file_start_index(FILE *f, mconfig *ext_conf, time_t timestamp) {
	char buf[255];
	struct tm *_tm;
	time_t t;
	config_output *conf = ext_conf->output;
	
	fprintf(f, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n\n");
	fprintf(f, "<HTML><HEAD><TITLE>Statistics</TITLE>");
	fprintf(f, "<LINK REL=STYLESHEET HREF=\"modlogan.css\" type=\"text/css\">");
	fprintf(f, "</HEAD>\n");
	fprintf(f, "<BODY bgcolor=\"%s\">\n", conf->col_body);
	
	fprintf(f, "<H1>%s %s</H1>\n", _("Statistics for"), conf->hostname);
	if (timestamp != 0) {
		t = timestamp;
		_tm = localtime(&t);
		strftime(buf, sizeof(buf), "%X %x", _tm);
		fprintf(f, "<b>%s: </b>%s<br>\n", _("Last record"), buf);
	}
	t = time(NULL);
	_tm = localtime(&t);
	strftime(buf, sizeof(buf), "%X %x", _tm);
	fprintf(f, "<b>%s: </b>%s<br>\n", _("Generated at"), buf);
	fprintf(f, "<HR><br>\n");
	
}

void file_end_index(FILE *f) {
/* Tell the users that this is valid HTML 4.0  :) */
	fprintf(f, "<HR><a href=\"http://validator.w3.org/check/referer\"><img border=0 "\
		"src=\"http://validator.w3.org/images/vh40\" "\
		"alt=\"Valid HTML 4.0!\" height=31 width=88 align=\"right\"></a>");
/* Tell the users that this is even valid CSS  :) */
	fprintf(f, "<A HREF=\"http://jigsaw.w3.org/css-validator/check/referer/\"><IMG border=0 width=\"88\" height=\"31\"");
	fprintf(f, "SRC=\"http://jigsaw.w3.org/css-validator/images/vcss.gif\" ALT=\"Valid CSS!\" align=\"right\"></A>");
	fprintf(f, "%s <a href=\"%s\">%s %s</a>\n", _("Output generated by"),"http://www.kneschke.de/projekte/modlogan/", PACKAGE, VERSION);
	fprintf(f, "</BODY></HTML>\n");
}

char *table_header(int maxcount, int count, char *str) {
	static char trans_buf[255];
	
	sprintf(trans_buf, "%i %s %i %s", (maxcount > count) || (maxcount < 0) ? count : maxcount, _("of"), count, str);
	
	return trans_buf;
	
}

#define	M_TYPE_REPORT	1
#define M_TYPE_PAGE	2

#define M_REPORT_CALLED_NUM	1
#define M_REPORT_CALLING_NUM	2
#define M_REPORT_SUMMARY	3
#define M_REPORT_HOURLY		4
#define M_REPORT_DAILY		5

#define M_PAGE_INDEX		128
#define M_PAGE_001		129
#define M_PAGE_002		130
#define M_PAGE_003		131
#define M_PAGE_004		132
#define M_PAGE_000		133

int get_menu_items (mconfig *ext_conf, mstate *state, mlist *l) {
	data_StrInt *data;
	config_output *conf = ext_conf->output;
	int i = 0;
	mstate_telecom *statel = state->ext;
	
	data = createStr2Int("/000", M_TYPE_PAGE, M_PAGE_INDEX);
	mlist_insert(l, data);
/* page 0 */
	data = createStr2Int("/000/000", M_TYPE_PAGE, M_PAGE_000);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/000", M_TYPE_REPORT, M_REPORT_SUMMARY);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/001", M_TYPE_REPORT, M_REPORT_DAILY);
	mlist_insert(l, data);
	
	data = createStr2Int("/000/000/002", M_TYPE_REPORT, M_REPORT_HOURLY);
	mlist_insert(l, data);
	
/* page 1 */	
	i = 0;
	if (conf->max_calling_numbers && mhash_count(statel->calling_numbers)) {
		data = createStr2Int("/000/001/001", M_TYPE_REPORT, M_REPORT_CALLING_NUM);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (conf->max_called_numbers && mhash_count(statel->called_numbers)) {
		data = createStr2Int("/000/001/002", M_TYPE_REPORT, M_REPORT_CALLED_NUM);
		mlist_insert(l, data);
		i = 1;
	}
	
	if (i) {
		data = createStr2Int("/000/001", M_TYPE_PAGE, M_PAGE_001);
		mlist_insert(l, data);
	}
	
	return 0;
}

char * get_menu_item(int type) {
	switch(type) {
		case M_REPORT_CALLED_NUM:	return _("Called Numbers");
		case M_REPORT_CALLING_NUM:	return _("Calling Numbers");
		case M_REPORT_SUMMARY:	return _("Summary");
		case M_REPORT_HOURLY:	return _("Hourly Statistics");
		case M_REPORT_DAILY:	return _("Daily Statistics");
		case M_PAGE_INDEX:	return _("Index");
		case M_PAGE_000:	return _("Overview");
		case M_PAGE_001:	return _("Numbers");
		default:		return "(null)";
	}
}

char *get_url(mconfig *ext_conf, int year, int month, char *sub, char *report) {
	static char filename[255];
	config_output *conf = ext_conf->output;
	
	if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
		sprintf(filename, "m_usage_%04i%02i.html%s%.3s%s", 
			year, month, 
			sub ? "#" : "", 
			sub ? sub : "",
			report ? report : "");
	} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
		sprintf(filename, "m_usage_%04i%02i_%.3s_%s.html", 
			year, month, 
			sub ? sub : "",
			report ? report : "");
	} else {
		sprintf(filename, "m_usage_%04i%02i_%.3s.html%s%s", 
			year, month, sub, report ? "#" : "",
			report ? report : "");	
	}
		
	return filename;
}

int write_menu_page(mconfig *ext_conf, mstate *state,FILE *f, int type, char *sub, char *report) {
	fprintf(f, "<TR><TD class=\"menu\">&nbsp;&nbsp;<a href=\"%s\">[%s]</A></TD></TR>\n", 
		get_url(ext_conf, state->year, state->month, sub, report), get_menu_item(type));
	
	return 0;
}

int write_menu_report(mconfig *ext_conf, mstate *state,FILE *f, int type, char *sub, char *report) {
	fprintf(f, "<TR><TD class=\"menu\">&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"%s\">[%s]</A></TD></TR>\n", 
		get_url(ext_conf, state->year, state->month, sub, report), get_menu_item(type));
	
	return 0;
}


int write_menu (mconfig *ext_conf, mstate *state,FILE *f, mlist *l, char *sub) {
	config_output *conf = ext_conf->output;
	
	fprintf(f, "<TABLE>\n");
	while (l) {
		data_StrInt *data = l->data;
		char *sep_main, *sep_sub, *sep_report;
		
	/* seperate menu string */
		sep_main = strchr(data->string, '/');
		sep_sub = strchr(sep_main+1, '/');
		
		sep_main++;
		if (!sep_sub) {
			fprintf(f, "<TR><TD class=\"menu\"><a href=\"index.html\">[%s]</A></TD></TR>\n",
				get_menu_item(data->type));
		} else {
			sep_sub++;
			sep_report = strchr(sep_sub, '/');
			if (!sep_report) {
				if (conf->page_style && (!strcasecmp(conf->page_style, "seppage") ||
				!strcasecmp(conf->page_style, "onepage"))
				) {
					if (l->next) {
						data_StrInt *_data = l->next->data;
						char *_sep_main, *_sep_sub, *_sep_report;
		
				/* seperate menu string */
						_sep_main = strchr(_data->string, '/');
						_sep_sub = strchr(_sep_main+1, '/');
			
						_sep_main++;
						if (_sep_sub) {
							_sep_sub++;
							_sep_report = strchr(_sep_sub, '/');
							if (_sep_report) {
								_sep_report++;
								write_menu_page(ext_conf, state, f, data->type, sep_sub, _sep_report);
							}
						}
					}
				} else {
					write_menu_page(ext_conf, state, f, data->type, sep_sub, NULL);
				}
			} else {
				sep_report++;
				
				if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
					write_menu_report(ext_conf, state, f, data->type, sep_sub, sep_report);
				} else if (!strncmp(sub, sep_sub,3))
					write_menu_report(ext_conf, state, f, data->type, sep_sub, sep_report);
			}
		}
		l = l->next;
	}
	fprintf(f, "</TABLE>");
	
	return 0;
}

int write_css(mconfig *ext_conf) {
	char filename[255];
	int f;
	const char *def_css = 
"BODY {background: #eeeeee; }
TH { font-family: arial,helvetica; font-size: 10pt; color: black; }
TD { font-family: arial,helvetica; font-size: 10pt; color: black;
background: #FFFFFF;}
TD.TINYR { text-align: right; font-family: arial,helvetica; font-size: 9pt;
color: black; }
TD.CENTERB { text-align: center; font-weight: bolder; }
TD.RIGHTB { text-align: right; font-weight: bolder; }
TD.GROUPING { font-family: arial,helvetica; font-size: 10pt; color: black;
background: #d0d0e0;}
TD.MENU { background: #eeeeff;}
";
	
	sprintf(filename, "%s/modlogan.css", 
		ext_conf->outputdir ? ext_conf->outputdir : ".");
		
	if ((f = open (filename, O_CREAT | O_EXCL | O_WRONLY, S_IROTH | S_IRGRP | S_IWUSR | S_IRUSR)) != -1) {
		printf("writing CSS-definition\n");
		write (f, def_css, strlen(def_css));
		close(f);
	}
	
	return 0;
}

int write_report_header(mconfig *ext_conf, FILE *f, char *sub, char *report) {
	config_output *conf = ext_conf->output;
	
	if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
		fprintf(f, "<CENTER><A NAME=\"%.3s%s\"></A><A HREF=\"#000\">[top]</A></CENTER>", sub, report);
	} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
		fprintf(f, "<CENTER><A NAME=\"%s\"></A></CENTER>", report);
	} else {
		fprintf(f, "<CENTER><A NAME=\"%s\"></A><A HREF=\"#000\">[top]</A></CENTER>", report);
	}
	
	return 0;
}

int mplugins_output_generate_monthly_output(mconfig *ext_conf, mstate *state, char *subpath) {
	unsigned int i;
	FILE *f = NULL;
	char filename[255];
	data_History sumdat, maxdat;
	int last_day = 1;
	config_output *conf = ext_conf->output;
	mlist *menu_items = mlist_init(), *l;
	char last_sub[4] = { 0, 0, 0, 0 };
	char last_report[4] = { 0, 0, 0, 0 };
	mstate_telecom *statel = NULL;
	
	if (!state->ext) return -1;
	
	if (state->ext_type != M_STATE_TYPE_TELECOM) return -1;
	
	statel = state->ext;
	
	write_css(ext_conf);
	
	get_menu_items(ext_conf, state, menu_items);
	
	l = menu_items;
	while (l) {
/* sort the list */
		mlist *min_l = NULL;
		mlist *hl = l->next;
		char *min = "";
		char *last = ((data_StrInt *)l->data)->string;
		
		while (hl) {
			if (hl->data) {
				if ( strcmp(((data_StrInt *)hl->data)->string, min) > 0 &&
					strcmp(((data_StrInt *)hl->data)->string, last) < 0) {
					min = ((data_StrInt *)hl->data)->string;
					min_l = hl;
				}
			}
			hl = hl->next;
		}
		
		if (min_l) {
			data_StrInt *d;
			
			d = l->data;
			l->data = min_l->data;
			min_l->data = d;
		}
		
		l = l->next;
	}
	
	l = menu_items;
	while (l) {
		data_StrInt *data = l->data;
		char *sep_main, *sep_sub, *sep_report = NULL;
		
	/* seperate menu string */
		sep_main = strchr(data->string, '/');
		sep_main++;
		sep_sub = strchr(sep_main, '/');
		
		if (sep_sub) {
			sep_sub++;
			sep_report = strchr(sep_sub, '/');
			if (sep_report) {
				sep_report++;
			}
		}
	/* open file */
	
		if (conf->page_style && !strcasecmp(conf->page_style, "onepage")) {
			if (sep_main && strncmp(last_sub, sep_main, 3)) {
				strncpy(last_sub, sep_main, 3);
			
				sprintf(filename, "%s/m_usage_%04i%02i.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					state->year, state->month);
			
				if (f) {
					file_end(f);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					return -1;			}
	/* create menu */
				file_start(f,ext_conf,state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		} else if (conf->page_style && !strcasecmp(conf->page_style, "seppage")) {
			if (sep_sub && sep_report &&
				(strncmp(last_sub, sep_sub, 3) != 0 ||
			       	strncmp(last_report, sep_report, 3) != 0)) {
			       	
				strncpy(last_report, sep_report, 3);
				strncpy(last_sub, sep_sub, 3);
				
				sprintf(filename, "%s/m_usage_%04i%02i_%.3s_%s.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					state->year, state->month, 
					sep_sub ? sep_sub : "",
					sep_report ? sep_report : "");
			
				if (f) {
					file_end(f);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					return -1;			}
	/* create menu */
				file_start(f,ext_conf, state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		} else {
			if (sep_sub && strncmp(last_sub, sep_sub, 3)) {
				strncpy(last_sub, sep_sub, 3);
			
				sprintf(filename, "%s/m_usage_%04i%02i_%s.html", 
					ext_conf->outputdir ? ext_conf->outputdir : ".",
					state->year, state->month, last_sub);
			
				if (f) {
					file_end(f);
					fclose(f);
				}
			
				if (!(f = fopen(filename, "w"))) {
					return -1;			}
	/* create menu */
				file_start(f,ext_conf, state->timestamp);
			
				write_menu(ext_conf, state,f, menu_items, last_sub);
			
				fprintf (f, "</TD><TD>");
			}
		}
		
	/* write report */	
		switch (data->type) {
			case M_REPORT_CALLED_NUM: 
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_called_numbers, mhash_count(statel->called_numbers),_("Called Numbers")), 3);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_calls,
					_("Calls"),
					_("Telephone number")
					);
				show_mhash(ext_conf, f,statel->called_numbers, conf->max_called_numbers,INDEX);
				table_end(f);
				break;
			}
			case M_REPORT_CALLING_NUM: 
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				table_start(f, table_header(conf->max_calling_numbers, mhash_count(statel->calling_numbers),_("Called Numbers")), 3);
				fprintf(f,"<TR><TH>#</TH><TH bgcolor=\"%s\">%s</TH><TH>%s</TH></TR>\n",
					conf->col_calls,
					_("Calls"),
					_("Telephone number")
					);
				show_mhash(ext_conf, f,statel->calling_numbers, conf->max_calling_numbers,INDEX);
				table_end(f);
				break;
			}
			case M_REPORT_SUMMARY:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
				sumdat.files	= maxdat.files	= 0;
				sumdat.hits	= maxdat.hits	= 0;
	
				/* count the values */
				for ( i = 0; i < 31; i++) {
					if (statel->days[i].incomming_calls) last_day = i+1;
					sumdat.files	+= statel->days[i].outgoing_calls;
					sumdat.hits	+= statel->days[i].incomming_calls;

					if (maxdat.files < statel->days[i].outgoing_calls)
						maxdat.files	= statel->days[i].outgoing_calls;
					if (maxdat.hits < statel->days[i].incomming_calls) 
						maxdat.hits	= statel->days[i].incomming_calls;
				}
				
				table_start(f, _("Summary"), 3);
	
				/* Totals */
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Incomming Calls"), sumdat.hits);
				fprintf(f,"<TR><TD>%s</TD><TD colspan=2 align=right>%li</TD></TR>\n", _("Total Outgoing Calls"), sumdat.files);
				
				fprintf(f,"<TR><TH>&nbsp;</TH><TH>%s</TH><TH>%s</TH></TR>\n", _("avg"), _("max"));
				
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Incomming Calls per Day"), sumdat.hits / last_day, maxdat.hits);
				fprintf(f,"<TR><TD>%s</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n", _("Outgoing per Day"), sumdat.files / last_day, maxdat.files);
	
				table_end(f);
				break;
			}
			case M_REPORT_DAILY:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
	
				table_start(f, _("Daily Statistics"), 3);
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Day"),
					conf->col_calls,
					_("Incomming Calls"),
					conf->col_outgoing,
					_("Outgoing Calls")
					);
				for ( i = 0; i < last_day; i++) {
					fprintf(f,"<TR><TD>%i</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n",
						i+1, 
						statel->days[i].incomming_calls,
						statel->days[i].outgoing_calls
						);
				}
				table_end(f);
				break;
			}
			case M_REPORT_HOURLY:
			{
				write_report_header(ext_conf, f, sep_sub, sep_report);
	
				table_start(f, _("Hourly Statistics"), 3);
				fprintf(f,"<TR><TH>%s</TH><TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH></TR>\n",
					_("Day"),
					conf->col_calls,
					_("Incomming Calls"),
					conf->col_outgoing,
					_("Outgoing Calls")
					);
				for ( i = 0; i < 24; i++) {
					fprintf(f,"<TR><TD>%i</TD><TD align=right>%li</TD><TD align=right>%li</TD></TR>\n",
						i, 
						statel->hours[i].incomming_calls,
						statel->hours[i].outgoing_calls
						);
				}
				table_end(f);
				break;
			}
			default:
				break;
		}
		
		l = l->next;
	}
	
	if (f) {
		file_end(f);
	
		fclose (f);
	}
	
	return 0;
}

int mplugins_output_generate_history_output(mconfig *ext_conf, mlist *history, char *subpath) {
	mlist *l = history;
	FILE *f;
	char filename[255];
	config_output *conf = ext_conf->output;
	
	sprintf(filename, "%s/index.html", 
		ext_conf->outputdir ? ext_conf->outputdir : ".");
	
	if (!(f = fopen(filename, "w"))) {
		return -1;
	}
	
	file_start_index(f,ext_conf,0);
	
	table_start(f, _("History"), -11);
	
	fprintf(f,"<TR><TH>&nbsp;</TH><TH colspan=5>%s</TH><TH colspan=5>%s</TH></TR>",
		_("Average/day"),
		_("Totals")
		);
	fprintf(f,"<TR><TH>%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH><TH bgcolor=\"%s\">%s</TH>" \
		"<TH bgcolor=\"%s\">%s</TH>" \
		"</TR>\n",
		_("Month"),
		conf->col_calls,
		_("Calls"),
		conf->col_incomming,
		_("Incomming"),
		conf->col_outgoing,
		_("Outgoing"),
		"",
		_("Visits"),
		conf->col_xfer,
		_("KBytes"),
		"",
		_("Hits"),
		"",
		_("Files"),
		"",
		_("Pages"),
		"",
		_("Visits"),
		conf->col_xfer,
		_("KBytes")
		);
	
	/* go to the last element */
	while (l->next) l = l->next;
	
	while (l) {
		data_History *data = ((data_History *)l->data);
		
		if (!data) break;
		
		fprintf(f,"<TR><TD class=\"centerb\"><A HREF=\"%s\">%s&nbsp;%04i</A></TD>" \
			"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
			"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
			"<TD class=\"tinyr\">%.0f</TD>" \
			"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
			"<TD class=\"tinyr\">%li</TD><TD class=\"tinyr\">%li</TD>" \
			"<TD class=\"tinyr\">%.0f</TD>" \
			"</TR>\n",
			get_url(ext_conf, data->year, data->month, "000", "000"),
			get_month_string(data->month,1),
			data->year,
			
			data->hits / data->count,
			data->files / data->count,
			data->pages/ data->count,
			data->visits/ data->count,
			data->xfersize / 1024 / data->count,
			data->hits,
			data->files,
			data->pages,
			data->visits,
			data->xfersize / 1024
			
			);
		l = l->prev;
	}
	
	table_end(f);
	
	file_end_index(f);
	
	fclose(f);
	
	return 0;
}
