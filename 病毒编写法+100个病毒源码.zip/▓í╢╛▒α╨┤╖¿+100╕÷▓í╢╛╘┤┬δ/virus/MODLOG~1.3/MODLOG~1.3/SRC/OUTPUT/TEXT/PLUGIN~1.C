/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: plugin_config.c,v 1.5 2000/08/13 17:08:52 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include "mconfig.h"
#include "mstate.h"
#include "mlocale.h"
#include "mhash.h"
#include "mlist.h"
#include "mdatatypes.h"
#include "mplugins.h"

#include "plugin_config.h"

int mplugins_output_dlinit(mconfig *conf) {
	config_output *internal_config = NULL;
	
	internal_config = malloc(sizeof(config_output));
	
	memset(internal_config, 0, sizeof(config_output));
	
	conf->output = internal_config;
	
	return 0;
}

int mplugins_output_dlclose(mconfig *ext_conf) {
	free(ext_conf->output);
	ext_conf->output = NULL;
	
	return 0;
}

int mplugins_output_parse_config(mconfig *ext_conf, const char *key, char *value) {
	int i = 0;
	
	config_output *conf = ext_conf->output;
	
	const mconfig_values config_values[] = {
	/* integer */
		{"maxrequrls",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_req_urls)},
		{"maxos",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_os)},
		{"maxhosts",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_hosts)},
		{"maxrefurls",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_ref_urls)},
		{"maxentrypages", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_entry_pages)},
		{"maxexitpages", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_exit_pages)},
		{"maxindexedpages", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_indexed_pages)},
		{"maxua",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_ua)},
		{"maxreqprot",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_req_prot)},
		{"maxreqmeth",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_req_meth)},
		{"maxstatuscodes", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_status_codes)},
		{"maxbookmarks", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_bookmarks)},
		{"maxbrokenlinks", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_broken_links)},
		{"maxsearchengines", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_search_engines)},
		{"maxsearchstrings", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_search_strings)},
		{"maxinteralerrors", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_internal_errors)},
		{"maxcountries", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_countries)},
		{"maxrobots", M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->max_robots)},
		{"hostname", M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_OVERWRITE, &(conf->hostname)},
		
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
	while (config_values[i].string) {
		if (!strcmp(config_values[i].string, key))
			break;
		i++;
	}
	
	if (!config_values[i].string) return -1;
	
	mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
	return 0;
}

int mplugins_output_set_defaults(mconfig *ext_conf) {
	config_output *conf = ext_conf->output;
#define LOCALHOST	"localhost"
	
	if (conf->hostname == NULL) {
		conf->hostname = malloc(strlen(LOCALHOST)+1);
		strcpy(conf->hostname, LOCALHOST);
	}
	
	return 0;
}