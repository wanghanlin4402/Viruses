/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: webdatatypes.c,v 1.2 2000/10/15 19:14:01 jk Exp $
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#ifdef HAVE_LIBZ
#include <zlib.h>
#else 
#include "zlibwrapper.h"
#endif

#include "webdatatypes.h"

/* begin of Split */

int Split_write(gzFile *f, void *d) {
	return 0;
}

int Split_destroy(void *d) {
	data_Split *data = d;
	
	if (data->string != NULL)	free(data->string);
	if (data->match != NULL)	pcre_free(data->match);
	if (data != NULL)	free(data);
	
	return 0;
}

int Split_setdata(data_Split *data, int field, const char *match, const char *dest) {
	const char *errstr;
	int errofs;
	data->string = malloc(strlen(dest)+1);
	strcpy(data->string, dest);
	
	data->match	= pcre_compile(match, 0, &errstr, &errofs, NULL);
	
	data->count	= 0;
	data->type	= field;
	
	if (data->match == NULL) {
		fprintf(stderr, "%s.%d: regex compilation error: %s\n", __FILE__, __LINE__, errstr);
		return -1;
	}
	
	return 0;
}

int Split_read(void *data, gzFile *f) {
	return 0;
}

int Split_append(void *d, void *s) {
	return 0;
}

void *Split_copy(void *d) {
	return NULL;
}

data_Split *Split_init() {
	data_Split *data = malloc(sizeof(data_Split));
	
	/* functions */
	data->destructor	= Split_destroy;
	data->write		= Split_write;
	data->read		= Split_read;
	data->copy		= Split_copy;
	data->append		= Split_append;
	
	data->string	= NULL;
	data->match	= NULL;
	
	data->count	= 0;
	data->type	= 0;
	
	return data;
}

data_Split	*createSplit(int field, const char *match, const char *dest) {
	data_Split *data = Split_init();
	
	if (Split_setdata(data, field, match, dest)) {
		data->destructor(data);
		data = NULL;
	}
	
	return data;
}

/* end of Split */


/* begin of SubList */

int SubList_write(gzFile *f, void *d) {
	return 0;
}

int SubList_destroy(void *d) {
	data_SubList *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data->sublist != NULL) mlist_free(data->sublist);
	if (data != NULL) free(data);
	
	return 0;
}

int SubList_setdata(data_SubList *data, char *str) {
	data->string = malloc(strlen(str)+1);
	strcpy(data->string, str);
	
	data->sublist	= mlist_init();
	
	data->count	= 0;
	data->type	= 0;
	
	return 0;
}

int SubList_read(void *data, gzFile *f) {
	return 0;
}

int SubList_append(void *d, void *s) {
	return 0;
}

void *SubList_copy(void *d) {
	return NULL;
}

data_SubList *SubList_init() {
	data_SubList *data = malloc(sizeof(data_SubList));
	
	/* functions */
	data->destructor	= SubList_destroy;
	data->write		= SubList_write;
	data->read		= SubList_read;
	data->copy		= SubList_copy;
	data->append		= SubList_append;
	
	data->string	= NULL;
	data->sublist	= NULL;
	
	data->count	= 0;
	data->type	= 0;
	
	return data;
}



data_SubList *createSubList(char *group) {
	data_SubList *data = SubList_init();
	
	SubList_setdata(data, group);
	
	return data;
}

/* end of SubList */
