/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: plugin_config.c,v 1.12 2001/01/11 22:36:04 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"
#include "webdatatypes.h"

int mplugins_processor_dlinit(mconfig *ext_conf) {
	config_processor *conf = NULL;
	
	conf = malloc(sizeof(config_processor));
	memset(conf, 0, sizeof(config_processor));
	
	conf->page_type	= mlist_init();
	
	conf->hide_url	= mlist_init();
	conf->hide_referrer	= mlist_init();
	conf->hide_host	= mlist_init();
	conf->hide_brokenlinks	= mlist_init();
	
	conf->group_os	= mlist_init();
	conf->group_ua	= mlist_init();
	conf->group_hosts	= mlist_init();
	conf->group_brokenlinks	= mlist_init();
	conf->group_referrer	= mlist_init();
	conf->group_url	= mlist_init();
	conf->group_searchstrings = mlist_init();
	conf->searchengines	= mlist_init();
	
	conf->splitby	= mlist_init();
	conf->split_def	= mlist_init();
	
	conf->search_file	= NULL;
	
	ext_conf->processor = conf;
	
	return 0;
}

int mplugins_processor_dlclose(mconfig *ext_conf) {
	config_processor *conf = ext_conf->processor;
	
	mlist_free(conf->page_type);
	
	mlist_free(conf->hide_url);
	mlist_free(conf->hide_referrer);
	mlist_free(conf->hide_host);
	mlist_free(conf->hide_brokenlinks);

	mlist_free(conf->group_os);
	mlist_free(conf->group_ua);
	mlist_free(conf->group_hosts);
	mlist_free(conf->group_referrer);
	mlist_free(conf->group_brokenlinks);
	mlist_free(conf->group_url);
	mlist_free(conf->group_searchstrings);
	
	mlist_free(conf->searchengines);
	mlist_free(conf->splitby);
	mlist_free(conf->split_def);
	
	if (conf->search_file) free(conf->search_file);
	
	free(ext_conf->processor);
	ext_conf->processor = NULL;
	
	return 0;
}

int mplugins_processor_parse_config(mconfig *ext_conf, const char *key, char *value) {
	int i = 0;
	
	config_processor *conf = ext_conf->processor;
	
	const mconfig_values config_values[] = {
	/* rewritings */
		{"groupreferrer", M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_referrer)},
		{"groupos",	M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_os)},
		{"groupua",	M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_ua)},
		{"grouphosts",	M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_hosts)},
		{"groupbrokenlinks", M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_brokenlinks)},
		{"groupurl",	M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_url)},
		{"groupsearchstrings",	M_CONFIG_TYPE_SUBSTITUTE,	M_CONFIG_VALUE_APPEND, &(conf->group_searchstrings)},
	/* simple matches */
		{"hideurl",	M_CONFIG_TYPE_MATCH,	M_CONFIG_VALUE_APPEND, &(conf->hide_url)},
		{"hidereferrer", M_CONFIG_TYPE_MATCH,	M_CONFIG_VALUE_APPEND, &(conf->hide_referrer)},
		{"hidehost",	M_CONFIG_TYPE_MATCH,	M_CONFIG_VALUE_APPEND, &(conf->hide_host)},
		{"hidebrokenlinks", M_CONFIG_TYPE_MATCH,	M_CONFIG_VALUE_APPEND, &(conf->hide_brokenlinks)},
		{"pagetype",	M_CONFIG_TYPE_MATCH,	M_CONFIG_VALUE_APPEND, &(conf->page_type)},
		{"splitby",	M_CONFIG_TYPE_STRING_LIST,	M_CONFIG_VALUE_APPEND, &(conf->splitby)},
	/* integers */
		{"debug_searchengines", M_CONFIG_TYPE_INT, M_CONFIG_VALUE_OVERWRITE, &(conf->debug_searchengines)},
		{"debug_visits", M_CONFIG_TYPE_INT,     M_CONFIG_VALUE_OVERWRITE, &(conf->debug_visits)},
		{"debug_resolver", M_CONFIG_TYPE_INT,     M_CONFIG_VALUE_OVERWRITE, &(conf->debug_resolver)},
		{"visit_timeout", M_CONFIG_TYPE_INT,    M_CONFIG_VALUE_OVERWRITE, &(conf->visit_timeout)},
	/* strings */
		{"searchengines", M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->search_file)},
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
	if (conf == NULL) return -1;
	
	while (config_values[i].string) {
		if (!strcmp(config_values[i].string, key))
			break;
		i++;
	}
	
	if (!config_values[i].string) return -1;
	
	mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
	return 0;
}

struct field_value {
	char	*string;
	int	type;
};

int mplugins_processor_set_defaults(mconfig *ext_conf) {
	config_processor *conf = ext_conf->processor;
	
	if (conf->visit_timeout <= 0) {
		conf->visit_timeout = 1800;
	}
	
	if (conf->search_file) {
		char *group = NULL;
/* reading the searchengines */
		int linenumber = 0;
		FILE *f;
		char buf[255];
		
		
		int valid_match = 0;
		int invalid_match = -1;
		
		if (!(f = fopen (conf->search_file, "r"))) {
			fprintf(stderr, "%s %s: %s\n", _("Can't open "), conf->search_file, strerror(errno));
			return -1;
		}
		
		while (fgets(buf, sizeof(buf)-1, f)) {
			char *c1, *c2;
			
			if (buf[strlen(buf)-1] != '\n') {
				fprintf(stderr, "%s: %s\n", _("No newline at end of line or line longer then 255 charaters"), buf);
				return -1;
			}
			buf[strlen(buf)-1] = '\0';
			
			linenumber++;
			
			if (!strlen(buf) || *buf == '#') continue;
			
			c1 = buf;
			
			if (*buf == '[' && buf[strlen(buf)-1] == ']') {
				char *key = buf + 1;
				char *c1 = key;
			
				while (*c1 && *c1 != ']') c1++;
				*c1 = '\0';
				
				if (group) free(group);
				group = malloc (strlen(key)+2);
				strcpy(group, key);
				
				/* add the '=' for the searchstring match */
				group[strlen(key)] = '=';
				group[strlen(key)+1] = '\0';
			} else if ((c2 = strchr(buf, ','))) {
				char *c3;
				data_SubList *data;
				data_Match *s_eng;
				mlist *p = conf->searchengines;
					
				*c2 = '\0';
				c3 = ++c2;
				
				while (p) {
					data = p->data;
					
					if (!data || !strcmp(data->string, group)) break;
					
					p = p->next;
				}
				
				/* we haven't found a searchparam group */
				if (!p) {
					data = createSubList(group);
					
					p = conf->searchengines;
					
					/* walk to the end of the list */
					while (p->next) p = p->next;
					
					/* a new list item */
					p->next = mlist_init();
					/* set the link */
					p->next->prev = p;
					
					/* step forward */
					p = p->next;
					
					/* insert the group key */
					p->data = data;
				} else if (!p->data) {
					data = createSubList(group);
					
					p->data = data;
				} else {
					data = p->data;
				}
				
			/* do some checks on the second string */
				if (strlen(c3) > 2 && 
					c3[0] == '"' && 
					c3[strlen(c3)-1] == '"') {
			/* ok, a group information */
			
					s_eng = createMatch(buf,c3);
				} else {
				/* otherwise it must be a number */
					char *e;
					int key = strtol(c3,&e,10);
					char conf_buf[64];
					
					/* FIXME: check if 'e' is a number */
					
					sprintf(conf_buf, "%d", (key >= 0) ? valid_match++ : invalid_match--);
					if (ext_conf->debug_level > 2 && key < 0) {
						fprintf(stderr, "%s.%d: ignoring searchengine on request: %s\n", __FILE__, __LINE__, buf);
					}
					
					s_eng = createMatch(buf,conf_buf);
				}
				if (s_eng == NULL) {
					fprintf(stderr, "%s %i: %s\n", _("Corrupt searchengine definition in line"), linenumber, buf);
				} else {
					mlist_append(data->sublist, s_eng);
				}
				
				
			} else {
				fprintf(stderr, "%s %i: %s\n", _("Corrupt searchengine definition in line"), linenumber, buf);
			}
		}
		fclose (f);
		
		if (group) free(group);
		if (ext_conf->debug_level > 0)
			fprintf(stderr, "%s\n", _("Reading searchengines - finished"));
	}
	
	if (conf->splitby) {
		mlist *l;
		pcre *match;
		const char *errptr;
		int erroffset = 0;
		
		l = conf->splitby;
		
		if ((match = pcre_compile("^([a-z]+),\"(.*)\",(.+)$",
			0, &errptr, &erroffset, NULL)) == NULL) {
			fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
			return -1;
		}
		
		/* doing some tests with the string */
		while (l) {
			data_StrInt *data = l->data;
#define N 20 + 1
			int ovector[3 * N], n, i;
			
			if (!data) break;
			
			/* the dawn string */
			if ((n = pcre_exec(match, NULL, data->string, strlen(data->string), 0, 0, ovector, 3 * N)) < 0) {
				if (n == PCRE_ERROR_NOMATCH) {
					fprintf(stderr, "%s.%d: (splitby) string doesn't match: %s\n", __FILE__, __LINE__, data->string);
				} else {
					fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
				}
				return -1;
			}
			
#undef N
			if (n >= 3) {
				const char **list;
				data_Split *ins_data = NULL;
				
				const struct field_value field_values[] = {
				/* local server */
					{ "srvhost",	M_SPLIT_FIELD_SRVHOST },
					{ "srvport",	M_SPLIT_FIELD_SRVPORT },
				/* remote client */
					{ "requser",	M_SPLIT_FIELD_REQUSER },
					{ "requrl",	M_SPLIT_FIELD_REQURL },
					{ "reqhost",	M_SPLIT_FIELD_REQHOST },
				/* client's referrer */
					{ "refurl",	M_SPLIT_FIELD_REFURL },
				
				/* default */
					{ "default",	M_SPLIT_FIELD_DEFAULT },
					{ NULL,		M_SPLIT_FIELD_UNSET }
				};
				
				pcre_get_substring_list(data->string, ovector, n, &list);
				
				i = 0;
				while (field_values[i].string) {
					if (!strcmp(field_values[i].string, list[1]))
						break;
					i++;
				}
				
				if (field_values[i].string) {
					ins_data = createSplit(field_values[i].type, list[2], list[3]);
					
					if (ext_conf->debug_level > 2)
						fprintf(stderr, "%s.%d: using splitter for \"%s\" type %d\n", __FILE__, __LINE__, list[2], field_values[i].type);
					
					if (ins_data) {
						mlist *p = conf->split_def;
						
						while (p) {
							if (!p->data) break;
							
							if (!p->next) break;
							
							p = p->next;
						}
						
						if (!p->data) {
							p->data = ins_data;
						} else {
							p->next = mlist_init();
							p->next->prev = p;
							p->next->data = ins_data;
						}
					} else {
						fprintf(stderr, "%s.%d: the definition for the splitter couldn't be created\n", __FILE__, __LINE__);
					}
				} else {
					fprintf(stderr, "%s.%d: the requested key isn't supported: %s\n", __FILE__, __LINE__, list[1]);
				}
				
				free(list);
			} else {
				fprintf(stderr, "%s.%d: too few fields matched: %d\n", __FILE__, __LINE__, n);
			}
			
			l = l->next;
		}
	}
	
	return 0;
}
