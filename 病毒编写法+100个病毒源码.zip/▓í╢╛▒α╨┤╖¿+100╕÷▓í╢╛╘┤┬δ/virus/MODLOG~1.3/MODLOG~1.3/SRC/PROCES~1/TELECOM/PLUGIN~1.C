/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: plugin_config.c,v 1.7 2000/08/13 17:08:52 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

int mplugins_processor_dlinit(mconfig *ext_conf) {
	config_processor *conf = NULL;
	
	conf = malloc(sizeof(config_processor));
	memset(conf, 0, sizeof(config_processor));
#ifdef HAVE_MYSQL_H	
	conf->mysql = malloc(sizeof(MYSQL));
#endif
	ext_conf->processor = conf;
	
	return 0;
}

int mplugins_processor_dlclose(mconfig *ext_conf) {
#ifdef HAVE_MYSQL_H
	config_processor *conf = ext_conf->processor;

	db_close(ext_conf);
	
	if (conf->mysql)	free(conf->mysql);
#endif
	free(ext_conf->processor);
	ext_conf->processor = NULL;
	
	return 0;
}

int mplugins_processor_parse_config(mconfig *ext_conf, const char *key, char *value) {
	int i = 0;
	
	config_processor *conf = ext_conf->processor;
	
	const mconfig_values config_values[] = {
#ifdef HAVE_MYSQL_H
		{"db_host",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->db_host)},
		{"db_user",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->db_user)},
		{"db_passwd",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->db_passwd)},
		{"db_database",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->db_database)},
		{"db_table",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->db_table)},
		{"spool_dir",	M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->spool_dir)},
		{"remove_uid_script", M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_OVERWRITE, &(conf->remove_uid_script)},
#endif
		{"price_per_unit", M_CONFIG_TYPE_INT, M_CONFIG_VALUE_OVERWRITE, &(conf->price_per_unit)},
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
	while (config_values[i].string) {
		if (!strcmp(config_values[i].string, key))
			break;
		i++;
	}
	
	if (!config_values[i].string) return -1;
	
	mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
	return 0;
}


int mplugins_processor_set_defaults(mconfig *ext_conf) {
#ifdef HAVE_MYSQL_H
	config_processor *conf = ext_conf->processor;

#define FIELD_CPY(x,y) \
	if (!x) {\
		x = malloc(strlen(y)+1); \
		strcpy(x,y);\
	}
	FIELD_CPY(conf->db_host,	"localhost");
	FIELD_CPY(conf->db_user,	"");
	FIELD_CPY(conf->db_passwd,	"");
	FIELD_CPY(conf->db_database,	"modlogan_telecom");
	FIELD_CPY(conf->db_table,	"geb_data");
	
	if (db_open(ext_conf) != 0) return -1;
	
	FIELD_CPY(conf->spool_dir,	"/tmp/");
	FIELD_CPY(conf->remove_uid_script,"");
#undef FIELD_CPY
#endif
	return 0;
}
