/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: db_mysql.c,v 1.2 2000/08/02 21:16:49 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>

#include "config.h"
#include "mrecord.h"
#include "mlocale.h"
#include "mconfig.h"
#include "mplugins.h"
#include "mstate.h"
#include "mdatatypes.h"
#include "misc.h"
#include "plugin_config.h"

#ifdef HAVE_MYSQL_H
int db_open(mconfig *ext_conf) {   
	config_processor *conf = ext_conf->processor;
	if (!(mysql_connect(conf->mysql, conf->db_host, conf->db_user, conf->db_passwd))) {
		fprintf(stderr, "%s", "Connection to mySQL failed.");
		fprintf(stderr, "%s", mysql_error(conf->mysql));
		return -1;
	}

	/* select database */   
	if (mysql_select_db(conf->mysql, conf->db_database)) {
		fprintf( stderr, "%s", "Selection of a database has failed.");
		fprintf( stderr, "%s", mysql_error(conf->mysql));
		return -1;
	}
	return 0;
}

int db_close(mconfig *ext_conf) {
	config_processor *conf = ext_conf->processor;
	
	mysql_close(conf->mysql);

	if (conf->res)		mysql_free_result(conf->res);
	return 0;
}

int db_query(mconfig *ext_conf, const char *str) {
	config_processor *conf = ext_conf->processor;
	
	if (conf->res) {
		mysql_free_result(conf->res);
		conf->res = NULL;
	}
	
	if (mysql_query(conf->mysql, str)) {
		fprintf(stderr,"Query (%s) failed: %s\n",str,mysql_error(conf->mysql));
	} else {
		conf->res = mysql_store_result(conf->mysql);
	}
	
	return (conf->res != NULL);
}

char **db_fetchrow(mconfig *ext_conf) {
	MYSQL_ROW row;
	config_processor *conf = ext_conf->processor;
	
	if (!conf->res) return NULL;
	if ((row = mysql_fetch_row(conf->res))) {
		return row;
	} else {
		return NULL;
	}
}

int insert_phone_data(mconfig *ext_conf, mlogrec *record) {
	char *query = malloc( sizeof(char) * 1024 );
	config_processor *conf = ext_conf->processor;
	int q_res = 0;
	struct tm *tm;
	mlogrec_telecom *rectel = record->ext;
	mlogrec_telecom_internal *recint = rectel->ext;
	
	tm = localtime(&(record->timestamp));
	
	sprintf(query, "INSERT INTO %s (datum, uhrzeit, rufende_nummer, " 
		"gespraechsdauer,gerufene_nummer,richtung,provider, einheiten,"
		"kostenstelle) "
		"values ('%04d-%02d-%02d','%02d:%02d:%02d',"
		"%s%s%s, '%02ld:%02ld:%02ld', %s%s%s, '%d',"
		"%s%s%s, %d, %s%s%s)",
		conf->db_table,
		tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
		tm->tm_hour, tm->tm_min, tm->tm_sec,
		*(rectel->calling_number) ? "'" : "", 
		*(rectel->calling_number) ? rectel->calling_number : "NULL", 
		*(rectel->calling_number) ? "'" : "", 
		rectel->duration / 3600,
		(rectel->duration % 3600) / 60,
		rectel->duration % 60,
		*(rectel->called_number) ? "'" : "", 
		*(rectel->called_number) ? rectel->called_number : "NULL", 
		*(rectel->called_number) ? "'" : "", 
		rectel->direction,
#if 0
		rectel->ext && recint->provider ? "'" : "", 
		rectel->ext && recint->provider ? recint->provider : "NULL", 
		rectel->ext && recint->provider ? "'" : "",
#else
		"'",
		rectel->ext && recint->provider ? recint->provider : "", 
		"'",
#endif
		rectel->ext && recint->units_to_pay ? recint->units_to_pay : 0,
		rectel->ext && recint->user_id ? "'" : "", 
		rectel->ext && recint->user_id ? recint->user_id : "NULL", 
		rectel->ext && recint->user_id ? "'" : ""
		);
	
#if 0
	fprintf(stderr, "%s\n", query);
#endif
	q_res = db_query(ext_conf, query);
	
	free(query);
	
	return q_res;
}

int pay_account(mconfig *ext_conf, char *uid, int units) {
	char str[255];
	char **r;
	double d = 0;
	char *loc;
	config_processor *conf = ext_conf->processor;
	
	if (!uid) return -1;
	
/* precheck */
	sprintf(str, "SELECT guthaben FROM user WHERE pin=%s",uid) ;
	if (db_query(ext_conf, str) && (r = db_fetchrow(ext_conf))) {
		loc = setlocale(LC_NUMERIC, "C");
		d = strtod(r[0],NULL);
		loc = setlocale(LC_NUMERIC, loc);
	
		if (d < 0) {
			fprintf(stderr, "Account of User '%s' is already empty\n", uid);
		}
	} else {
		fprintf(stderr, "User '%s' not found in DB\n", uid);
		return -1;
	}
	
/* FIXME: this one is hardcoded */
	d -= units * conf->price_per_unit / 100.0;
	
	loc = setlocale(LC_NUMERIC, "C");
	sprintf(str, "UPDATE user SET guthaben=\"%.2f\" WHERE pin=%s",
		d, uid);
	loc = setlocale(LC_NUMERIC, loc);
		
	if (db_query(ext_conf, str) == 0) {
		return -1;
	}
	
	return 0;
}

int check_account(mconfig *ext_conf, char *uid) {
	char str[255];
	int status = 0;
	char **r;
	double d;
	char *loc;
	
	if (!uid) return -1;
	
	sprintf(str, "SELECT guthaben FROM user WHERE pin=%s",uid) ;
	if (db_query(ext_conf, str) && (r = db_fetchrow(ext_conf))) {
		loc = setlocale(LC_NUMERIC, "C");
		d = strtod(r[0],NULL);
		loc = setlocale(LC_NUMERIC, loc);
	
		if (d <= 0) {
			status = 1;
		}
	} else {
		fprintf(stderr, "User '%s' not found in DB\n", uid);
		return -1;
	}
	
	return status;
}

void sub_processor(mconfig *ext_conf, mlogrec *record) {
	mlogrec_telecom *rectel = record->ext;
	config_processor *conf = ext_conf->processor;
	char *uid;
	
	insert_phone_data(ext_conf, record);

	if (rectel->ext && rectel->ext_type == M_RECORD_TYPE_TELECOM_INTERNAL) {
		mlogrec_telecom_internal *recint = rectel->ext;
		
		uid = recint->user_id;
		
		pay_account(ext_conf, uid, recint->units_to_pay);
		
		if (check_account(ext_conf, uid) == 1) {
			FILE *f;
			char *fn;
		
		/* 
		 * i don't really know how long a PID or a timestamp can be
		 * but 20 char's should be enough 
		 */
		 
			fn = malloc(strlen(conf->spool_dir) + strlen("/tkc_") + 20 + 20 + 1 + 5);
			sprintf(fn, "%s%s%ld_%d.job", conf->spool_dir, "/tkc_", time(NULL), getpid());
		
			if ((f = fopen(fn, "w")) == NULL) {
				fprintf(stderr, "Can't open job file (%s): %s\n", fn, strerror(errno));
				free(fn);
				return;
			}
		
			fprintf(f, "%s,%s\n", conf->remove_uid_script, uid);
		
			fclose(f);
			free(fn);
		
		}
	}
}
#else

void sub_processor(mconfig *ext_conf, mlogrec *record) {
	return;
}

#endif	
