/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mhash.c,v 1.7 2000/12/22 18:39:27 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "config.h"
#include "mlist.h"
#include "mhash.h"
#include "mdatatypes.h"

int mhash_unfold(mhash *h[], mlist *l ) {
	int i = 0;
	for ( i = 0; i < HASH_SIZE; i++) {
		if (h[i]->list) {
			mlist *hl;
			
			hl = h[i]->list;
			while (hl) {
				if (hl->data) {
					data_StrInt *data;
					data = ((data_StrInt *)hl->data)->copy(hl->data);
				
					mlist_insert(l, data);
				}
				hl = hl->next;
			}
		}
	}
	return 0;
}

int mhash_unfold_sorted_limited(mhash *h[], mlist *l, int count ) {
	int i, j, max;
	data_StrInt *data, *ins_data;
	
	for ( j = 0; j < count; j++) {
		data = NULL;
		
		max = 0;
		
		for ( i = 0; i < HASH_SIZE; i++) {
			if (h[i]->list) {
				mlist *hl;
			
				hl = h[i]->list;
				while (hl) {
					if (hl->data) {
						if (((data_StrInt *)hl->data)->count > max) {
							max = ((data_StrInt *)hl->data)->count;
							data = (data_StrInt *)hl->data;
						}
					}
					hl = hl->next;
				}
			}
		}
		
		if (data) {
			ins_data = data->copy(data);
			
			mlist_insert(l, ins_data);
		
			data->count = -data->count;
		}
	}
	
	for ( i = 0; i < HASH_SIZE; i++) {
		if (h[i]->list) {
			mlist *hl;
			
			hl = h[i]->list;
			while (hl) {
				if (hl->data) {
					if (((data_StrInt *)hl->data)->count < 0) {
						data = (data_StrInt *)hl->data;
						
						data->count = -data->count;
					}
				}
				hl = hl->next;
			}
		}
	}
	
	return 0;
}


int mhash_calc (char *str) {
	unsigned long i = 0;
	
	while (*str) 
		i = *str++ + 31 * i;
	
	return (i % HASH_SIZE);
}

mhash **mhash_init () {
	int i = 0;
	
	mhash **h;
	
	h = malloc(sizeof(mhash *) * HASH_SIZE);
	
	for (i = 0; i < HASH_SIZE; i++) {
		h[i] = malloc(sizeof(mhash));
		h[i]->list = mlist_init();
	}
	
	return h;
}

int mhash_free (mhash *h[]) {
	int i = 0;
	
	for (i = 0; i < HASH_SIZE; i++) {
		mlist_free(h[i]->list);
		free(h[i]);
	}
	free(h);
	
	return 0;
}

int mhash_insert(mhash *h[], void *data) {
	int ndx = 0;
	
	if (!((data_StrInt *)data)->string) return -1;
	
	ndx = mhash_calc(((data_StrInt *)data)->string);
	
	mlist_insert(h[ndx]->list, data);
	
	return 0;
}


int mhash_count(mhash *h[]) {
	int i, c = 0;
	if (!h) return 0;
	
	for ( i = 0; i < HASH_SIZE; i++) {
		c += mlist_count(h[i]->list);
	}
	
	return c;
}

void *mhash_get_data(mhash **h, const char *str) {
	int ndx;
	
	ndx = mhash_calc(str);
	
	return mlist_get_data(h[ndx]->list, str);
}

int mhash_in_hash(mhash **h, const char *str) {
	int ndx;
	
	ndx = mhash_calc(str);
	
	return mlist_in_list(h[ndx]->list, str);
}