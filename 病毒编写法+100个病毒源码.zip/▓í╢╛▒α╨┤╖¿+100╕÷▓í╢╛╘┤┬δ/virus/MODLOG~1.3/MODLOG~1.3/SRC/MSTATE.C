/* 
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mstate.c,v 1.22 2000/12/22 18:41:19 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#include "config.h"
#ifdef HAVE_LIBZ
#include <zlib.h>
#else 
#include "zlibwrapper.h"
#endif

#include "mlist.h"
#include "mstate.h"
#include "mdatatypes.h"
#include "mlocale.h"

#define STATE_FILE_VERSION	"0.5"

int mstate_is_section_end(const char *s) {
	if (!strncmp(s, "# -e- ", 5)) {
		return 1;
	} else {
		return 0;
	}
}

mstate *mstate_init() {
	mstate *state = malloc(sizeof(mstate));
	
	state->year		= 0;
	state->month		= 0;
	state->timestamp	= 0;
	
	state->ext		= NULL;
	state->ext_type		= M_STATE_TYPE_UNSET;
	
	return state;
}

void mstate_free(mstate *state) {
	if (!state) return;
	
	if (state->ext) {
		switch(state->ext_type) {
		case M_STATE_TYPE_WEB:
			mstate_free_web(state->ext);
			break;
		case M_STATE_TYPE_TELECOM:
			mstate_free_telecom(state->ext);
			break;
		case M_STATE_TYPE_UNSET:
			break;
		default:
			fprintf(stderr, "%s.%d: unknown substate type %d\n", __FILE__, __LINE__, state->ext_type);
		}
	}
	
	free(state);
}

mstate_web *mstate_init_web() {
	int i;
	
	mstate_web *state = malloc(sizeof(mstate_web));
	
	state->allvisittime	= 0;
	state->allvisitlength	= 0;
	
	state->visit_list	= mlist_init();
	
	state->exit_pages	= mhash_init();
	state->entry_pages	= mhash_init();
	state->indexed_pages	= mhash_init();
	state->os_hash		= mhash_init();
	state->ua_hash		= mhash_init();
	state->req_url_hash	= mhash_init();
	state->req_prot_hash	= mhash_init();
	state->req_meth_hash	= mhash_init();
	state->status_hash	= mhash_init();
	state->host_hash	= mhash_init();
	state->ref_url_hash	= mhash_init();
	state->robots		= mhash_init();
	state->bookmarks	= mhash_init();
	state->status_internal_error = mhash_init();
	state->status_missing_file = mhash_init();
	state->searchstring	= mhash_init();
	state->searchsite	= mhash_init();
	state->country_hash	= mhash_init();
	
	for (i = 0; i < 24; i++) {
		state->hours[i].hits = 0;
		state->hours[i].files = 0;
		state->hours[i].pages = 0;
		state->hours[i].visits = 0;
		state->hours[i].hosts = 0;
		state->hours[i].xfersize = 0;
	}
	
	for (i = 0; i < 31; i++) {
		state->days[i].hits = 0;
		state->days[i].files = 0;
		state->days[i].pages = 0;
		state->days[i].visits = 0;
		state->days[i].hosts = 0;
		state->days[i].xfersize = 0;
	}
	
	return state;
}

void mstate_free_web(mstate_web *state) {
	if (!state) return;
	
	mhash_free(state->os_hash);
	mhash_free(state->ua_hash);
	mhash_free(state->req_prot_hash);
	mhash_free(state->req_meth_hash);
	mhash_free(state->status_hash);
	mhash_free(state->host_hash);
	mhash_free(state->req_url_hash);
	mhash_free(state->ref_url_hash);
	mhash_free(state->bookmarks);
	mhash_free(state->robots);
	mhash_free(state->status_internal_error);
	mhash_free(state->status_missing_file);
	mhash_free(state->searchstring);
	mhash_free(state->searchsite);
	mhash_free(state->country_hash);
	mhash_free(state->indexed_pages);
	mhash_free(state->exit_pages);
	mhash_free(state->entry_pages);
	
	mlist_free(state->visit_list);
	
	free(state);
}

mstate_telecom *mstate_init_telecom() {
	int i;
	
	mstate_telecom *state = malloc(sizeof(mstate_telecom));
	
	state->called_numbers	= mhash_init();
	state->calling_numbers	= mhash_init();
	
	for (i = 0; i < 24; i++) {
		state->hours[i].incomming_calls = 0;
		state->hours[i].outgoing_calls = 0;
	}
	
	for (i = 0; i < 31; i++) {
		state->days[i].incomming_calls = 0;
		state->days[i].outgoing_calls = 0;
	}
	
	return state;
}

void mstate_free_telecom(mstate_telecom *state) {
	if (!state) return;
	
	mhash_free(state->called_numbers);
	mhash_free(state->calling_numbers);
	
	free(state);
}



int mstate_write_element_start(gzFile *f, const char *section, const char *str) {
	gzprintf(f, "# -b- -%s- %s --\n", section, str);
	
	return 0;
}

int mstate_write_element_end(gzFile *f, const char *section, const char *str) {
	gzprintf(f, "# -e- -%s- %s --\n", section, str);
	
	return 0;
}

int mhash_write(gzFile *f, mhash **h) {
	int i;

	for (i = 0; i < HASH_SIZE; i++) {
		if (h[i]->list) {
			mlist_write(f, h[i]->list);
		}
	}
	
	return 0;
}

int mstate_write (mconfig *conf, mstate *state, int _add_month, char *subpath) {
	gzFile *f;
	char filename[255];
	
	if (subpath) {
		sprintf(filename, "%s/%s/",
			conf->outputdir ? conf->outputdir : ".",
			subpath);
		mkdir(filename, 0755);
		
		if (_add_month == M_STATE_WRITE_DEFAULT) {
			sprintf(filename, "%s/%s/modlogan.state.gz", 
				conf->outputdir ? conf->outputdir : ".", 
				subpath);
		} else {
			sprintf(filename, "%s/%s/modlogan_%04d%02d.state.gz", 
				conf->outputdir ? conf->outputdir : ".", 
				subpath,
				state->year, state->month);
		}
	} else {
		if (_add_month == M_STATE_WRITE_DEFAULT) {
			sprintf(filename, "%s/modlogan.state.gz", 
				conf->outputdir ? conf->outputdir : ".");
		} else {
			sprintf(filename, "%s/modlogan_%04d%02d.state.gz", 
				conf->outputdir ? conf->outputdir : ".", 
				state->year, state->month);
		}
	}
	
	if (conf->debug_level > 1) {
		fprintf(stderr, "%s.%d: STATE-Filename: %s\n", __FILE__, __LINE__, filename);
	}
	
	if (!(f = gzopen(filename, "wb"))) {
		fprintf(stderr, "Can't open state-file %s: %s\n", filename, strerror(errno));
		return -1;
	}
	
	gzprintf(f, "# %s - %s\n", PACKAGE, STATE_FILE_VERSION);
	
	mstate_write_element_start(f, M_STATE_SECTION_GLOBAL,  M_STATE_SUMMARY);
	gzprintf(f, "%ld,%d,%d\n", state->timestamp,
		state->year, state->month);
	mstate_write_element_end(f, M_STATE_SECTION_GLOBAL,  M_STATE_SUMMARY);
	
	if (state->ext) {
		switch(state->ext_type) {
		case M_STATE_TYPE_WEB:
			mstate_write_web(conf, state->ext, f);
			break;
		case M_STATE_TYPE_TELECOM:
			mstate_write_telecom(conf, state->ext, f);
			break;
		default:
			fprintf(stderr, "%s.%d: unknown substate type\n", __FILE__, __LINE__);
		}
	}
	
	gzclose(f);
	
	return 0;
}

int mstate_write_web (mconfig *conf, mstate_web *state, gzFile *f) {
	int i;
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_ALLVISITLEN);
	gzprintf(f, "%ld\n", state->allvisitlength);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_ALLVISITLEN);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_ALLVISITTIME);
	gzprintf(f, "%ld\n", state->allvisittime);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_ALLVISITTIME);

	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_URL);
	mhash_write(f, state->req_url_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_URL);

	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_METHOD);
	mhash_write(f, state->req_meth_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_METHOD);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_PROTOCOL);
	mhash_write(f, state->req_prot_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_REQ_PROTOCOL);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_REF_URL);
	mhash_write(f, state->ref_url_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_REF_URL);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_OS);
	mhash_write(f, state->os_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_OS);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_USERAGENT);
	mhash_write(f, state->ua_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_USERAGENT);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_HOST);
	mhash_write(f, state->host_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_HOST);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_STATUS);
	mhash_write(f, state->status_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_STATUS);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_EXITPAGES);
	mhash_write(f, state->exit_pages);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_EXITPAGES);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_ENTRYPAGES);
	mhash_write(f, state->entry_pages);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_ENTRYPAGES);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_VISIT);
	mlist_write(f, state->visit_list);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_VISIT);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_COUNTRIES);
	mhash_write(f, state->country_hash);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_COUNTRIES);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_ROBOTS);
	mhash_write(f, state->robots);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_ROBOTS);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_SEARCHSITE);
	mhash_write(f, state->searchsite);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_SEARCHSITE);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_SEARCHSTRING);
	mhash_write(f, state->searchstring);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_SEARCHSTRING);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_INT_ERROR);
	mhash_write(f, state->status_internal_error);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_INT_ERROR);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_MISSING_FILE);
	mhash_write(f, state->status_missing_file);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_MISSING_FILE);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_BOOKMARKS);
	mhash_write(f, state->bookmarks);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_BOOKMARKS);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_INDEXED_PAGES);
	mhash_write(f, state->indexed_pages);
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_INDEXED_PAGES);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_HOURS);
	for (i = 0; i < 24; i++) {
		gzprintf(f, "%ld,%ld,%ld,%ld,%ld,%.0f\n",
			state->hours[i].hits,
			state->hours[i].files,
			state->hours[i].pages,
			state->hours[i].visits,
			state->hours[i].hosts,
			state->hours[i].xfersize
		);
	}
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_HOURS);
	
	mstate_write_element_start(f, M_STATE_SECTION_WEB, M_STATE_WEB_DAYS);
	for (i = 0; i < 31; i++) {
		gzprintf(f, "%ld,%ld,%ld,%ld,%ld,%.0f\n",
			state->days[i].hits,
			state->days[i].files,
			state->days[i].pages,
			state->days[i].visits,
			state->days[i].hosts,
			state->days[i].xfersize
		);
	}
	mstate_write_element_end(f, M_STATE_SECTION_WEB, M_STATE_WEB_DAYS);
	
	return 0;
}

int mstate_write_telecom (mconfig *conf, mstate_telecom *state, gzFile *f) {
	return 0;
}

char * mstate_getline (gzFile *f) {
	char *buffer;
	int buf_len = 256;
	int buf_inc = 128;
	
	buffer = malloc((buf_len+1) * sizeof(char));
	
	*buffer = '\0';

	if (!gzgets(f, buffer, buf_len-1)) {
		return buffer;
	}

	while (buffer[strlen(buffer)-1] != '\n') {
		buffer = realloc(buffer, (buf_len+buf_inc) * sizeof(char));
		
		if (!gzgets(f, buffer+strlen(buffer), buf_inc-1)) {
			break;
		}
		
		buf_len += buf_inc;
	}
	
	return buffer;
}

#define M_STATE_DATATYPE_UNSET	0
#define M_STATE_DATATYPE_HASH	1
#define M_STATE_DATATYPE_LONG	2
#define M_STATE_DATATYPE_LIST	3
#define M_STATE_DATATYPE_WEB_ARRAY 4

#define M_STATE_DATASUBTYPE_UNSET	0
#define M_STATE_DATASUBTYPE_STRINT	1
#define M_STATE_DATASUBTYPE_BROKENLINK	2
#define M_STATE_DATASUBTYPE_STR3INT	3
#define M_STATE_DATASUBTYPE_VISIT	4
#define M_STATE_DATASUBTYPE_WEB_ARRAY	5

int mstate_insert_value(void *dest, int type, int subtype, gzFile *f) {
	switch (type) {
		case M_STATE_DATATYPE_LONG: {
			int str = *(int *)(dest);
			char *buffer;
			
			buffer = mstate_getline(f);
			
			str = strtol(buffer, NULL, 10);
			
			*(int *)(dest) = str;
			
			free(buffer);
			buffer = mstate_getline(f);
			free(buffer);
			
			break;
		}
		case M_STATE_DATATYPE_WEB_ARRAY: {
			marray_web *str = (marray_web *)(dest);
			char *buffer;
			int errofs;
			const char *errptr;
#define N 20 + 1
			const char **list;
			int ovector[3 * N], n, i = 0;
			
			pcre *header_match = pcre_compile ("^([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+)$",
				0, &errptr, &errofs, NULL);
	
			while ((buffer = mstate_getline(f))) {
				if (mstate_is_section_end(buffer)) break;
				if ((n = pcre_exec(header_match, NULL, buffer, strlen(buffer), 0, 0, ovector, 3 * N)) < 0) {
					if (n == PCRE_ERROR_NOMATCH) {
						fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, buffer);
					} else {
						fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
					}
					free(buffer);
					return -1;
				}
		
				if (n >= 6) {
					pcre_get_substring_list(buffer, ovector, n, &list);
					
					str[i].hits = strtol(list[1], NULL, 10);
					str[i].files = strtol(list[2], NULL, 10);
					str[i].pages = strtol(list[3], NULL, 10);
					str[i].visits = strtol(list[4], NULL, 10);
					str[i].hosts = strtol(list[5], NULL, 10);
					str[i].xfersize = strtod(list[6], NULL);
					
					free(list);
				}
				free(buffer);
				i++;
			}
			pcre_free(header_match);
			
			break;
		}
		case M_STATE_DATATYPE_HASH: {
			switch(subtype) {
				case M_STATE_DATASUBTYPE_STRINT: {
					data_StrInt *data = StrInt_init();
					mhash **hash = *(mhash ***) dest;
					
					while ((data->read(data, f) == 0)) {
						if (!data->string) {
							data->destructor(data);
							data = NULL;
							break;
						}
						
						mhash_insert(hash, data);
						data = StrInt_init();
					}
					
					if (data)
						data->destructor(data);
					
					break;
				}
				case M_STATE_DATASUBTYPE_STR3INT: {
					data_Str3Int *data = Str3Int_init();
					mhash **hash = *(mhash ***) dest;
					
					while ((data->read(data, f) == 0)) {
						if (!data->string) {
							data->destructor(data);
							data = NULL;
							break;
						}
						
						mhash_insert(hash, data);
						data = Str3Int_init();
					}
					
					if (data)
						data->destructor(data);
					break;
				}
				case M_STATE_DATASUBTYPE_BROKENLINK: {
					data_BrokenLink *data = BrokenLink_init();
					mhash **hash = *(mhash ***) dest;
					
					while ((data->read(data, f) == 0)) {
						if (!data->string) {
							data->destructor(data);
							data = NULL;
							break;
						}
						
						mhash_insert(hash, data);
						data = BrokenLink_init();
					}
					if (data)
						data->destructor(data);
					break;
				}
				default:
					fprintf(stderr, "%s.%d: unknown datasubtype %d\n", __FILE__, __LINE__, subtype);
					return -1;
			}
			break;
		}
		
		case M_STATE_DATATYPE_LIST: {
			switch(subtype) {
				case M_STATE_DATASUBTYPE_STRINT: {
					data_StrInt *data = StrInt_init();
					mlist *list = *(mlist **) dest;
					
					while ((data->read(data, f) == 0)) {
						if (!data->string) {
							data->destructor(data);
							data = NULL;
							break;
						}
						
						mlist_insert(list, data);
						data = StrInt_init();
					}
					
					if (data)
						data->destructor(data);
					break;
				 }
				 case M_STATE_DATASUBTYPE_VISIT: {
					data_Visit *data = Visit_init();
					mlist *list = *(mlist **) dest;
					
					while ((data->read(data, f) == 0)) {
						if (!data->string) {
							data->destructor(data);
							data = NULL;
							break;
						}
						
						mlist_insert(list, data);
						data = Visit_init();
					}
					
					if (data)
						data->destructor(data);
					
					break;
				 }
				 default:
					fprintf(stderr, "%s.%d: unknown datasubtype %d\n", __FILE__, __LINE__, subtype);
					return -1;
			}
			break;
		}
		
		default:
			return -1;
	}
	return 0;
}

typedef struct {
	char	*string;
	int	type;
	int	subtype;
	void	*dest;
} mstate_values;

int mstate_read_web (mconfig *conf, mstate_web *state, gzFile *f, char *key) {
	int i = 0;
	
	const mstate_values state_values[] = {
		{ M_STATE_WEB_ALLVISITTIME, M_STATE_DATATYPE_LONG, M_STATE_DATASUBTYPE_UNSET,	&(state->allvisittime) },
		{ M_STATE_WEB_ALLVISITLEN, M_STATE_DATATYPE_LONG, M_STATE_DATASUBTYPE_UNSET,	&(state->allvisitlength) },
		{ M_STATE_WEB_REQ_URL,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->req_url_hash) },
		{ M_STATE_WEB_REQ_METHOD, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->req_meth_hash) },
		{ M_STATE_WEB_REQ_PROTOCOL, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->req_prot_hash) },
		{ M_STATE_WEB_REF_URL,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->ref_url_hash) },
		{ M_STATE_WEB_OS,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STR3INT,	&(state->os_hash) },
		{ M_STATE_WEB_USERAGENT, M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STR3INT,	&(state->ua_hash) },
		{ M_STATE_WEB_HOST,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STR3INT,	&(state->host_hash) },
		{ M_STATE_WEB_STATUS,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->status_hash) },
		{ M_STATE_WEB_EXITPAGES, M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->exit_pages) },
		{ M_STATE_WEB_ENTRYPAGES, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->entry_pages) },
		{ M_STATE_WEB_VISIT,	M_STATE_DATATYPE_LIST,	M_STATE_DATASUBTYPE_VISIT,	&(state->visit_list) },
		{ M_STATE_WEB_HOURS,	M_STATE_DATATYPE_WEB_ARRAY, M_STATE_DATASUBTYPE_STRINT,	&(state->hours) },
		{ M_STATE_WEB_DAYS,	M_STATE_DATATYPE_WEB_ARRAY, M_STATE_DATASUBTYPE_STRINT,	&(state->days) },
		{ M_STATE_WEB_COUNTRIES, M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STR3INT,	&(state->country_hash) },
		{ M_STATE_WEB_ROBOTS,	M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->robots) },
		{ M_STATE_WEB_SEARCHSITE, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->searchsite) },
		{ M_STATE_WEB_SEARCHSTRING, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->searchstring) },
		{ M_STATE_WEB_INT_ERROR, M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_BROKENLINK,	&(state->status_internal_error) },
		{ M_STATE_WEB_MISSING_FILE, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_BROKENLINK, &(state->status_missing_file) },
		{ M_STATE_WEB_BOOKMARKS, M_STATE_DATATYPE_HASH,	M_STATE_DATASUBTYPE_STRINT,	&(state->bookmarks) },
		{ M_STATE_WEB_INDEXED_PAGES, M_STATE_DATATYPE_HASH, M_STATE_DATASUBTYPE_STRINT,	&(state->indexed_pages) },
		
		{ NULL, M_STATE_DATATYPE_UNSET, M_STATE_DATASUBTYPE_UNSET, NULL}
	};

	while (state_values[i].string) {
		if (!strcmp(state_values[i].string, key))
			break;
		i++;
	}

	if (!state_values[i].string) return -1;
	
	if (mstate_insert_value(state_values[i].dest, state_values[i].type, state_values[i].subtype, f)) {
		return -1;
	}
	
	return 0;
}

int mstate_read_telecom (mconfig *conf, mstate_telecom *state, gzFile *f, char *subsection) {
	return 0;
}

int mstate_read_global (mconfig *conf, mstate *state, gzFile *f, char *subsection) {
	char *buffer;
	int errofs;
	const char *errptr;
#define N 20 + 1
	const char **list;
	int ovector[3 * N], n, i = 0;
			
	pcre *header_match = pcre_compile ("^([0-9]+),([0-9]+),([0-9]+)$",
		0, &errptr, &errofs, NULL);
	
	while ((buffer = mstate_getline(f))) {
		if (mstate_is_section_end(buffer)) break;
		if ((n = pcre_exec(header_match, NULL, buffer, strlen(buffer), 0, 0, ovector, 3 * N)) < 0) {
			if (n == PCRE_ERROR_NOMATCH) {
				fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, buffer);
			} else {
				fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
			}
			free(buffer);
			return -1;
		}
		
		if (n >= 3) {
			pcre_get_substring_list(buffer, ovector, n, &list);
					
			state->timestamp = strtol(list[1], NULL, 10);
			state->year = strtol(list[2], NULL, 10);
			state->month = strtol(list[3], NULL, 10);
			
			free(list);
		}
		free(buffer);
		i++;
	}
	pcre_free(header_match);
	
	free(buffer);
	return 0;
}

int mstate_read (mconfig *conf, mstate *state, int year, int month, char *subpath) {
	gzFile  *f;
	char *buffer, cmpbuf[255];
	char filename[255];
	pcre *header_match = NULL;
	const char *errptr;
	int errofs = 0;
#define N 20 + 1
	const char **list;
	int ovector[3 * N], n;
	
	sprintf(cmpbuf, "# %s - %s\n", PACKAGE, STATE_FILE_VERSION);
	
	if (year == 0 || month == 0) {
		sprintf(filename, "%s%s%s/modlogan.state%s", 
			conf->outputdir ? conf->outputdir : ".", 
			subpath ? "/" : "",
			subpath ? subpath : "",
			".gz");
	} else {
		sprintf(filename, "%s%s%s/modlogan_%04d%02d.state%s", 
			conf->outputdir ? conf->outputdir : ".", 
			subpath ? "/" : "",
			subpath ? subpath : "",
			year, month,
			".gz");
	}
	
	if (!(f = gzopen(filename, "rb"))) {
		if (conf->debug_level > 1)
			fprintf(stderr, "%s.%d: %s: %s\n", __FILE__, __LINE__, _("Can't open state file"), strerror(errno));
		return -1;
	}
	
	buffer = mstate_getline(f);
	
	if (strcmp(buffer, cmpbuf)) {
		fprintf(stderr, "%s.%d: %s: \n%s -> %s", __FILE__, __LINE__, _("state file header doesn't match"), buffer, cmpbuf);
		free(buffer);
		return -1;
	}
	free(buffer);
	
	header_match = pcre_compile ("^# -([be])- -([a-z]+)- ([a-z_]+) --$",
		0, &errptr, &errofs, NULL);
	
	while ((buffer = mstate_getline(f))) {
		if (!*buffer) {
			free(buffer);
			break;
		}
		if ((n = pcre_exec(header_match, NULL, buffer, strlen(buffer), 0, 0, ovector, 3 * N)) < 0) {
			if (n == PCRE_ERROR_NOMATCH) {
				fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, buffer);
			} else {
				fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
			}
			free(buffer);
			return -1;
		}
		
		if (n >= 3) {
			char header_type = '\0';
			char *section_name, *subsection_name;
			pcre_get_substring_list(buffer, ovector, n, &list);
			
			header_type = *list[1];
			
			if (header_type == 'b') {
			
				section_name = (char *)list[2];
				
				subsection_name = (char *)list[3];
			
				if (strcmp(section_name, M_STATE_SECTION_WEB) == 0) {
					if (state->ext) {
						if (state->ext_type != M_STATE_TYPE_WEB) {
							return -1;
						}
					} else {
						state->ext = mstate_init_web();
						state->ext_type = M_STATE_TYPE_WEB;
					}
				
					mstate_read_web(conf, state->ext, f, subsection_name);
				} else if (strcmp(section_name, M_STATE_SECTION_TELECOM) == 0) {
					if (state->ext) {
						if (state->ext_type != M_STATE_TYPE_WEB) {
							return -1;
						}
					} else {
						state->ext = mstate_init_web();
						state->ext_type = M_STATE_TYPE_WEB;
					}
				
					mstate_read_telecom(conf, state->ext, f, subsection_name);
				} else if (strcmp(section_name, M_STATE_SECTION_GLOBAL) == 0) {
					mstate_read_global(conf, state, f, subsection_name);
				} else {
					printf("--><--\n");
				}
			}
			free(list);
		} else {
			printf("-->\n");
		}
		
		free(buffer);
	}
	
	gzclose(f);
	
	return 0;
}