/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: parse.c,v 1.3 2000/07/23 13:17:53 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

int parse_timestamp(mconfig *ext_conf, const char *str, mlogrec *record) {
#define N 20 + 1
	int ovector[3 * N], n;
	char buf[10];
	struct tm tm;
	config_input *conf = ext_conf->input;
	
	if ((n = pcre_exec(conf->match_timestamp, conf->match_timestamp_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	/* everything has matched, take the different pieces and be happy :) */
	pcre_copy_substring(str, ovector, n, 1, buf, sizeof(buf));
	tm.tm_mday = strtol(buf, NULL, 10);
	
	pcre_copy_substring(str, ovector, n, 2, buf, sizeof(buf));
	tm.tm_mon = strtol(buf, NULL, 10)-1;
	
	pcre_copy_substring(str, ovector, n, 3, buf, sizeof(buf));
	tm.tm_year = strtol(buf, NULL, 10);
	/* Y2K fix */
	if (tm.tm_year < 70) tm.tm_year += 100;
	if (tm.tm_year > 1900) tm.tm_year -= 1900;
	
	pcre_copy_substring(str, ovector, n, 4, buf, sizeof(buf));
	tm.tm_hour = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 5, buf, sizeof(buf));
	tm.tm_min = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 6, buf, sizeof(buf));
	tm.tm_sec = strtol(buf, NULL, 10);
	
	record->timestamp = mktime (&tm);
	
	return 0;
#undef  N
}

int parse_duration(mconfig *ext_conf, const char *str, mlogrec_telecom *record) {
#define N 20 + 1
	int ovector[3 * N], n;
	char buf[10];
	config_input *conf = ext_conf->input;
	
	if ((n = pcre_exec(conf->match_duration, conf->match_duration_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	pcre_copy_substring(str, ovector, n, 1, buf, sizeof(buf));
	record->duration = strtol(buf, NULL, 10) * 60 * 60;
	
	pcre_copy_substring(str, ovector, n, 2, buf, sizeof(buf));
	record->duration += strtol(buf, NULL, 10) * 60;
	
	pcre_copy_substring(str, ovector, n, 3, buf, sizeof(buf));
	record->duration += strtol(buf, NULL, 10);
	
	return 0;
#undef  N
}

int parse_record_pcre(mconfig *ext_conf, mlogrec *record, char *_buffer) {
#define N 20 + 1
	const char **list;
	int ovector[3 * N], n;
	config_input *conf = ext_conf->input;
	mlogrec_telecom *rectel = NULL; 
	mlogrec_telecom_internal *recint = NULL;
	
	record->ext_type = M_RECORD_TYPE_TELECOM;
	record->ext = mrecord_init_telecom();
	
	rectel = record->ext;
	
	if (rectel == NULL) return -1;

/* parse the record */	
	if ((n = pcre_exec(conf->match_line, conf->match_line_extra, _buffer, strlen(_buffer), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _buffer);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	if (n >= 8) {
		int i;
		char *c;
		
		pcre_get_substring_list(_buffer, ovector, n, &list);
		
		parse_timestamp(ext_conf, list[1], record);
		i = strtol(list[8], NULL, 10);
		rectel->direction = (i == 1) ? M_RECORD_TELECOM_DIRECTION_IN : M_RECORD_TELECOM_DIRECTION_OUT;
		
		if (rectel->direction == M_RECORD_TELECOM_DIRECTION_IN) {
			rectel->calling_number = malloc(strlen((char *)list[6])+1);
			strcpy(rectel->calling_number, (char *)list[6]);
			rectel->called_number = malloc(strlen((char *)list[3])+1);
		/* strip leading whitespaces */
			c = (char *)list[3];
			while (*c && *c == ' ') c++;
			strcpy(rectel->called_number, c);
		} else {
			rectel->calling_number = malloc(strlen((char *)list[3])+1);
		/* strip leading whitespaces */
			c = (char *)list[3];
			while (*c && *c == ' ') c++;
			strcpy(rectel->calling_number, c);
			
			rectel->called_number = malloc(strlen((char *)list[6])+1);
			
			c = (char *)list[6];
			if (conf->split_provider) {
				if (rectel->ext) {
					recint = rectel->ext;
				} else {
					recint = mrecord_init_telecom_internal();
				}
				if (strncmp(c, "0100", 4) == 0) {	
					recint->provider = malloc(6 + 1);
					strncpy(recint->provider, c, 6);
					*(recint->provider+6) = '\0';
					c += 6;
					rectel->ext = recint;
					rectel->ext_type = M_RECORD_TYPE_TELECOM_INTERNAL;
				} else if (strncmp(c, "010", 3) == 0) {
					recint->provider = malloc(5 + 1);
					strncpy(recint->provider, c, 5);
					*(recint->provider+5) = '\0';
					c += 5;
					rectel->ext = recint;
					rectel->ext_type = M_RECORD_TYPE_TELECOM_INTERNAL;
				} else if (!rectel->ext) {
					mrecord_free_telecom_internal(recint);
					recint = NULL;
				}
			}
			
			strcpy(rectel->called_number, c);
		}
		
		if (*(list[5])) {
			parse_duration(ext_conf, list[5], rectel);
		}
		
		c = (char *)list[7];
		while (*c && *c == ' ') c++;
		
		if (*c) {
			if (rectel->ext) {
				recint = rectel->ext;
			} else {
				recint = mrecord_init_telecom_internal();
			}
			
			recint->units_to_pay = strtol(c, NULL, 10);
			
			rectel->ext = recint;
			rectel->ext_type = M_RECORD_TYPE_TELECOM_INTERNAL;
		}
		
		if (n >= 10) {
			if (*(list[10])) {
				if (rectel->ext) {
					recint = rectel->ext;
				} else {
					recint = mrecord_init_telecom_internal();
				}
			
				recint->user_id = malloc(strlen((char *)list[10])+1);
				strcpy(recint->user_id, (char *)list[10]);
			
				rectel->ext = recint;
				rectel->ext_type = M_RECORD_TYPE_TELECOM_INTERNAL;
			}
		}
		
		free(list);
	} else {
		fprintf(stderr, "%s.%d: Matched fields below minimum: %d\n", __FILE__, __LINE__, n);
		return -1;
	}
	
	return 0;
#undef  N
}

int get_line (mconfig *ext_conf) {
	config_input *conf = ext_conf->input;
	int newline = 1;
	
	if (!fgets(conf->buffer, conf->buf_len-1,conf->inputfile)) {
		newline = 0;
	}

	while (newline && conf->buffer[strlen(conf->buffer)-1] != '\n') {
		conf->buffer = realloc(conf->buffer, (conf->buf_len+conf->buf_inc) * sizeof(char));
		
		if (!fgets(conf->buffer+strlen(conf->buffer), conf->buf_inc-1,conf->inputfile)) {
			newline = 0;
		}
		
		conf->buf_len += conf->buf_inc;
	}
	
	return newline;
}

int mplugins_input_get_next_record(mconfig *ext_conf, mlogrec *record) {
	config_input *conf = ext_conf->input;
	
	if (record == NULL) return M_RECORD_EOF;

	if (!get_line(ext_conf)) return M_RECORD_EOF;

	if (parse_record_pcre(ext_conf, record, conf->buffer) == -1) 
		return M_RECORD_CORRUPT;

	return M_RECORD_NO_ERROR;
}
