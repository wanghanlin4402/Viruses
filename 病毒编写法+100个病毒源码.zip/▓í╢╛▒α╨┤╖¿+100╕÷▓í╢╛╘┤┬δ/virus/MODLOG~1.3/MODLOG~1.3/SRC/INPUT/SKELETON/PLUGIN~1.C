/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: plugin_config.c,v 1.1 2000/10/15 19:04:02 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

#warning THIS IS A INPUT PLUGIN SKELETON. CHANGE WHAT HAS TO BE CHANGED.

/* C: every comment that starts with 'C:' is a comment for this skeleton
 * only and should appear in your final plugin
 */
 
/* C: this code is taken from the squid plugin */

/* init the plugin */

int mplugins_input_dlinit(mconfig *ext_conf) {
	config_input *conf = NULL;
	const char *errptr;
	int erroffset = 0;

/* C: get the neccesary space */
	conf = malloc(sizeof(config_input));
	memset(conf, 0, sizeof(config_input));

/* C: set some defaults */	
	conf->inputfilename = NULL;
	
	conf->inputfile = stdin;
	
	conf->buf_len = 256;
	conf->buf_inc = 128;
	conf->buffer = malloc(conf->buf_len * sizeof(char));

/* C: compile the match */	
	if ((conf->match_squid = pcre_compile(
		/*timestamp  +msec        duration    client-ip   
		                                            status */
		"^([0-9]{9})\\.([0-9]{3}) ([ 0-9]{6}) (.+?) (.+?)/([0-9]{3}) "
		/* xfersize           url         hierarchy code
 		          req_meth          rfc931            type   */
		"([0-9]+) ([_a-zA-Z]+) (.+?) (.+?) (.+?)/(.+?) (.+?)$",
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	} 
	
	conf->match_squid_extra = pcre_study(conf->match_squid, 0, &errptr);
	if (errptr != NULL) {
		fprintf(stderr, "%s.%d: rexexp studying error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	}

/* C: connect the plugin config to the master config */	
	ext_conf->input = conf;
	
	return 0;
}

/* destructor */

int mplugins_input_dlclose(mconfig *ext_conf) {
	config_input *conf = ext_conf->input;

/* C: clean up everything you have opened, reserved */
	if (conf->inputfilename && strcmp(conf->inputfilename, "-")) {
		fclose(conf->inputfile);
	}
	
	free(conf->buffer);
	
	free(ext_conf->input);
	ext_conf->input = NULL;
	
	return 0;
}

int mplugins_input_parse_config(mconfig *ext_conf, const char *key, char *value) {
	int i = 0;
	
	config_input *conf = ext_conf->input;
	
/* C: add your config options here. the format of the struct: 
 * {"<name of the option>", <type>, <how to handle the further 
 * occurences of the same value>, <address of the pointer where 
 * the value should go to> }
 *
 * you only have the change config_values[] the rest is done in the
 * background (-> ./src/mconfig.c)
 */
	const mconfig_values config_values[] = {
		{"inputfile",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_OVERWRITE, &(conf->inputfilename)},
		
/* C: terminate the array of options */		
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
	while (config_values[i].string) {
		if (!strcmp(config_values[i].string, key))
			break;
		i++;
	}
	
	if (!config_values[i].string) return -1;
	
	mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
	return 0;
}


int mplugins_input_set_defaults(mconfig *ext_conf) {
	config_input *conf = ext_conf->input;

/* C: set some usefull defaults and do the stuff that has to be done at the
 * END of the config-process. this function is called when all configfiles
 * are successfully parsed. it's good place to open files here or the
 * compile regex on the fly (-> ./src/input/clf using the format-key)
 */
	
	if (conf->inputfilename && strcmp(conf->inputfilename, "-")) {
		if (!(conf->inputfile = fopen(conf->inputfilename, "r"))) {
			fprintf(stderr, "%s %s: %s\n", _("Can't open inputfile "), conf->inputfilename, strerror(errno));
			return -1;
		}
	}
	
	return 0;
}
