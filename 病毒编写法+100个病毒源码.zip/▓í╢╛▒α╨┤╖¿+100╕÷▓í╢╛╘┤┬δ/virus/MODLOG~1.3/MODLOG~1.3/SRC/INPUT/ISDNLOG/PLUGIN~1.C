/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: plugin_config.c,v 1.1 2000/07/06 18:02:06 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

int mplugins_input_dlinit(mconfig *ext_conf) {
	config_input *conf = NULL;
	const char *errptr;
	int erroffset = 0;
	
	conf = malloc(sizeof(config_input));
	memset(conf, 0, sizeof(config_input));
	
	conf->inputfilename = NULL;

	/* will be replaced by setdefaults if we have a real inputfilename */
	conf->inputfile = stdin;
	conf->buf_len = 256;
	conf->buf_inc = 128;
	conf->buffer = malloc(conf->buf_len * sizeof(char));
	
	if ((conf->match_line = pcre_compile(
		"^(.+?)\\|([+0-9]*)\\s*\\|([+0-9]*)\\s*\\|\\s*([0-9]+)\\|\\s*([0-9]+)\\|\\s*([0-9]+)\\|\\s*([-0-9]+)\\|([OI])\\|\\s*([-0-9]+)\\|\\s*([0-9]+)\\|\\s*([0-9]+)\\|([0-9.]+)\\|([0-9])\\|([0-9])\\|([0-9.]+)\\|([A-Z]+)\\|([0-9.]+)\\|([-0-9]+)\\|$",
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	}
	
	if ((conf->match_timestamp = pcre_compile(
		"^([a-zA-Z]{3}) +([0-9]{1,2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4})", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	} 
	
	if ((conf->match_duration = pcre_compile(
		"^([0-9]{2}):([0-9]{2}):([0-9]{2})$",
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	}
	
	conf->match_line_extra = NULL;
	conf->match_timestamp_extra = NULL;
	conf->match_duration_extra = NULL;
	
	ext_conf->input = conf;
	
	return 0;
}

int mplugins_input_dlclose(mconfig *ext_conf) {
	config_input *conf = ext_conf->input;
	
	if (conf->inputfilename && strcmp(conf->inputfilename, "-")) {
		fclose(conf->inputfile);
	}
	
	if (conf->buffer) free(conf->buffer);
	
	free(ext_conf->input);
	ext_conf->input = NULL;
	
	return 0;
}

int mplugins_input_parse_config(mconfig *ext_conf, const char *key, char *value) {
	int i = 0;
	
	config_input *conf = ext_conf->input;
	
	const mconfig_values config_values[] = {
		{"inputfile",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_OVERWRITE, &(conf->inputfilename)},
		{"split_provider",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->split_provider)},
		
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
	while (config_values[i].string) {
		if (!strcmp(config_values[i].string, key))
			break;
		i++;
	}
	
	if (!config_values[i].string) return -1;
		
	mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
	return 0;
}


int mplugins_input_set_defaults(mconfig *ext_conf) {
	config_input *conf = ext_conf->input;

	if (conf->inputfilename && strcmp(conf->inputfilename, "-")) {
		if (!(conf->inputfile = fopen(conf->inputfilename, "r"))) {
			fprintf(stderr, "%s %s: %s\n", _("Can't open inputfile "), conf->inputfilename, strerror(errno));
			return -1;
		}
	}
	
	return 0;
}
