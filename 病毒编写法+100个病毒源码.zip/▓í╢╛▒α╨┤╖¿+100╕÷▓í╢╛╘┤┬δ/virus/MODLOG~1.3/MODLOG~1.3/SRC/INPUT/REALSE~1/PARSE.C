/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: parse.c,v 1.1 2000/08/27 21:44:49 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

/*#define DEBUG_PCRE 0*/

const char *short_month[] = {	"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
			"Jul", "Aug", "Sep", "Oct", "Nov", "Dec", NULL};

int parse_timestamp(mconfig *ext_conf, const char *str, mlogrec *record) {
#define N 20 + 1
	int ovector[3 * N], n, i;
	char buf[10];
	struct tm tm;
	config_input *conf = ext_conf->input;
	
	if ((n = pcre_exec(conf->match_timestamp, conf->match_timestamp_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	/* everything has matched, take the different pieces and be happy :) */
	pcre_copy_substring(str, ovector, n, 1, buf, sizeof(buf));
	tm.tm_mday = strtol(buf, NULL, 10);
	
	pcre_copy_substring(str, ovector, n, 2, buf, sizeof(buf));
	for (i = 0; short_month[i];i++) {
		if (!strcmp(buf, short_month[i])) {
			tm.tm_mon = i;
		}
	}
	
	pcre_copy_substring(str, ovector, n, 3, buf, sizeof(buf));
	tm.tm_year = strtol(buf, NULL, 10)-1900;
	
	pcre_copy_substring(str, ovector, n, 4, buf, sizeof(buf));
	tm.tm_hour = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 5, buf, sizeof(buf));
	tm.tm_min = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 6, buf, sizeof(buf));
	tm.tm_sec = strtol(buf, NULL, 10);
	
	record->timestamp = mktime (&tm);
	
	return 0;
#undef  N
}

int parse_url(mconfig *ext_conf,const char *str, mlogrec_web *record) {
#define N 20 + 1
	int ovector[3 * N], n;
#ifdef DEBUG_INPUT
	int i;
#endif
	config_input *conf = ext_conf->input;
	const char **list;
	
	if ((n = pcre_exec(conf->match_url, conf->match_url_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	if (n >= 3) {
		/* everything has matched, take the different pieces and be happy :) */
		pcre_get_substring_list(str, ovector, n, &list);
	
		record->req_method = malloc(strlen((char *)list[1])+1);
		strcpy(record->req_method, (char *)list[1]);
		record->req_url = malloc(strlen((char *)list[2])+1);
		strcpy(record->req_url, (char *)list[2]);
		
		if (n >= 4) {
			if (strlen((char *)list[4])) {
				record->req_getvars = malloc(strlen((char *)list[4])+1);
				strcpy(record->req_getvars, (char *)list[4]);
			}
		}
			
		if (n >= 6) {
			record->req_protocol = malloc(strlen((char *)list[6])+1);
			strcpy(record->req_protocol, (char *)list[6]);
		}
#ifdef DEBUG_INPUT				
		for (i = 0; i < n ; i++) {
			printf("--> %d: %s\n", i, list[i]);
		}

		fprintf(stderr, "%s.%d: %s, %s, %s, %s\n", __FILE__, __LINE__, record->req_method, record->req_url, record->req_getvars, record->req_protocol);
#endif		
		free(list);
	} else {
		fprintf(stderr, "%s.%d: Matched fields below minimum: %d\n", __FILE__, __LINE__, n);
		return -1;
	}
	
	return 0;
#undef  N
}

int parse_record_pcre(mconfig *ext_conf, mlogrec *record, char *_buffer) {
#define N 20 + 1
	const char **list;
	int ovector[3 * N], n;
#ifdef DEBUG_PCRE
	int i;
#endif
	config_input *conf = ext_conf->input;
	mlogrec_web *recweb = NULL; 
/*
	mlogrec_web_extclf *recext = NULL; 
*/	
	record->ext_type = M_RECORD_TYPE_WEB;
	record->ext = mrecord_init_web();
	
	recweb = record->ext;
	
	if (recweb == NULL) return -1;
/*	
	recweb->ext = mrecord_init_web_extclf();
	recweb->ext_type = M_RECORD_TYPE_WEB_EXTCLF;
	
	recext = recweb->ext;
	
	if (recext == NULL) return -1;
*/
	if ((n = pcre_exec(conf->match_clf, conf->match_clf_extra, _buffer, strlen(_buffer), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _buffer);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	if (n == 17) {
		pcre_get_substring_list(_buffer, ovector, n, &list);
	/* 
	   1 - client-ip
	   2 - '-'
	   3 - '-'
	   4 - timestamp
	   5 - request
	   6 - status
	   7 - xfersize
	   8 - client info
	   9 - client uid
	   10 - statistics
	   11-16 - currently unknown
	*/	
		recweb->req_host = malloc(strlen((char *)list[1])+1);
		strcpy(recweb->req_host, (char *)list[1]);
	
		if (parse_timestamp(ext_conf, list[4], record) == -1) {
			free(list);
			return -1;
		}
	
		if (parse_url(ext_conf, list[5], recweb) == -1) {
			free(list);
			return -1;
		}
	
		recweb->req_status = strtol(list[6], NULL,10);
		recweb->xfersize = strtol(list[7], NULL,10);

		pcre_free(list);
	} else {
		fprintf(stderr, "%s.%d: Matched fields below minimum: %d\n", __FILE__, __LINE__, n);
		return -1;
	}

#ifdef DEBUG_PCRE
	pcre_get_substring_list(_buffer, ovector, n, &list);
	for (i = 0; i < n; i++) {
		printf("%d: %s\n", i, list[i]);
	}
	pcre_free(list);
#endif
	return 0;
#undef  N
}

int mplugins_input_get_next_record(mconfig *ext_conf, mlogrec *record) {
	int ret = 0;
	config_input *conf = ext_conf->input;
	
	if (!fgets(conf->buffer, conf->buf_len-1,conf->inputfile)) {
		return M_RECORD_EOF;
	}

	while (conf->buffer[strlen(conf->buffer)-1] != '\n') {
		conf->buffer = realloc(conf->buffer, (conf->buf_len+conf->buf_inc) * sizeof(char));
		
		if (!fgets(conf->buffer+strlen(conf->buffer), conf->buf_inc-1,conf->inputfile)) {
			return M_RECORD_EOF;
		}
		
		conf->buf_len += conf->buf_inc;
	}
	ret = parse_record_pcre(ext_conf, record, conf->buffer);

	return ret == -1 ? M_RECORD_CORRUPT : M_RECORD_NO_ERROR;
}
