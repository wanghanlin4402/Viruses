/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: parse.c,v 1.1 2001/01/11 22:40:29 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>

#include "mlocale.h"
#include "mplugins.h"
#include "mrecord.h"
#include "mdatatypes.h"
#include "misc.h"

#include "plugin_config.h"

int find_os (mconfig *ext_conf, char *str) {
	config_input *conf = ext_conf->input;
	mlist *l = conf->match_os;
	if (!str || !l) return 0;
	
	while (*str == ' ') str++;
	
	while (l) {
		data_Match *data = (data_Match *)l->data;
		
		if (data && strmatch(data->match, str)) {
#if 0
			printf("OS found: %s\n", str);
#endif
			return 1;
		}
		
		l = l->next;
	}
	
	return 0;
}

int find_ua (mconfig *ext_conf, char *str) {
	config_input *conf = ext_conf->input;
	mlist *l = conf->match_ua;
	if (!str || !l) return 0;
	
	while (*str == ' ') str++;
	
	while (l) {
		data_Match *data = (data_Match *)l->data;
		
		if (data && strmatch(data->match, str)) {
#if 0
			printf("UA found: %s\n", str);
#endif
			return 1;
		}
		
		l = l->next;
	}
	
	return 0;
}

int parse_timestamp(mconfig *ext_conf, const char *_date, const char *_time, mlogrec *record) {
#define N 20 + 1
	int ovector[3 * N], n;
	char buf[10];
	struct tm tm;
	config_input *conf = ext_conf->input;
	
	char *str = NULL;
	
	str = malloc(strlen(_date) + strlen(_time) + 2);
	strcpy(str, _date);
	strcat(str, " ");
	strcat(str, _time);
	
	if ((n = pcre_exec(conf->match_timestamp, conf->match_timestamp_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	pcre_copy_substring(str, ovector, n, 1, buf, sizeof(buf));
	tm.tm_year = strtol(buf, NULL, 10)-1900;
	pcre_copy_substring(str, ovector, n, 3, buf, sizeof(buf));
	tm.tm_mday = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 2, buf, sizeof(buf));
	tm.tm_mon = strtol(buf, NULL, 10)-1;
	
	pcre_copy_substring(str, ovector, n, 4, buf, sizeof(buf));
	tm.tm_hour = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 5, buf, sizeof(buf));
	tm.tm_min = strtol(buf, NULL, 10);
	pcre_copy_substring(str, ovector, n, 6, buf, sizeof(buf));
	tm.tm_sec = strtol(buf, NULL, 10);
	
	record->timestamp = mktime (&tm);
	
	return 0;
#undef  N
}

int parse_useragent(mconfig *ext_conf,const char *str, mlogrec_web_extclf *record) {
/* get user agent */
	char *pc1 = (char *)str, *pc3, *pc2 = (char *)str, *buf_copy;
	
	buf_copy = malloc(strlen(str)+1);
	strcpy(buf_copy, str);
	
	str = urlescape((char *)str);
	
	if ((pc3 = strchr(pc1, '(') )) {
		if (strstr(pc3, "compatible")) {
			int finished = 0;
			
			pc1 = pc2 = (pc3+1);
			
			while (!finished) {
				while (*pc2 && !(*pc2 == ';' || *pc2 == ')')) pc2++;
				if (!*pc2) {
					if (ext_conf->debug_level > 0)
						fprintf(stderr, "%s: '%s'\n", _("the 'Useragent' field of the logfile is incorrect"),buf_copy);
					free(buf_copy);
					return -1;
				} else if (*pc2 == ')') {
					finished = 1;
				}
				
				while (*pc1 == ' ') pc1++;
				
				*pc2 = '\0';
				if (!record->req_useragent && find_ua(ext_conf, pc1)) {
					record->req_useragent = malloc(pc2-pc1+1);
					strcpy(record->req_useragent, pc1);
				} else if (!record->req_useros && find_os(ext_conf, pc1)) {
					record->req_useros = malloc(pc2-pc1+1);
					strcpy(record->req_useros, pc1);
				}
				pc1 = ++pc2;
			}
			

		} else {
			int finished = 0;
			
			pc2 = pc3;

			*pc2 = '\0';
			
			if (!find_ua(ext_conf, pc1)) {
//				printf("UA- unknown: %s\n", pc4);
			}
			
			record->req_useragent = malloc(pc2-pc1+1);
			strcpy(record->req_useragent, pc1);
			
			pc1 = pc2 = (pc3+1);

			while (!finished) {
				while (*pc2 && !(*pc2 == ';' || *pc2 == ')')) pc2++;
				if (!*pc2) {
					if (ext_conf->debug_level > 0)
						fprintf(stderr, "%s: '%s'\n", _("the 'Useragent' field of the logfile is incorrect"),buf_copy);
					free(buf_copy);
					return -1;
				} else if (*pc2 == ')') {
					finished = 1;
				}

				while (*pc1 == ' ') pc1++;
				
				*pc2 = '\0';
								
				
				if (!record->req_useros && find_os(ext_conf, pc1)) {
					record->req_useros = malloc(strlen(pc1)+1);
					strcpy(record->req_useros, pc1);
				}
				pc1 = ++pc2;
			}
		}

#if 0
		if (!record->req_useragent) {
			printf("UA unknown: %s\n", pc4);
		}
		
		if (!record->req_useros) {
			printf("OS unknown: %s\n", pc4);
		}
#endif
	} else {
		record->req_useragent = malloc(strlen(str)+1);
		strcpy(record->req_useragent, str);
	}
	
	free(buf_copy);
	
	return 0;
}

int parse_referrer(mconfig *ext_conf,const char *str, mlogrec_web_extclf *record) {
#define N 20 + 1
	int ovector[3 * N], n;
	config_input *conf = ext_conf->input;
	const char **list;
	
	if ((n = pcre_exec(conf->match_referrer, conf->match_referrer_extra, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, str);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
	
	if (n >= 2) {
		/* everything has matched, take the different pieces and be happy :) */
		pcre_get_substring_list(str, ovector, n, &list);
	
		record->ref_url = malloc(strlen((char *)list[1])+1);
		strcpy(record->ref_url, (char *)list[1]);
		
		if (n > 3) {
			record->ref_getvars = malloc(strlen((char *)list[3])+1);
			strcpy(record->ref_getvars, (char *)list[3]);
		}
#ifdef DEBUG_INPUT		
		fprintf(stderr, "%s.%d: %s, %s\n", __FILE__, __LINE__, record->ref_url, record->ref_getvars);
#endif
		free(list);
	} else {
		fprintf(stderr, "%s.%d: Matched fields below minimum: %d\n", __FILE__, __LINE__, n);
		return -1;
	}
	
	
	
	return 0;
#undef  N
}

#define M_MSIIS_FIELD_DATE		1
#define M_MSIIS_FIELD_TIME		2
#define M_MSIIS_FIELD_CLIENT_IP		3
#define M_MSIIS_FIELD_USERNAME		4
#define M_MSIIS_FIELD_SITENAME		5
#define M_MSIIS_FIELD_SERVERNAME	6
#define M_MSIIS_FIELD_SERVER_IP		7
#define M_MSIIS_FIELD_SERVER_PORT	8
#define M_MSIIS_FIELD_REQ_METHOD	9
#define M_MSIIS_FIELD_URI_STEM		10
#define M_MSIIS_FIELD_URI_QUERY		11
#define M_MSIIS_FIELD_STATUS		12
#define M_MSIIS_FIELD_WIN32_STATUS	13
#define M_MSIIS_FIELD_BYTES_SEND	14
#define M_MSIIS_FIELD_BYTES_RECEIVED	15
#define M_MSIIS_FIELD_TIME_TAKEN	16
#define M_MSIIS_FIELD_REQ_PROTOCOL	17
#define M_MSIIS_FIELD_REQ_HOST		18
#define M_MSIIS_FIELD_USER_AGENT	19
#define M_MSIIS_FIELD_COOKIE		20
#define M_MSIIS_FIELD_REFERRER		21

typedef struct {
	char	*field;
	int	id;
	char	*match;
} msiis_field_def;

const msiis_field_def def[] = 
	{ { "date", 		M_MSIIS_FIELD_DATE,	"(.+?)"},
	  { "time", 		M_MSIIS_FIELD_TIME,	"(.+?)"},
	  { "c-ip", 		M_MSIIS_FIELD_CLIENT_IP,"(.+?)"},
	  { "cs-username",	M_MSIIS_FIELD_USERNAME,	"(.+?)"},
	  { "s-sitename",	M_MSIIS_FIELD_SITENAME,	"(.+?)"},
	  { "s-computername",	M_MSIIS_FIELD_SERVERNAME, "(.+?)"},
	  { "s-ip",		M_MSIIS_FIELD_SERVER_IP,"(.+?)"},
	  { "s-port",		M_MSIIS_FIELD_SERVER_PORT, "([0-9]+?)"},
	  { "cs-method",	M_MSIIS_FIELD_REQ_METHOD, "(.+?)"},
	  { "cs-uri-stem",	M_MSIIS_FIELD_URI_STEM,	"(.+?)"},
	  { "cs-uri-query",	M_MSIIS_FIELD_URI_QUERY,"(.+?)"},
	  { "sc-status",	M_MSIIS_FIELD_STATUS,	"([0-9]+?)"},
	  { "sc-win32-status",	M_MSIIS_FIELD_WIN32_STATUS, "(.+?)"},
	  { "sc-bytes",		M_MSIIS_FIELD_BYTES_SEND,"([0-9]+?)"},
	  { "cs-bytes", 	M_MSIIS_FIELD_BYTES_RECEIVED, "([0-9]+?)"},
	  { "time-taken",	M_MSIIS_FIELD_TIME_TAKEN,"(.+?)"},
	  { "cs-version",	M_MSIIS_FIELD_REQ_PROTOCOL, "(.+?)"},
	  { "cs-host",		M_MSIIS_FIELD_REQ_HOST,	"(.+?)"},
	  { "cs(User-Agent)",	M_MSIIS_FIELD_USER_AGENT, "(.+?)"},
	  { "cs(Cookie)",	M_MSIIS_FIELD_COOKIE,	"(.+?)"},
	  { "cs(Referer)",	M_MSIIS_FIELD_REFERRER,	"(.+?)"},
		  
	  { NULL, 0, NULL}
};

int parse_msiis_field_info(mconfig *ext_conf, const char *_buffer) {
	config_input *conf = ext_conf->input;
	char *buf, *pa, *pe;
	int pos = 0, i;
	char *match_buf;
	const char *errptr;
	int erroffset = 0;
	
	if (_buffer == NULL) return -1;
	
	if ((buf = malloc(strlen(_buffer)+1)) == NULL) {
		return -1;
	}
	
	strcpy(buf, _buffer);
	
	pa = buf;
	pe = NULL;
	
	while ((pe = strchr(pa, ' ')) != NULL) {
		*pe = '\0';
		
		for (i = 0; def[i].field != NULL; i++) {
			if (strcmp(def[i].field, pa) == 0) {
				break;
			}
		}
		
		if (def[i].field != NULL) {
			if (pos >= M_MSIIS_MAX_FIELDS) return -1;
			
			conf->trans_fields[pos++] = i;
		} else {
			fprintf(stderr, "%s.%d: Unknown fieldtype: %s\n", __FILE__, __LINE__, pa);
			free(buf);
			return -1;
		}
		
		pa = pe + 1;
	}
	
	/* don't forget the last param */
	if (*pa) {
		for (i = 0; def[i].field != NULL; i++) {
			if (strcmp(def[i].field, pa) == 0) {
				break;
			}
		}
	
		if (def[i].field != NULL) {
			if (pos >= M_MSIIS_MAX_FIELDS) return -1;
			conf->trans_fields[pos++] = i;
		} else {
			fprintf(stderr, "%s.%d: Unknown fieldtype: %s\n", __FILE__, __LINE__, pa);
			free(buf);
			return -1;
		}
	}
	
	free(buf);
	
	match_buf = malloc(1024);
	
	*match_buf = '\0';
	
	for (i = 0; i < pos; i++) {
		if (*match_buf == '\0') {
			match_buf = strcat(match_buf, "^");
		} else {
			match_buf = strcat(match_buf, " ");
		}
		match_buf = strcat(match_buf, def[conf->trans_fields[i]].match);
	}
	
	match_buf = strcat(match_buf, "$");
	
	if ((conf->match_clf = pcre_compile(match_buf,
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		free(match_buf);
		return -1;
	} 
	free(match_buf);
	
	conf->match_clf_extra = pcre_study(conf->match_clf, 0, &errptr);
	if (errptr != NULL) {
		fprintf(stderr, "%s.%d: rexexp studying error at %s\n", __FILE__, __LINE__, errptr);
		return -1;
	}
	
	return 0;
}

/*
** returns:
** 0  - no error
** -1 - fatal error
** 1  - corrupt record
*/
int parse_record_pcre(mconfig *ext_conf, mlogrec *record, char *_buffer) {
#define N 30 + 1
	const char **list;
	int ovector[3 * N], n, i;
	config_input *conf = ext_conf->input;
	mlogrec_web *recweb = NULL; 
	mlogrec_web_extclf *recext = NULL; 
	
	const char *_date = NULL, *_time = NULL;
	
	/* remove the carriage return */
	if (_buffer[strlen(_buffer)-1] == '\r') {
		_buffer[strlen(_buffer)-1] = '\0';
	}
	
	if (strncmp("#Version: ", _buffer, 10) == 0) {
		if (strncmp("#Version: 1.0", _buffer, 13) != 0) {
			fprintf(stderr, "%s.%d: only logfile version 1.0 is supported\n", __FILE__, __LINE__);
			return -1;
		}
		return 1;
	}
	
	if (strncmp("#Fields: ", _buffer, 9) == 0) {
		if (parse_msiis_field_info(ext_conf, _buffer+9) != 0) {
			return -1;
		} else {
			return 1;
		}
	}
	
	if (*_buffer == '#') return 1;
	
	if (conf->match_clf == NULL) return -1;
	
	recweb = mrecord_init_web();
	
	record->ext_type = M_RECORD_TYPE_WEB;
	record->ext = recweb;
	
	recext = mrecord_init_web_extclf();
	
	recweb->ext_type = M_RECORD_TYPE_WEB_EXTCLF;
	recweb->ext = recext;
	
	if (recweb == NULL) return 1;

/* parse a CLF record */	
	if ((n = pcre_exec(conf->match_clf, conf->match_clf_extra, _buffer, strlen(_buffer), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _buffer);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return 1;
	}
	
	if (n == 0) {
		fprintf(stderr, "%s.%d: !REPORT ME! N is too low -> %d\n", __FILE__, __LINE__, N);
		return -1;
	}
	
	pcre_get_substring_list(_buffer, ovector, n, &list);
	
	for (i = 0; i < n-1; i++) {
		switch (def[conf->trans_fields[i]].id) {
		case M_MSIIS_FIELD_DATE:
			_date = list[i+1];
			break;
		case M_MSIIS_FIELD_TIME:
			_time = list[i+1];
			break;
		case M_MSIIS_FIELD_CLIENT_IP:
			recweb->req_host = malloc(strlen((char *)list[i+1])+1);
			strcpy(recweb->req_host, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_USERNAME:
			recweb->req_user = malloc(strlen((char *)list[i+1])+1);
			strcpy(recweb->req_user, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_REQ_METHOD:
			recweb->req_method = malloc(strlen((char *)list[i+1])+1);
			strcpy(recweb->req_method, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_URI_STEM:
			recweb->req_url = malloc(strlen((char *)list[i+1])+1);
			strcpy(recweb->req_url, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_STATUS:
			recweb->req_status = strtol(list[i+1], NULL,10);
			break;
		case M_MSIIS_FIELD_BYTES_SEND:
			recweb->xfersize = strtod(list[i+1], NULL);
			break;
		case M_MSIIS_FIELD_SERVER_PORT:
			recext->srv_port = malloc(strlen((char *)list[i+1])+1);
			strcpy(recext->srv_port, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_SERVER_IP:
			recext->srv_host = malloc(strlen((char *)list[i+1])+1);
			strcpy(recext->srv_host, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_REQ_PROTOCOL:
			recweb->req_protocol = malloc(strlen((char *)list[i+1])+1);
			strcpy(recweb->req_protocol, (char *)list[i+1]);
			break;
		case M_MSIIS_FIELD_USER_AGENT:
			if (parse_useragent(ext_conf, list[i+1], recext)  == -1) {
				return 1;
			}
			break;
		case M_MSIIS_FIELD_REFERRER:
			if (parse_referrer(ext_conf, list[i+1], recext)  == -1) {
				return 1;
			}
			break;
		/* no mapping */
		case M_MSIIS_FIELD_COOKIE:
		case M_MSIIS_FIELD_SITENAME:
		case M_MSIIS_FIELD_SERVERNAME:
		
		case M_MSIIS_FIELD_REQ_HOST:
		case M_MSIIS_FIELD_BYTES_RECEIVED:
		case M_MSIIS_FIELD_TIME_TAKEN:
		case M_MSIIS_FIELD_URI_QUERY:
		case M_MSIIS_FIELD_WIN32_STATUS:
			if (ext_conf->debug_level > 2)
				fprintf(stderr, "the field '%s' is known, but not supported yet.\n",def[conf->trans_fields[i]].field);
			break;
			

		default:
			fprintf(stderr, "the field '%s' is unknown\n", def[conf->trans_fields[i]].field);
			break;
		}
	}
	
	if (_time != NULL && _date != NULL) {
		parse_timestamp(ext_conf, _date, _time, record);
	}
	
	free(list);
	
	return 0;
#undef  N
}

int mplugins_input_get_next_record(mconfig *ext_conf, mlogrec *record) {
	int ret = 0;
	config_input *conf = ext_conf->input;
	
	if (record == NULL) return -1;
	
	if (!fgets(conf->buffer, conf->buf_len-1,conf->inputfile)) {
		return -1;
	}

	while (conf->buffer[strlen(conf->buffer)-1] != '\n') {
		conf->buffer = realloc(conf->buffer, (conf->buf_len+conf->buf_inc) * sizeof(char));
		
		if (!fgets(conf->buffer+strlen(conf->buffer), conf->buf_inc-1,conf->inputfile)) {
			return -1;
		}
		
		conf->buf_len += conf->buf_inc;
	}
	
	conf->buffer[strlen(conf->buffer)-1] = '\0';
	
	ret = parse_record_pcre(ext_conf, record, conf->buffer);
	
	return ret;
}
