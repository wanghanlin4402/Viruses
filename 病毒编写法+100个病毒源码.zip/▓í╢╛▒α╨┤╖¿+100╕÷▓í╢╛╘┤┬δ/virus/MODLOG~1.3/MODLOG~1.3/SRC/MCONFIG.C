/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mconfig.c,v 1.28 2001/01/11 22:21:58 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <sys/stat.h>

#ifdef HAVE_LIBADNS
#include <adns.h>
#endif

#include "mlocale.h"
#include "mconfig.h"
#include "mdatatypes.h"
#include "misc.h"
#include "mplugins.h"


static int linenumber = 0;
static char *filename = NULL;

#define M_CONFIG_GROUP_UNKNOWN	-1
#define M_CONFIG_GROUP_IGNORE	0
#define M_CONFIG_GROUP_GLOBAL	1
#define M_CONFIG_GROUP_INPUT	2
#define M_CONFIG_GROUP_OUTPUT	3
#define M_CONFIG_GROUP_PROCESSOR	4

int mconfig_insert_value(void *dest, int type, char *value, int value_def) {
	pcre *match = NULL;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	switch(type) {
		case M_CONFIG_TYPE_STRING: {
			char *str = *(char **)(dest);
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE: {
					if (str) break;

					str = malloc(strlen(value)+1);
					strcpy(str, value);
					
					*(char **)(dest) = str;
					break;
				}
				case M_CONFIG_VALUE_APPEND:
					fprintf(stderr,"%s.%d: append not supported for string type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_OVERWRITE:
					if (str) free(str);
					str = malloc(strlen(value)+1);
					strcpy(str, value);
			
					*(char **)(dest) = str;
					break;
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			
			break;
		}
		case M_CONFIG_TYPE_STRING_LIST: {
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					fprintf(stderr,"%s.%d: ignore not supported for grouping type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_APPEND: {
					data_StrInt *data;
					mlist *l = *(mlist **)(dest);
						
					data = createStrInt(value, 1);
					mlist_insert(l, data);
					break;
				}
				case M_CONFIG_VALUE_OVERWRITE:
					fprintf(stderr,"%s.%d: overwrite not supported for grouping type\n", __FILE__, __LINE__);
					break;
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			break;
		}
		case M_CONFIG_TYPE_COLTRIPPL: {
			char *str = *(char **)(dest);
			
			if (!is_htmltripple(value)) {
				fprintf(stderr, "%s (%s:%i): %s\n", _("Invalid colortripple"), filename, linenumber, value);
				break;
			}
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					if (str) break;
					str = malloc(strlen(value)+1);
					strcpy(str, value);
					
					*(char **)(dest) = str;
					break;
				case M_CONFIG_VALUE_APPEND:
					fprintf(stderr,"%s.%d: append not supported for colortripple type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_OVERWRITE:
					if (str) free(str);
					str = malloc(strlen(value)+1);
					strcpy(str, value);
					
					*(char **)(dest) = str;
					break;
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
					
				
			break;
		}
		case M_CONFIG_TYPE_SUBSTITUTE: {
			if ((match = pcre_compile(
				"^\"(.+)\",(.+)$", 
				0, &errptr, &erroffset, NULL)) == NULL) {
		
				fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
				return -1;
			} 
	
			if ((n = pcre_exec(match, NULL, value, strlen(value), 0, 0, ovector, 3 * N)) < 0) {
				if (n == PCRE_ERROR_NOMATCH) {
					fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, value);
					fprintf(stderr, "%s (%s:%i): %s\n", "grouping", filename, linenumber, value);
				} else {
					fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
				}
				return -1;
			}
	
			pcre_get_substring_list(value, ovector, n, &list);
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					fprintf(stderr,"%s.%d: ignore not supported for grouping type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_APPEND: {
					data_Match *data;
					mlist *l = *(mlist **)(dest);
						
					data = createMatch((char *)list[1], (char *)list[2]);
					mlist_append(l, data);
					break;
				}
				case M_CONFIG_VALUE_OVERWRITE:
					fprintf(stderr,"%s.%d: overwrite not supported for grouping type\n", __FILE__, __LINE__);
					break;
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			free(list);
			free(match);
			break;
		}
		case M_CONFIG_TYPE_MATCH: {
			if ((match = pcre_compile(
				"^\"(.+)\"$", 
				0, &errptr, &erroffset, NULL)) == NULL) {
		
				fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
				return -1;
			} 
	
			if ((n = pcre_exec(match, NULL, value, strlen(value), 0, 0, ovector, 3 * N)) < 0) {
				if (n == PCRE_ERROR_NOMATCH) {
					fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, value);
					fprintf(stderr, "%s (%s:%i): %s\n", "hiding", filename, linenumber, value);
				} else {
					fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
				}
				return -1;
			}
	
			pcre_get_substring_list(value, ovector, n, &list);
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					fprintf(stderr,"%s.%d: ignore not supported for hiding type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_APPEND: {
					data_Match *data;
					mlist *l = *(mlist **)(dest);
					
					data = createMatch((char *)list[1], "");
					
					mlist_append(l, data);
					break;
				}
				case M_CONFIG_VALUE_OVERWRITE:
					fprintf(stderr,"%s.%d: overwrite not supported for hiding type\n", __FILE__, __LINE__);
					break;
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			free(list);
			free(match);
			break;
		}
		case M_CONFIG_TYPE_INT: {
			int str = *(int *)(dest);
			char *endp;
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					fprintf(stderr,"%s.%d: ignore not supported for int type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_APPEND:
					fprintf(stderr,"%s.%d: append not supported for int type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_OVERWRITE: {
					str = strtol(value, &endp, 10);
					
					if (*endp != '\0') {
						fprintf(stderr, "%s (%s:%i): %s\n", _("Value isn't an integer in line"), filename, linenumber, value);
					} else {
						*(int *)(dest) = str;
					}
					break;
				}
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			break;
		}
		case M_CONFIG_TYPE_CHAR: {
			char str = *(char *)(dest);
			
			switch(value_def) {
				case M_CONFIG_VALUE_IGNORE:
					fprintf(stderr,"%s.%d: ignore not supported for int type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_APPEND:
					fprintf(stderr,"%s.%d: append not supported for int type\n", __FILE__, __LINE__);
					break;
				case M_CONFIG_VALUE_OVERWRITE: {
					str = *value;
					
					*(char *)(dest) = str;
					break;
				}
				default:
					fprintf(stderr,"%s.%d: unknown type of value definetion\n", __FILE__, __LINE__);
					break;
			}
			
			break;
		}
		default:
			fprintf(stderr,"%s.%d: unknown type of key-value definetion\n", __FILE__, __LINE__);
			break;
	}
#undef N	
	return 0;
}

int mconfig_set_defaults(mconfig *conf) {
	struct stat st;
	if (conf == NULL) return -1;
	
	if (conf->outputdir == NULL) {
		fprintf(stderr, "no output directory was set\n");
		return -1;
	}
	
	if (stat(conf->outputdir, &st) != 0) {
		fprintf(stderr, "Can't check if the output directory is ok (%s): %s\n", conf->outputdir, strerror(errno));
		return -1;
	} else {
		if (S_ISDIR(st.st_mode) && 
			(((st.st_mode & S_IWUSR) && (st.st_mode & S_IRUSR)) ||
			((st.st_mode & S_IWGRP) && (st.st_mode & S_IRGRP)) ||
			((st.st_mode & S_IWOTH) && (st.st_mode & S_IROTH)))
			) {
			/* every thing seems to be ok. */
		} else {
			fprintf(stderr, "the output directory doesn't have the right permissions: %s\n", conf->outputdir);
			return -1;
		}
	}

#ifdef HAVE_LIBADNS
	conf->adns = (adns_state *)malloc(sizeof(adns_state));
	
	if (adns_init(conf->adns, 0, 0)) {
		fprintf(stderr, "Can't init the resolver\n");
		return -1;
	}
#endif

	return 0;
}


	
	
mconfig *mconfig_parse(mconfig *conf, const char *cf) {	
	FILE *f;
	int current_group = M_CONFIG_GROUP_IGNORE;
	char buf[255];
	int locale_is_not_setup_yet = 1;
	int ln = 0;
	
	char *_filename = NULL;
	
	const mconfig_values config_values[] = {
	/* strings */
		{"inputplugin",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_IGNORE, &(conf->inputplugin)},
		{"outputplugin", M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_IGNORE, &(conf->outputplugin)},
		{"processorplugin", M_CONFIG_TYPE_STRING, M_CONFIG_VALUE_IGNORE, &(conf->processorplugin)},
		{"outputdir",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_OVERWRITE, &(conf->outputdir)},
		{"language",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_OVERWRITE, &(conf->language)},
	/* integers */
		{"incremental",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->incremental)},
		{"debug_level",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->debug_level)},
		{"gen_report_threshold",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->gen_report_threshold)},
		{"disable_resolver",	M_CONFIG_TYPE_INT,	M_CONFIG_VALUE_OVERWRITE, &(conf->disable_resolver)},
	/* strings */
		{"default_configfile",	M_CONFIG_TYPE_STRING,	M_CONFIG_VALUE_IGNORE, &(conf->default_configfile)},
		
		{NULL, M_CONFIG_TYPE_INT, 0, NULL}
	};
	
#ifdef SYSCONFDIR
	const char *def_cf_dir = SYSCONFDIR;
#else
	const char *def_cf_dir = "./";
#endif
	const char *def_cf_name = "modlogan.conf";
	
	if (!cf) {
		_filename = malloc(strlen(def_cf_dir) + strlen(def_cf_name) + 2);
		
		strcpy(_filename, def_cf_dir);
		strcat(_filename, "/");
		strcat(_filename, def_cf_name);
	} else {
		_filename = malloc(strlen(cf) + 1);
		strcpy(_filename, cf);
	}
	
	filename = _filename;
	
	if (!(f = fopen(filename, "r"))) {
		fprintf(stderr,"%s %s: %s\n", _("Can't open configfile"), filename, strerror(errno));
		free(_filename);
		filename = NULL;
		return NULL;
	}
	
	printf("using configfile: %s\n",filename);
	
	while (fgets(buf, sizeof(buf)-1, f)) {
		if (buf[strlen(buf)-1] != '\n') {
			fprintf(stderr, "%s: %s\n", _("No newline at end of line or line longer then 255 charaters"), buf);
			free(_filename);
			filename = NULL;
			return NULL;
		}
		buf[strlen(buf)-1] = '\0';
		
		ln++;
		linenumber = ln;
		
		if (!strlen(buf)) continue;
		
		if (*buf == '[') {
			char *key = buf + 1;
			char *subkey = NULL;
			char *c1 = key;
			
			
			while (*c1 && *c1 != ']') c1++;
			*c1 = '\0';
			
			if ((subkey = strchr(key, '_'))) {
				*subkey++ = '\0';
			}
			
			if (!strcmp(key, "global")) {
				current_group = M_CONFIG_GROUP_GLOBAL;
			} else if (!strcmp(key, "input")) {
				if (subkey && conf->inputplugin) {
					if (strcmp(conf->inputplugin, subkey) != 0) {
						current_group = M_CONFIG_GROUP_IGNORE;
					} else {
						if (!conf->input)
							if (mplugins_init_input(conf) != 0) return NULL;
				
						current_group = M_CONFIG_GROUP_INPUT;
					}
				} else {
					if (!conf->input)
						if (mplugins_init_input(conf) != 0) return NULL;
				
					current_group = M_CONFIG_GROUP_INPUT;
				}
			} else if (!strcmp(key, "output")) {
				if (subkey && conf->outputplugin) {
					if (strcmp(conf->outputplugin, subkey) != 0) {
						current_group = M_CONFIG_GROUP_IGNORE;
					} else {
						if (!conf->output)
							if (mplugins_init_output(conf) != 0) return NULL;
				
						current_group = M_CONFIG_GROUP_OUTPUT;
					}
				} else {
					if (!conf->output)
						if (mplugins_init_output(conf) != 0) return NULL;
				
					current_group = M_CONFIG_GROUP_OUTPUT;
				}
			} else if (!strcmp(key, "processor")) {
				if (subkey && conf->processorplugin) {
					if (strcmp(conf->processorplugin, subkey) != 0) {
						current_group = M_CONFIG_GROUP_IGNORE;
					} else {
						if (!conf->processor)
							if (mplugins_init_processor(conf) != 0) return NULL;
				
						current_group = M_CONFIG_GROUP_PROCESSOR;
					}
				} else {
					if (!conf->processor)
						if (mplugins_init_processor(conf) != 0) return NULL;
				
					current_group = M_CONFIG_GROUP_PROCESSOR;
				}
			} else {
				current_group = M_CONFIG_GROUP_UNKNOWN;
				fprintf(stderr, "%s (%s:%i): %s\n", _("Unknown section in line"), filename, linenumber, buf);
			}
			
			if (current_group != 0 && current_group != M_CONFIG_GROUP_GLOBAL &&
				locale_is_not_setup_yet) {
				init_locale(conf);
				locale_is_not_setup_yet = 0;
			}
				
		} else if (*buf == '#') {
		/* a comment */
		} else {
			char *key, *value, *c1;
			int i;
			
			key = buf;
			if (!(value = strchr(key, '='))) {
				fprintf(stderr,"%s (%s:%i): %s\n", _("no '=' found in line"), filename, linenumber, buf);
				free(_filename);
				filename = NULL;
				return NULL;
			}
			c1 = value;
			
			/* remove whitespaces at the end of the key */
			while (c1 > key) {
				if (!isspace(*(c1-1))) {
					break;
				}
				c1--;
			}
			*c1 = '\0';
			
			c1 = value+1;
			
			while (*c1) {
				if (!isspace(*c1)) {
					break;
				}
				c1++;
			}
			value = c1;
			
			c1 = value + strlen(value);
			while (c1 > value) {
				if (!isspace(*(c1-1))) {
					break;
				}
				c1--;
			}
			*c1 = '\0';
			
			switch(current_group) {
				case M_CONFIG_GROUP_GLOBAL:
				{
					i = 0;
					while (config_values[i].string) {
						if (!strcmp(config_values[i].string, key))
							break;
						i++;
					}
			
					if (config_values[i].string) {
						int parse_default_file = 0;
						if (!strcmp(config_values[i].string, "default_configfile")) {
							if (conf->default_configfile == NULL) {
								parse_default_file = 1;
							}
						}
						mconfig_insert_value(config_values[i].dest, config_values[i].type, value, config_values[i].value_def);
						
						if (conf->default_configfile != NULL && parse_default_file == 1) {
							mconfig_parse(conf, conf->default_configfile);
							filename = _filename;
						}
						
					} else {
						fprintf(stderr, "[global] %s (%s:%i): %s\n", _("Unknown Keyword in line"), filename, linenumber, buf);
					}
					break;
				}
				case M_CONFIG_GROUP_INPUT:
				{
					if (mplugins_input_parse_config(conf, key, value)) {
						fprintf(stderr, "[input] %s (%s:%i): %s\n", _("Unknown Keyword in line"), filename, linenumber, buf);
					}
					break;
				}
				case M_CONFIG_GROUP_OUTPUT:
				{
					if (mplugins_output_parse_config(conf, key, value)) {
						fprintf(stderr, "[output] %s (%s:%i): %s\n", _("Unknown Keyword in line"), filename, linenumber, buf);
					}
					break;
				}
				case M_CONFIG_GROUP_PROCESSOR:
				{
					if (mplugins_processor_parse_config(conf, key, value)) {
						fprintf(stderr, "[processor] %s (%s:%i): %s\n", _("Unknown Keyword in line"), filename, linenumber, buf);
					}
					break;
				}
				case M_CONFIG_GROUP_IGNORE:
					break;
				default:
					fprintf(stderr, "%s (%s:%i): %s\n", _("Unknown section in line"), filename, linenumber, buf);
			}
		}
	}
	
	fclose (f);
	
	if (conf->debug_level > 0)
		fprintf(stderr, "%s: %s \n", filename, _("Reading config - finished"));
	
	free(_filename);
	filename = NULL;
	return conf;
}

mconfig *mconfig_init(const char *cf) {
	mconfig *conf = malloc(sizeof(mconfig));
	int no_plug_error = 0;
	
	if (!conf) return NULL;
	
	memset(conf, 0, sizeof(mconfig));
	
	if (!mconfig_parse(conf, cf)) return NULL;

#ifdef	NO_PLUGINS
	if (strcmp(conf->inputplugin, INPUT_PLUGIN) ) {
		printf("section [global]: inputplugin is not %s\n", INPUT_PLUGIN);
		no_plug_error = 1;
	}
	
	if (strcmp(conf->processorplugin, PROCESSOR_PLUGIN) ) {
		printf("section [global]: processorplugin is not %s\n", PROCESSOR_PLUGIN);
		no_plug_error = 1;
	}
	
	if (strcmp(conf->outputplugin, OUTPUT_PLUGIN) ) {
		printf("section [global]: outputplugin is not %s\n", OUTPUT_PLUGIN);
		no_plug_error = 1;
	}
	
	if (no_plug_error) {
		printf("You are using the 'static' modlogan which linked against the following plugins:\n");
		printf("inputplugin     -> %s\n", INPUT_PLUGIN);
		printf("processorplugin -> %s\n", PROCESSOR_PLUGIN);
		printf("outputplugin    -> %s\n", OUTPUT_PLUGIN);
		printf("Your configfile is stating something different.\n\n");
		printf("Please correct the error reported above and rerun modlogan.\n");
		return NULL;
	}
#endif
	
	if (conf->debug_level > 2)
		fprintf(stderr, "%s.%d: trying to init the plugins that aren't setup yet\n", __FILE__, __LINE__);
	
	/* default values */
	if (!conf->input) {
		if (mplugins_init_input(conf) != 0) return NULL;
	}
	
	if (!conf->output) {
		if (mplugins_init_output(conf) != 0) return NULL;
	}
	
	if (!conf->processor) {
		if (mplugins_init_processor(conf) != 0) return NULL;
	}
	
	if (conf->debug_level > 2)
		fprintf(stderr, "%s.%d: doing some checks and set the default values\n", __FILE__, __LINE__);

#ifdef HAVE_LIBADNS
	conf->adns = NULL;
	conf->query_hash = mhash_init();
#endif

	if (mconfig_set_defaults(conf) != 0) return NULL;

	if (mplugins_input_set_defaults(conf) != 0) return NULL;
	if (mplugins_output_set_defaults(conf) != 0) return NULL;
	if (mplugins_processor_set_defaults(conf) != 0) return NULL;
	
	return conf;
}

int mconfig_free(mconfig *conf) {
	if (!conf) return -1;
	
	if (conf->outputdir)	free(conf->outputdir);
	if (conf->outputplugin)	free(conf->outputplugin);
	if (conf->inputplugin)	free(conf->inputplugin);
	if (conf->processorplugin)	free(conf->processorplugin);
	
	if (conf->default_configfile)	free(conf->default_configfile);
#ifdef HAVE_LIBADNS
	adns_finish(*(conf->adns));
	if (conf->adns)	free(conf->adns);
	if (conf->query_hash) mhash_free(conf->query_hash);
#endif
	
	free(conf);
	
	return 0;
	
}