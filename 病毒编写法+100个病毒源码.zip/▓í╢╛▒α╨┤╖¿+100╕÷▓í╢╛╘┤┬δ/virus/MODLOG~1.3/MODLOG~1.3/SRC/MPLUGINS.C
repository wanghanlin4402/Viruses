/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mplugins.c,v 1.18 2000/11/11 21:43:13 jk Exp $
*/

#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>

#include "mconfig.h"
#include "mrecord.h"
#include "mplugins.h"

#ifdef NO_PLUGINS
int mplugins_init_input(mconfig *conf) {
	return mplugins_input_dlinit(conf);
}

int mplugins_init_output(mconfig *conf) {
	return mplugins_output_dlinit(conf);
}
int mplugins_init_processor(mconfig *conf) {
	return mplugins_processor_dlinit(conf);
}

int mplugins_free(mconfig *conf) {
	mplugins_output_dlclose(conf);
	mplugins_input_dlclose(conf);
	mplugins_processor_dlclose(conf);
	return 0;
}

int get_next_record(mconfig *config, mlogrec *record) {
	return mplugins_input_get_next_record(config, record);
}

int generate_monthly_output(mconfig *config, mstate *state, char *subpath) {
	return mplugins_output_generate_monthly_output(config, state, subpath);
}

int generate_history_output(mconfig *config, mlist *history, char *subpath) {
	return mplugins_output_generate_history_output(config, history, subpath);
}

int insert_record(mconfig *conf, mlist *state_list, mlogrec *record) {
	return mplugins_processor_insert_record(conf, state_list, record);
}

#else
static void *input_handle;
static void *output_handle;
static void *processor_handle;

static functions func;

int mplugins_init_input(mconfig *conf) {
	char *error;
	char *filename = NULL;
	
	int (*initfunc)(mconfig *conf);
	
/* reset all elements */
	input_handle = NULL;
	
	func.mplugins_input_get_next_record = NULL;
	func.mplugins_input_parse_config = NULL;
	
	if (conf->inputplugin == NULL) return -1;

	filename = malloc(strlen("/libmla_input_.so") + strlen(conf->inputplugin) + strlen(LIBDIR) + 1);

	sprintf(filename, "%s/libmla_input_%s.so", LIBDIR, conf->inputplugin);
	
	input_handle = dlopen (filename, RTLD_LAZY);
	free(filename);
	
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		return(-1);
	}
	
	func.mplugins_input_get_next_record = dlsym(input_handle,"mplugins_input_get_next_record");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(input_handle);
		input_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_input_parse_config = dlsym(input_handle,"mplugins_input_parse_config");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(input_handle);
		input_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_input_set_defaults = dlsym(input_handle,"mplugins_input_set_defaults");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(input_handle);
		input_handle = NULL;
		
		return(-1);
	}
	
	initfunc = dlsym(input_handle, "mplugins_input_dlinit");
	if (!error && initfunc) {
		initfunc(conf);
	}
	
	printf("used input plugin: %s\n",conf->inputplugin);
	
	return 0;
}

int mplugins_init_output(mconfig *conf) {
	char *error;
	char *filename;
	
	int (*initfunc)(mconfig *conf);
	
/* reset all elements */
	output_handle = NULL;
	
	func.mplugins_output_generate_monthly_output = NULL;
	func.mplugins_output_generate_history_output = NULL;
	func.mplugins_output_parse_config = NULL;

	filename = malloc(strlen("/libmla_output_.so") + strlen(conf->outputplugin) + strlen(LIBDIR) + 1);

	sprintf(filename, "%s/libmla_output_%s.so", LIBDIR, conf->outputplugin);
	
	output_handle = dlopen (filename, RTLD_LAZY);
	free(filename);
	if ((error = dlerror()) != NULL) {
		puts(error);
		return(-1);
	}
	
	func.mplugins_output_generate_monthly_output = dlsym(output_handle,"mplugins_output_generate_monthly_output");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(output_handle);
		output_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_output_generate_history_output = dlsym(output_handle,"mplugins_output_generate_history_output");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(output_handle);
		output_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_output_parse_config = dlsym(output_handle,"mplugins_output_parse_config");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(output_handle);
		output_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_output_set_defaults = dlsym(output_handle,"mplugins_output_set_defaults");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(output_handle);
		output_handle = NULL;
		
		return(-1);
	}
	
	initfunc = dlsym(output_handle, "mplugins_output_dlinit");
	if (!error && initfunc) {
		initfunc(conf);
	}
	
	printf("used output plugins: %s\n", conf->outputplugin);
	
	return 0;
}

int mplugins_init_processor(mconfig *conf) {
	char *error;
	char *filename;
	
	int (*initfunc)(mconfig *conf);
	
/* reset all elements */
	processor_handle = NULL;
	
	func.mplugins_processor_insert_record = NULL;
	func.mplugins_processor_parse_config = NULL;

	filename = malloc(strlen("/libmla_processor_.so") + strlen(conf->processorplugin) + strlen(LIBDIR) + 1);

	sprintf(filename, "%s/libmla_processor_%s.so", LIBDIR, conf->processorplugin);
	
	processor_handle = dlopen (filename, RTLD_LAZY);
	free(filename);
	if ((error = dlerror()) != NULL) {
		puts(error);
		return(-1);
	}
	
	func.mplugins_processor_insert_record = dlsym(processor_handle,"mplugins_processor_insert_record");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(processor_handle);
		processor_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_processor_parse_config = dlsym(processor_handle,"mplugins_processor_parse_config");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(processor_handle);
		processor_handle = NULL;
		
		return(-1);
	}
	
	func.mplugins_processor_set_defaults = dlsym(processor_handle,"mplugins_processor_set_defaults");
	if ((error = dlerror()) != NULL) {
		puts(error);
		
		dlclose(processor_handle);
		processor_handle = NULL;
		
		return(-1);
	}
	
	initfunc = dlsym(processor_handle, "mplugins_processor_dlinit");
	if (!error && initfunc) {
		initfunc(conf);
	}
	
	printf("used processor plugins: %s\n", conf->processorplugin);
	
	return 0;
}

int mplugins_free(mconfig *conf) {
	char *error;
	int (*closefunc)(mconfig *conf);
	
	closefunc = dlsym(input_handle, "mplugins_input_dlclose");
	if ((error = dlerror()) != NULL) {
		puts(error);
	} else if (closefunc) {
		closefunc(conf);
	}

	closefunc = dlsym(output_handle, "mplugins_output_dlclose");
	if ((error = dlerror()) != NULL) {
		puts(error);
	} else if (closefunc) {
		closefunc(conf);
	}
	
	closefunc = dlsym(processor_handle, "mplugins_processor_dlclose");
	if ((error = dlerror()) != NULL) {
		puts(error);
	} else if (closefunc) {
		closefunc(conf);
	}

	if (input_handle) dlclose(input_handle);
	if (output_handle) dlclose(output_handle);
	if (processor_handle) dlclose(processor_handle);
	
	output_handle = NULL;
	input_handle = NULL;
	processor_handle = NULL;
	return 0;
}

/* wrapper for dl-opened functions */
int get_next_record(mconfig *config, mlogrec *record) {
	if (!func.mplugins_input_get_next_record) return -1;
	
	return func.mplugins_input_get_next_record(config, record);
}

int generate_monthly_output(mconfig *config, mstate *state, char *subpath) {
	if (!func.mplugins_output_generate_monthly_output) return -1;
	
	return func.mplugins_output_generate_monthly_output(config, state, subpath);
}

int generate_history_output(mconfig *config, mlist *history, char *subpath) {
	if (!func.mplugins_output_generate_history_output) return -1;
	
	return func.mplugins_output_generate_history_output(config, history, subpath);
}

int insert_record(mconfig *conf, mlist *state_list, mlogrec *record) {
	if (!func.mplugins_processor_insert_record) return -1;
	
	return func.mplugins_processor_insert_record(conf, state_list, record);
}

int mplugins_input_parse_config(mconfig *ext_conf, const char *key, char *value) {
	if (!func.mplugins_input_parse_config) return -1;
	
	return func.mplugins_input_parse_config(ext_conf, key, value);
}

int mplugins_input_set_defaults(mconfig *ext_conf) {
	if (!func.mplugins_input_set_defaults) return -1;
	
	return func.mplugins_input_set_defaults(ext_conf);
}

int mplugins_output_parse_config(mconfig *ext_conf, const char *key, char *value) {
	if (!func.mplugins_output_parse_config) return -1;
	
	return func.mplugins_output_parse_config(ext_conf, key, value);
}

int mplugins_output_set_defaults(mconfig *ext_conf) {
	if (!func.mplugins_output_set_defaults) return -1;
	
	return func.mplugins_output_set_defaults(ext_conf);
}

int mplugins_processor_parse_config(mconfig *ext_conf, const char *key, char *value) {
	if (!func.mplugins_processor_parse_config) return -1;
	
	return func.mplugins_processor_parse_config(ext_conf, key, value);
}

int mplugins_processor_set_defaults(mconfig *ext_conf) {
	if (!func.mplugins_processor_set_defaults) return -1;
	
	return func.mplugins_processor_set_defaults(ext_conf);
}

#endif
