/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mlist.c,v 1.11 2001/01/11 22:25:09 jk Exp $
*/

#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "config.h"
#include "mlist.h"
#include "mdatatypes.h"

mlist* mlist_sort_full_by_string (mlist *l) {
	return mlist_sort_limited_by_string(l, -1);
}

mlist* mlist_sort_limited_by_string (mlist *l, int count) {
	mlist *act, *first;
	int i = 0;
	
	if (l == NULL || count == 0) return l;
	
	first = l;
	act = l;
	
	if (count < 0) count = 0; 

	for ( i = 0; (!count || (i < count)) && act; i++) {
		mlist *w = act->next;
		mlist *s = act;
		
		while (w) {
			if (strcmp (((data_StrInt*)w->data)->string, ((data_StrInt*)s->data)->string) < 0 ) {
				s = w;
			}
			w = w->next;
		}
		
		if ( s != act ) {
		/* insert in the sorted part of the list */
				
		/* take 'act' from the list */
			s->prev->next = s->next;
				
			if (s->next) 
				s->next->prev = s->prev;
				
			/* insert it at the right place */
			
			if (act == first) {
				s->prev = NULL;
				s->next = first;
				
				first->prev = s;
				
				first = s;
			} else {
				s->prev = act->prev;
				s->next = act;
				
				act->prev->next = s;
				act->prev = s;
			}
		} else {
			act = act->next;
		}
	}
	
	return first;
}

mlist* mlist_sort_full (mlist *l) {
	return mlist_sort_limited(l, -1);
}

/* limited select sort */
mlist* mlist_sort_limited (mlist *l, int count) {
	mlist *act, *first;
	int i = 0;
	int debug = 0;
	
	if (l == NULL || count == 0) return l;
	
	first = l;
	act = l;
	
	if (count < 0) {
		count = 0; 
		debug = 1;
	}
	
	if (debug) printf("--\n"); 
	for ( i = 0; (!count || (i < count)) && act; i++) {
		mlist *w = act->next;
		mlist *s = act;
		
		if (debug) printf("-1- %d\n",i); 
		while (w) {
			if (((data_StrInt*)w->data)->count > ((data_StrInt*)s->data)->count) {
				s = w;
			}
			w = w->next;
		}
		
		if ( s != act ) {
		/* insert in the sorted part of the list */
				
		/* take 'act' from the list */
			s->prev->next = s->next;
				
			if (s->next) 
				s->next->prev = s->prev;
				
			/* insert it at the right place */
			
			if (act == first) {
				s->prev = NULL;
				s->next = first;
				
				first->prev = s;
				
				first = s;
			} else {
				s->prev = act->prev;
				s->next = act;
				
				act->prev->next = s;
				act->prev = s;
			}
		} else {
			act = act->next;
		}
	}
	
	return first;
}


mlist *mlist_init () {
	mlist *l = malloc(sizeof(mlist));
	
	l->prev = NULL;
	l->next = NULL;
	l->data = NULL;
	
	return l;
}

int mlist_free_entry(mlist *l) {
	if (l->data) {
		((data_StrInt *)l->data)->destructor(l->data);
	}
	free(l);
	
	l = NULL;
	
	return 0;
}

int mlist_free(mlist *l) {
	mlist *act;
	if (!l) return 0;
	
	/* rewind to the beginnig */
	while (l->prev) {
		l = l->prev;
	}
	
	/* erase the list */
	while (l) {
		act = l;
		l = l->next;
		
		mlist_free_entry(act);
		
	}
	
	return 0;
}

int mlist_is_empty(mlist *l) {
	if (!l) return 1;
	
	return (l->data == NULL);
}

int mlist_insert (mlist *l, void *ins_data) {
	int inserted = 0;
	
	if (!l) return -1; 
	if (!ins_data) return -1;
		
	while(l) {
		data_StrInt *data = (data_StrInt *)l->data;
		
		if (!data) break;
			
		if (!strcmp(((data_StrInt*)ins_data)->string, data->string)) {
			if (data->append(data, ins_data) == M_DATA_APPENDED) {
				inserted = 1;
				
			/* the memory isn't used anymore */
				((data_StrInt*)ins_data)->destructor(ins_data);
				ins_data = NULL;	
				break;
			}
		}
			
		if (!l->next) break;
			
		l = l->next;
	}
	if (!inserted) {
		if (mlist_is_empty(l)) {
			l->data = ins_data;
		} else {
			mlist *n = mlist_init();
			
			n->data = ins_data;
			n->prev = l;
			l->next = n;
		}
	}
	
	return 0;
}

int mlist_append (mlist *l, void *ins_data) {
	int inserted = 0;
	
	if (!l) return -1; 
	if (!ins_data) return -1;
		
	while(l && l->data && l->next) {
		l = l->next;
	}
	if (!inserted) {
		if (mlist_is_empty(l)) {
			l->data = ins_data;
		} else {
			mlist *n = mlist_init();
			
			n->data = ins_data;
			n->prev = l;
			l->next = n;
		}
	}
	
	return 0;
}

int mlist_write(gzFile *f, mlist *l) {
	while (l) {
		if (l->data) {
			((data_StrInt *)l->data)->write(f, l->data);
		}
		l = l->next;
	}
	return 0;
}

int mlist_count(mlist *l) {
	int c = 0;
	if (!l) return 0;
	
	while (l) {
		if (l->data) c++;
		l = l->next;
	}
	
	return c;
}

void *mlist_get_data(mlist *l, const char *str) {
	data_StrInt *data = NULL;
	
	while(l) {
		data = (data_StrInt *)l->data;
		
		if (!data) break;
			
		if (!strcmp(str, data->string)) {
			break;
		}
		
		data = NULL;
			
		if (!l->next) {
			break;
		}
			
		l = l->next;
	}
	
	return data;
}

int mlist_in_list(mlist *l, const char *str) {
	data_StrInt *data = NULL;
	
	while(l) {
		data = (data_StrInt *)l->data;
		
		if (!data) break;
			
		if (!strcmp(str, data->string)) {
			return 1;
		}
		
		data = NULL;
			
		if (!l->next) {
			break;
		}
			
		l = l->next;
	}
	
	return 0;
}
