/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mdatatypes.c,v 1.23 2001/01/11 22:23:28 jk Exp $
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#ifdef HAVE_LIBZ
#include <zlib.h>
#else 
#include "zlibwrapper.h"
#endif

#include "mdatatypes.h"
#include "mstate.h"

int destroy2Str(void *d) {
	data_2Str *data = d;
	
	free(data->string);
	free(data->string2);
	free(data);
	
	return 0;
}

data_2Str *create2Str(char *string, char *string2) {
	data_2Str *data = malloc(sizeof(data_2Str));
	
	data->string = malloc(strlen(string)+1);
	strcpy(data->string, string);	
	
	data->string2 = malloc(strlen(string2)+1);
	strcpy(data->string2, string2);
	
	data->destructor = destroy2Str;
	data->write = NULL;
	
	return data;
}

char * _getline (gzFile *f) {
	char *buffer;
	int buf_len = 256;
	int buf_inc = 128;
	
	buffer = malloc(buf_len * sizeof(char));
	
	*buffer = '\0';

	if (!gzgets(f, buffer, buf_len-1)) {
		return buffer;
	}

	while (buffer[strlen(buffer)-1] != '\n') {
		buffer = realloc(buffer, (buf_len+buf_inc) * sizeof(char));
		
		if (!gzgets(f, buffer+strlen(buffer), buf_inc-1)) {
			break;
		}
		
		buf_len += buf_inc;
	}
	
	return buffer;
}



/* begin of Str2Int */

int Str2Int_write(gzFile *f, void *d) {
	data_StrInt *data = d;

	gzwrite(f, data->string, strlen(data->string));
	gzprintf(f, "\n%d,%d\n", 
		data->count,
		data->type);

	return 0;
}

int Str2Int_destroy(void *d) {
	data_StrInt *data = d;

	if (data->string != NULL) free(data->string);
	if (data != NULL) free(data);
	
	return 0;
}

int Str2Int_setdata(data_StrInt *data, const char *str, int count, int type) {
	data->string	= malloc(strlen(str)+1);
	strcpy(data->string, str);
	data->count	= count;
	data->type	= type;
	
	return 0;
}

int Str2Int_read(void *data, gzFile *f) {
	char *_s = NULL, *_c = NULL;
	int c, type;
	
	pcre *match;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	if ((_s = _getline(f)) == NULL) return -1;
	
	if (*_s == '\0') {
		free(_s);
		return -1;
	}
	if (mstate_is_section_end(_s)) {
		free(_s);
		return 0;
	}
	
	if ((_c = _getline(f)) == NULL) return -1;
	
	if (*_c == '\0') {
		free(_s);
		free(_c);
		return -1;
	}
	
	/* remove the newline */
	_s[strlen(_s)-1] = '\0';
	
	if ((match = pcre_compile(
		"^([0-9]+),([0-9]+)$", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
		
		return -1;
	} 
	
	if ((n = pcre_exec(match, NULL, _c, strlen(_c), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _c);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
#undef N	
	
	pcre_get_substring_list(_c, ovector, n, &list);
	
	c = strtol(list[1], NULL, 10);
	type = strtol(list[2], NULL, 10);
	
	Str2Int_setdata(data, _s, c, type);
	
	free(_s);
	free(_c);
	free(list);
	free(match);
	
	return 0;
}

void *Str2Int_copy(void *d) {
	data_StrInt *_data = d;
	
	data_StrInt *data = Str2Int_init();
	
	Str2Int_setdata(data, _data->string, _data->count, _data->type);
	
	return data;
}

int Str2Int_append(void *d, void *s) {
	data_StrInt *data = d;
	data_StrInt *src = s;
	
	data->count += src->count;
	
	return 0;
}

data_StrInt *Str2Int_init() {
	data_StrInt *data = malloc(sizeof(data_StrInt));
	
	/* functions */
	data->destructor	= Str2Int_destroy;
	data->write		= Str2Int_write;
	data->copy		= Str2Int_copy;
	data->append		= Str2Int_append;
	data->read		= Str2Int_read;
	
	data->string	= NULL;
	data->count	= 0;
	data->type	= 0;
	
	return data;
}

data_StrInt *createStr2Int(char *str, int count, int type) {
	data_StrInt *data = Str2Int_init();
	
	Str2Int_setdata(data, str, count, type);
	
	return data;
}

/* end of Str2Int */

/* begin of StrInt */
int StrInt_setdata(data_StrInt *data, const char *str, int count) {
	data->string	= malloc(strlen(str)+1);
	strcpy(data->string, str);
	data->count	= count;
	data->type	= 0;
	
	return 0;
}

data_StrInt *StrInt_init() {
	data_StrInt *data = malloc(sizeof(data_StrInt));
	
	/* functions */
	data->destructor	= Str2Int_destroy;
	data->write		= Str2Int_write;
	data->copy		= Str2Int_copy;
	data->append		= Str2Int_append;
	data->read		= Str2Int_read;
	
	data->string	= NULL;
	data->count	= 0;
	data->type	= 0;
	
	return data;
}

data_StrInt *createStrInt(char *str, int count) {
	data_StrInt *data = StrInt_init();
	
	StrInt_setdata(data, str, count);
	
	return data;
}

/* end of StrInt */

/* begin of Str3Int */

int Str3Int_write(gzFile *f, void *d) {
	data_Str3Int *data = d;
	
	gzwrite(f, data->string, strlen(data->string));
	gzprintf(f, "\n%d,%d,%d\n", 
		data->count,
		data->vcount,
		data->type);
	
	return 0;
}

int Str3Int_destroy(void *d) {
	data_Str3Int *data = d;
//printf("freed  : %s (%p)\n", data->string, data->string);
	if (data->string != NULL) free(data->string);
	if (data != NULL) free(data);
	
	return 0;
}


int Str3Int_setdata(data_Str3Int *data, const char *str, int count, int type, int vcount) {
	data->string	= malloc(strlen(str)+1);
	strcpy(data->string, str);
//printf("alloced: %s (%p)\n", data->string, data->string);
	data->count	= count;
	data->type	= type;
	data->vcount	= vcount;
	
	return 0;
}

int Str3Int_read(void *data, gzFile *f) {
	char *_s = NULL, *_c = NULL;
	int c, type, vcount;
	
	pcre *match;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	if ((_s = _getline(f)) == NULL) return -1;
	
	if (*_s == '\0') {
		free(_s);
		return -1;
	}
	if (mstate_is_section_end(_s)) {
		free(_s);
		return 0;
	}
	
	if ((_c = _getline(f)) == NULL) return -1;
	
	if (*_c == '\0') {
		free(_s);
		free(_c);
		return -1;
	}
	
	/* remove the newline */
	_s[strlen(_s)-1] = '\0';
	
	if ((match = pcre_compile(
		"^([0-9]+),([0-9]+),([0-9]+)$", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
		
		return -1;
	} 
	
	if ((n = pcre_exec(match, NULL, _c, strlen(_c), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _c);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
#undef N	
	
	pcre_get_substring_list(_c, ovector, n, &list);
	
	c = strtol(list[1], NULL, 10);
	type = strtol(list[2], NULL, 10);
	vcount = strtol(list[3], NULL, 10);
	
	Str3Int_setdata(data, _s, c, type, vcount);
	
	free(_s);
	free(_c);
	free(list);
	free(match);
	
	return 0;
}


void *Str3Int_copy(void *d) {
	data_Str3Int *_data = d;
	
	data_Str3Int *data = Str3Int_init();
	
	Str3Int_setdata(data, _data->string, _data->count, _data->type, _data->vcount);
	
	return data;
}

int Str3Int_append(void *d, void *s) {
	data_Str3Int *data = d;
	data_Str3Int *src = s;
	
	data->count += src->count;
	data->vcount += src->vcount;
	
	return 0;
}

data_Str3Int *Str3Int_init() {
	data_Str3Int *data = malloc(sizeof(data_Str3Int));
	
	/* functions */
	data->destructor	= Str3Int_destroy;
	data->write		= Str3Int_write;
	data->copy		= Str3Int_copy;
	data->append		= Str3Int_append;
	data->read		= Str3Int_read;
	
	data->string	= NULL;
	data->count	= 0;
	data->type	= 0;
	data->vcount	= 0;
	
	return data;
}

data_Str3Int *createStr3Int(char *str, int count, int type, int vcount) {
	data_Str3Int *data = Str3Int_init();
	
	Str3Int_setdata(data, str, count, type, vcount);
	
	return data;
}

/* end of Str3Int */

/* begin of Visit */
int Visit_write(gzFile *f, void *d) {
	data_Visit *data = d;

	gzwrite(f, data->string, strlen(data->string));
	gzwrite(f, "\n", strlen("\n"));
	gzwrite(f, data->lasturl, strlen(data->lasturl));
	gzwrite(f, "\n", strlen("\n"));
	gzwrite(f, data->useragent, strlen(data->useragent));
	
	gzprintf(f, "\n%d,%d,%d,%d\n", 
		data->count,
		data->timediff,
		data->timestamp,
		data->type);

	return 0;
}

int Visit_destroy(void *d) {
	data_Visit *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data->lasturl != NULL) free(data->lasturl);
	if (data->useragent != NULL) free(data->useragent);
	if (data != NULL) free(data);
	
	return 0;
}

int Visit_setdata(data_Visit *data, char *str, char *lasturl, char *useragent, int count, long timediff, time_t timestamp, int type) {
	data->string = malloc(strlen(str)+1);
	strcpy(data->string, str);
	
	data->lasturl = malloc(strlen(lasturl)+1);
	strcpy(data->lasturl, lasturl);
	
	if (useragent) {
		data->useragent = malloc(strlen(useragent)+1);
		strcpy(data->useragent, useragent);
	} else {
		data->useragent = malloc(strlen("-")+1);
		strcpy(data->useragent, "-");
	}
	
	data->timediff	= timediff;
	data->timestamp	= timestamp;
	data->count	= count;
	data->type	= type;
	
	return 0;
}

int Visit_read(void *data, gzFile *f) {
	char *_ls = NULL;
	char *_s = NULL, *_c = NULL, *_ua = NULL;
	int count, type, tdiff, tstamp;
	
	pcre *match;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	if ((_s = _getline(f)) == NULL) return -1;
	
	if (*_s == '\0') {
		free(_s);
		return -1;
	}
	if (mstate_is_section_end(_s)) {
		free(_s);
		return 0;
	}
	
	if ((_ls = _getline(f)) == NULL) return -1;
	
	if (*_ls == '\0') {
		free(_s);
		free(_ls);
		return -1;
	}
	
	if ((_ua = _getline(f)) == NULL) return -1;
	
	if (*_ua == '\0') {
		free(_s);
		free(_ls);
		free(_ua);
		return -1;
	}
	
	if ((_c = _getline(f)) == NULL) return -1;
	
	if (*_c == '\0') {
		free(_s);
		free(_ls);
		free(_ua);
		free(_c);
		return -1;
	}
	
	
	
	/* remove the newline */
	_s[strlen(_s)-1] = '\0';
	_ls[strlen(_ls)-1] = '\0';
	_ua[strlen(_ua)-1] = '\0';
	
	if ((match = pcre_compile(
		"^([0-9]+),([0-9]+),([0-9]+),([0-9]+)$", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
		return -1;
	} 
	
	if ((n = pcre_exec(match, NULL, _c, strlen(_c), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _c);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
#undef N	
	
	pcre_get_substring_list(_c, ovector, n, &list);
	
	count = strtol(list[1], NULL, 10);
	tdiff = strtol(list[2], NULL, 10);
	tstamp = strtol(list[3], NULL, 10);
	type = strtol(list[4], NULL, 10);
	
	Visit_setdata(data, _s, _ls, _ua, count, tdiff, tstamp, type);
	
	free(_s);
	free(_ls);
	free(_c);
	free(_ua);
	free(list);
	free(match);
	
	return 0;
}

int Visit_append(void *d, void *s) {
	data_Visit *data = d;
	data_Visit *src = s;
	
	if (!strcmp(src->string, data->string) && 
		!strcmp(src->useragent, data->useragent)) {
		
		if (data->timestamp > src->timestamp) {
			data->timestamp = src->timestamp;
		
			free(data->lasturl);
			data->lasturl = malloc(strlen(src->lasturl)+1);
			strcpy(data->lasturl, src->lasturl);
		}
		
		data->count += src->count;
		
		return M_DATA_APPENDED;
	} else {
		fprintf(stderr, "%s.%d: append skipped: same host, but useragent was different\n", __FILE__, __LINE__);
		return M_DATA_NOT_APPENDED;
	}
}

data_Visit *Visit_init() {
	data_Visit *data = malloc(sizeof(data_Visit));
	
	/* functions */
	data->destructor	= Visit_destroy;
	data->write		= Visit_write;
	data->copy		= NULL;
	data->append		= Visit_append;
	data->read		= Visit_read;
	
	data->string	= NULL;
	data->count	= 0;
	data->type	= 0;
	data->timediff	= 0;
	data->timestamp	= 0;
	data->lasturl	= NULL;
	data->useragent = NULL;
	
	return data;
}

data_Visit *createVisit(char *str, char *lasturl, char *useragent, int count, long timediff, time_t timestamp, int type) {
	data_Visit *data = Visit_init();
	
	Visit_setdata(data, str, lasturl, useragent, count, timediff, timestamp, type);
	
	return data;
}

/* end of Visit */

/* begin of History */

int History_write(gzFile *f, void *d) {
	data_History *data = d;
	
	gzwrite(f, data->string, strlen(data->string));
	gzprintf(f, "\n%d,%d,%d,%ld,%ld,%ld,%ld,%ld,%.0f\n", 
		data->year,
		data->month,
		data->count,
		data->pages,
		data->files,
		data->hits,
		data->visits,
		data->hosts,
		data->xfersize);
	
	return 0;
}

int History_destroy(void *d) {
	data_History *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data != NULL) free(data);
	
	return 0;
}

int History_setdata(data_History *data, const char *str, int count,
	int year, int month, int pages, int hits, int files,
	int visits, int hosts, double xfersize) {
	
	data->string = malloc(strlen(str)+1);
	strcpy(data->string, str);
	
	data->count	= count;
	
	data->month	= month;
	data->year	= year;
	
	data->pages	= pages;
	data->hits	= hits;
	data->files	= files;
	data->visits	= visits;
	data->hosts	= hosts;
	data->xfersize	= xfersize;
	
	return 0;
}

int History_read(void *data, gzFile *f) {
	char *_str = NULL, *_year = NULL;
	int year, month, pages, count, files, hits, visits, hosts;
	double xfersize;
	
	pcre *match;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	if ((_str = _getline(f)) == NULL) return -1;
	
	if (*_str == '\0') {
		free(_str);
		return -1;
	}
	
	if (*_str == '#') {
		free(_str);
		return 0;
	}
	
	if ((_year = _getline(f)) == NULL) return -1;
	
	/* remove the newline */
	_str[strlen(_str)-1] = '\0';
	
	if ((match = pcre_compile(
		"^([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+)$", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
		return -1;
	} 
	
	if ((n = pcre_exec(match, NULL, _year, strlen(_year), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _year);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
#undef N	
	
	pcre_get_substring_list(_year, ovector, n, &list);
	
	year	= strtol(list[1], NULL, 10);
	month	= strtol(list[2], NULL, 10);
	count	= strtol(list[3], NULL, 10);
	pages	= strtol(list[4], NULL, 10);
	files	= strtol(list[5], NULL, 10);
	hits	= strtol(list[6], NULL, 10);
	visits	= strtol(list[7], NULL, 10);
	hosts	= strtol(list[8], NULL, 10);
	xfersize = strtod(list[9], NULL);
	
	History_setdata(data, _str, count,
		year, month, pages, hits, files,
		visits, hosts, xfersize);
	
	free(_str);
	free(_year);
	free(list);
	free(match);
	
	return 0;
}

int History_append(void *d, void *s) {
	data_History *data = d;
	data_History *src = s;
	
	data->count	= src->count;
	
	data->month	= src->month;
	data->year	= src->year;
	
	data->pages	= src->pages;
	data->hits	= src->hits;
	data->files	= src->files;
	data->visits	= src->visits;
	data->hosts	= src->hosts;
	data->xfersize	= src->xfersize;
	
	return 0;
}

data_History *History_init() {
	data_History *data = malloc(sizeof(data_History));
	
	/* functions */
	data->destructor	= History_destroy;
	data->write		= History_write;
	data->read		= History_read;
	data->copy		= NULL;
	data->append		= History_append;
	
	data->string	= NULL;
	
	data->count	= 0;
	
	data->month	= 0;
	data->year	= 0;
	
	data->pages	= 0;
	data->hits	= 0;
	data->files	= 0;
	data->visits	= 0;
	data->hosts	= 0;
	data->xfersize	= 0;
	
	return data;
}

data_History *createHistory(mstate *state) {
	data_History *data = History_init();
	char buf[7];
	long i, pages, hits, files, visits, hosts, last_day = 0;
	double xfersize;
	struct tm *tm;
	mstate_web *staweb;
	
	tm = localtime(&(state->timestamp));
	
	sprintf(buf, "%04i%02i", state->year, state->month);
	
	pages	= 0;
	hits	= 0;
	files	= 0;
	visits	= 0;
	hosts	= 0;
	xfersize = 0;
	
	if (state->ext && state->ext_type == M_STATE_TYPE_WEB) {
		staweb = state->ext;
		
		for ( i = 0; i < 31; i++) {
			files		+= staweb->days[i].files;
			xfersize	+= staweb->days[i].xfersize;
			hits		+= staweb->days[i].hits;
			hosts		+= staweb->days[i].hosts;
			pages		+= staweb->days[i].pages;
			visits		+= staweb->days[i].visits;
			if (staweb->days[i].hits) last_day = i+1;
		}
	}
	
	History_setdata(data, buf, last_day, 
		state->year, state->month, 
		pages, hits, files,
		visits, hosts, xfersize);
	
	return data;
}

/* end of History */


/* begin of BrokenLink */

int BrokenLink_write(gzFile *f, void *d) {
	data_BrokenLink *data = d;
	
	gzwrite(f, data->string, strlen(data->string));
	gzwrite(f, "\n", strlen("\n"));
	gzwrite(f, data->referrer, strlen(data->referrer));
	gzprintf(f, "\n%d,%d,%ld\n", 
		data->count,
		data->type,
		data->timestamp);
	
	return 0;
}

int BrokenLink_destroy(void *d) {
	data_BrokenLink *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data->referrer != NULL) free(data->referrer);
	if (data != NULL) free(data);
	
	return 0;
}

int BrokenLink_setdata(data_BrokenLink *data, char *str, int count, 
	int type, time_t timestamp, char *referrer) {
	
	data->string = malloc(strlen(str)+1);
	strcpy(data->string, str);
	
	if (referrer) {
		data->referrer = malloc(strlen(referrer)+1);
		strcpy(data->referrer, referrer);
	} else {
		data->referrer = malloc(strlen("-")+1);
		strcpy(data->referrer, "-");
	}
	
	data->count	= count;
	data->type	= type;
	data->timestamp	= timestamp;
	
	return 0;
}

int BrokenLink_read(void *data, gzFile *f) {
	char *_s, *_ls, *_c;
	int count, type, tstamp;
	
	pcre *match;
	const char *errptr;
	int erroffset = 0;
#define N 20 + 1
	int ovector[3 * N], n;
	const char **list;
	
	if ((_s = _getline(f)) == NULL) return -1;
	
	if (*_s == '\0') {
		free(_s);
		return -1;
	}
	if (mstate_is_section_end(_s)) {
		free(_s);
		return 0;
	}
	
	if ((_ls = _getline(f)) == NULL) return -1;
	
	if (*_ls == '\0') {
		free(_ls);
		free(_s);
		return -1;
	}
	
	if ((_c = _getline(f)) == NULL) return -1;
	
	if (*_c == '\0') {
		free(_s);
		free(_ls);
		free(_c);
		return -1;
	}
	
	/* remove the newline */
	_s[strlen(_s)-1] = '\0';
	_ls[strlen(_ls)-1] = '\0';
	
	if ((match = pcre_compile(
		"^([0-9]+),([0-9]+),([0-9]+)$", 
		0, &errptr, &erroffset, NULL)) == NULL) {
		
		fprintf(stderr, "%s.%d: rexexp compilation error at %s\n", __FILE__, __LINE__, errptr);
		
		
		return -1;
	} 
	
	if ((n = pcre_exec(match, NULL, _c, strlen(_c), 0, 0, ovector, 3 * N)) < 0) {
		if (n == PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: string doesn't match: %s\n", __FILE__, __LINE__, _c);
		} else {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return -1;
	}
#undef N	
	
	pcre_get_substring_list(_c, ovector, n, &list);
	
	count = strtol(list[1], NULL, 10);
	type = strtol(list[2], NULL, 10);
	tstamp = strtol(list[3], NULL, 10);
	
	BrokenLink_setdata(data, _s, count, type, tstamp, _ls);
	
	free(_s);
	free(_ls);
	free(_c);
	free(list);
	free(match);
	
	return 0;
}

int BrokenLink_append(void *d, void *s) {
	data_BrokenLink *data = d;
	data_BrokenLink *src = s;
	
	if (data->referrer != NULL) free(data->referrer);
	data->referrer = malloc(strlen(src->referrer)+1);
	strcpy(data->referrer, src->referrer);
	
	data->timestamp	= src->timestamp;
	data->count	+= src->count;
	
	return 0;
}

void *BrokenLink_copy(void *d) {
	data_BrokenLink *data = BrokenLink_init();
	data_BrokenLink *_data = d;
	
	BrokenLink_setdata(data, _data->string, _data->count, _data->type, _data->timestamp, _data->referrer);
	
	
	return data;
}

data_BrokenLink *BrokenLink_init() {
	data_BrokenLink *data = malloc(sizeof(data_BrokenLink));
	
	/* functions */
	data->destructor	= BrokenLink_destroy;
	data->write		= BrokenLink_write;
	data->read		= BrokenLink_read;
	data->copy		= BrokenLink_copy;
	data->append		= BrokenLink_append;
	
	data->string	= NULL;
	data->referrer	= NULL;
	
	data->count	= 0;
	data->type	= 0;
	data->timestamp	= 0;
	
	return data;
}



data_BrokenLink	*createBrokenLink(char *str, int count, int type, time_t timestamp, char *referrer) {
	data_BrokenLink *data = BrokenLink_init();
	
	BrokenLink_setdata(data, str, count, type, timestamp, referrer);
	
	return data;
}

/* end of BrokenLink */


/* begin of State */

int State_write(gzFile *f, void *d) {
	return 0;
}

int State_destroy(void *d) {
	data_State *data = d;
	
	if (data->string != NULL)	free(data->string);
	if (data->state != NULL)	mstate_free(data->state);
	if (data->history != NULL)	mlist_free(data->history);
	if (data != NULL)	free(data);
	
	return 0;
}

int State_setdata(data_State *data, char *str, mstate *state, mlist *hist) {
	data->string = malloc(strlen(str)+1);
	strcpy(data->string, str);
	
	data->state = state ? state : mstate_init();
	data->history = hist ? hist : mlist_init();
	
	data->count	= 0;
	data->type	= 0;
	
	return 0;
}

int State_read(void *data, gzFile *f) {
	return 0;
}

int State_append(void *d, void *s) {
	return 0;
}

void *State_copy(void *d) {
	return NULL;
}

data_State *State_init() {
	data_State *data = malloc(sizeof(data_State));
	
	/* functions */
	data->destructor	= State_destroy;
	data->write		= State_write;
	data->read		= State_read;
	data->copy		= State_copy;
	data->append		= State_append;
	
	data->string	= NULL;
	data->state	= NULL;
	data->history	= NULL;
	
	data->count	= 0;
	data->type	= 0;
	
	return data;
}

data_State	*createState(char *str, mstate *state, mlist *hist) {
	data_State *data = State_init();
	
	if (State_setdata(data, str, state, hist)) {
		data->destructor(data);
		data = NULL;
	}
	
	return data;
}

/* end of State */

/* begin of Match */

int Match_write(gzFile *f, void *d) {
	return 0;
}

int Match_destroy(void *d) {
	data_Match *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data->match != NULL) free(data->match);
	if (data != NULL) free(data);
	
	return 0;
}

int Match_setdata(data_Match *data, char *match, char *string) {
	const char *errstr;
	int errofs;
	
	data->string = malloc(strlen(string)+1);
	strcpy(data->string, string);
	
	data->match	= pcre_compile(match, 0, &errstr, &errofs, NULL);
	
	data->count	= 0;
	data->type	= 0;
	
	if (data->match == NULL) {
		fprintf(stderr, "%s.%d: regex compilation error: %s\n", __FILE__, __LINE__, errstr);
		return -1;
	}
	
	return 0;
}

int Match_read(void *data, gzFile *f) {
	return 0;
}

int Match_append(void *d, void *s) {
	return 0;
}

void *Match_copy(void *d) {
	return NULL;
}

data_Match *Match_init() {
	data_Match *data = malloc(sizeof(data_Match));
	
	/* functions */
	data->destructor	= Match_destroy;
	data->write		= Match_write;
	data->read		= Match_read;
	data->copy		= Match_copy;
	data->append		= Match_append;
	
	data->string	= NULL;
	data->match	= NULL;
	
	data->count	= 0;
	data->type	= 0;
	
	return data;
}



data_Match *createMatch(char *match, char *string) {
	data_Match *data = Match_init();
	
	if (Match_setdata(data, match, string)) {
		data->destructor(data);
		data = NULL;
	}
	
	return data;
}

/* end of Match */

/* begin of Query */
#ifdef HAVE_LIBADNS
int Query_write(gzFile *f, void *d) {
	return 0;
}

int Query_destroy(void *d) {
	data_Query *data = d;
	
	if (data->string != NULL) free(data->string);
	if (data->query != NULL) free(data->query);
	if (data->resolved_ip != NULL) free(data->resolved_ip);
	if (data != NULL) free(data);
	
	return 0;
}

int Query_setdata(data_Query *data, char *string, adns_query *query) {

	data->string = malloc(strlen(string)+1);
	strcpy(data->string, string);
	
	data->count	= 0;
	data->type	= 0;
	
	data->query	= query;
	
	return 0;
}

int Query_read(void *data, gzFile *f) {
	return 0;
}

int Query_append(void *d, void *s) {
	return 0;
}

void *Query_copy(void *d) {
	return NULL;
}

data_Query *Query_init() {
	data_Query *data = malloc(sizeof(data_Query));
	
	/* functions */
	data->destructor	= Query_destroy;
	data->write		= Query_write;
	data->read		= Query_read;
	data->copy		= Query_copy;
	data->append		= Query_append;
	
	data->string	= NULL;
	data->query	= NULL;
	data->resolved_ip = NULL;
	
	data->count	= 0;
	data->type	= 0;
	
	return data;
}



data_Query *createQuery(char *ip, adns_query * query) {
	data_Query *data = Query_init();
	
	if (Query_setdata(data, ip, query)) {
		data->destructor(data);
		data = NULL;
	}
	
	return data;
}
#endif
/* end of Query */