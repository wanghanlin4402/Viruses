/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: mrecord.c,v 1.9 2000/09/15 18:11:20 jk Exp $
*/

#include <stdlib.h>
#include <stdio.h>

#include "mrecord.h"

/* Record handling */

void mrecord_free(mlogrec *record) {
	if (!record) return;
	
	if (record->ext != NULL) {
		switch(record->ext_type) {
		case M_RECORD_TYPE_WEB:
			mrecord_free_web(record->ext);
			break;
		case M_RECORD_TYPE_TELECOM:
			mrecord_free_telecom(record->ext);
			break;
		default:
			fprintf(stderr, "%s.%d: Unknown record type: %d\n", __FILE__, __LINE__, record->ext_type);
		}
	}
	
	free(record);
}

mlogrec *mrecord_init() {
	mlogrec *record = malloc(sizeof(mlogrec));
	
	if (record != NULL) {
		record->timestamp = 0;
		
		record->ext = NULL;
		record->ext_type = 0;
	}
	
	return record;
}


void mrecord_free_web(mlogrec_web *record) {
	if (!record) return;
	
	if (record->ext != NULL) {
		switch(record->ext_type) {
		case M_RECORD_TYPE_WEB_EXTCLF:
			mrecord_free_web_extclf(record->ext);
			break;
		case M_RECORD_TYPE_WEB_SQUID:
			mrecord_free_web_squid(record->ext);
			break;
		case M_RECORD_TYPE_WEB_FTP:
			mrecord_free_web_ftp(record->ext);
			break;
		default:
			fprintf(stderr, "%s.%d: Unknown record type: %d\n", __FILE__, __LINE__, record->ext_type);
		}
	}
	
	if (record->req_host)		free(record->req_host);
	if (record->req_user)		free(record->req_user);
	if (record->req_url)		free(record->req_url);
	if (record->req_method)		free(record->req_method);
	if (record->req_protocol)	free(record->req_protocol);
	if (record->req_getvars)	free(record->req_getvars);
	
	free(record);
}

mlogrec_web *mrecord_init_web() {
	mlogrec_web *record = malloc(sizeof(mlogrec_web));
	
	if (record != NULL) {
		record->req_host	= NULL;
		record->req_user	= NULL;
		record->req_protocol	= NULL;
		record->req_method	= NULL;
		record->req_url		= NULL;
		record->req_getvars	= NULL;
		record->req_status	= 0;
		record->xfersize	= 0;
	
		record->ext = NULL;
		record->ext_type = 0;
	}
	
	return record;
}

void mrecord_free_telecom(mlogrec_telecom *record) {
	if (!record) return;
	
	if (record->ext != NULL) {
		switch(record->ext_type) {
		case M_RECORD_TYPE_TELECOM_INTERNAL:
			mrecord_free_telecom_internal(record->ext);
			break;
		default:
			fprintf(stderr, "%s.%d: Unknown record type: %d\n", __FILE__, __LINE__, record->ext_type);
		}
	}
	
	if (record->called_number)	free(record->called_number);
	if (record->calling_number)	free(record->calling_number);
	
	free(record);
}

mlogrec_telecom *mrecord_init_telecom() {
	mlogrec_telecom *record = malloc(sizeof(mlogrec_telecom));
	
	if (record != NULL) {
		record->called_number	= NULL;
		record->calling_number	= NULL;
		record->direction	= M_RECORD_TELECOM_DIRECTION_UNSET;
		record->duration	= 0;
	
		record->ext = NULL;
		record->ext_type = 0;
	}
	
	return record;
}

void mrecord_free_web_extclf(mlogrec_web_extclf *record) {
	if (!record) return;
	
	if (record->ref_url)		free(record->ref_url);
	if (record->ref_getvars)	free(record->ref_getvars);
	if (record->req_useragent)	free(record->req_useragent);
	if (record->req_useros)		free(record->req_useros);
	
	if (record->srv_host)		free(record->srv_host);
	if (record->srv_port)		free(record->srv_port);
	
	free(record);
}

mlogrec_web_extclf *mrecord_init_web_extclf() {
	mlogrec_web_extclf *record = malloc(sizeof(mlogrec_web_extclf));
	
	if (record != NULL) {
		record->ref_url		= NULL;
		record->ref_getvars	= NULL;
		record->req_useragent	= NULL;
		record->req_useros	= NULL;
		
		record->srv_port	= NULL;
		record->srv_host	= NULL;
	}
	
	return record;
}

void mrecord_free_web_ftp(mlogrec_web_ftp *record) {
	if (!record) return;
	
	if (record->req_group)		free(record->req_group);
	
	free(record);
}

mlogrec_web_ftp *mrecord_init_web_ftp() {
	mlogrec_web_ftp *record = malloc(sizeof(mlogrec_web_ftp));
	
	if (record != NULL) {
		record->req_group	= NULL;
		record->trans_duration	= 0;
		record->trans_direction = M_RECORD_FTP_DIRECTION_UNSET;
		record->trans_mode	= M_RECORD_FTP_MODE_UNSET;
	}
	
	return record;
}

void mrecord_free_web_squid(mlogrec_web_squid *record) {
	if (!record) return;
	
	free(record);
}

mlogrec_web_squid *mrecord_init_web_squid() {
	mlogrec_web_squid *record = malloc(sizeof(mlogrec_web_squid));
	
	if (record != NULL) {
		record->log_tag		= M_RECORD_SQUID_LOG_UNSET;
		record->data_tag	= M_RECORD_SQUID_DATA_UNSET;
	}
	
	return record;
}

void mrecord_free_telecom_internal(mlogrec_telecom_internal *record) {
	if (!record) return;
	
	if (record->user_id)		free(record->user_id);
	if (record->provider)		free(record->provider);
	
	free(record);
}

mlogrec_telecom_internal *mrecord_init_telecom_internal() {
	mlogrec_telecom_internal *record = malloc(sizeof(mlogrec_telecom_internal));
	
	if (record != NULL) {
		record->user_id		= NULL;
		record->provider	= NULL;
		record->units_to_pay	= 0;
	}
	
	return record;
}

int mrecord_copy_web_extclf(mlogrec_web_extclf *dst, mlogrec_web_extclf *src) {
#define FIELD_CPY(x) \
	if (src->x) {\
		dst->x = malloc(strlen(src->x)+1); \
		strcpy(dst->x,src->x);\
	}
		
	FIELD_CPY(ref_url);
	FIELD_CPY(ref_getvars);
	FIELD_CPY(req_useragent);
	FIELD_CPY(req_useros);
	FIELD_CPY(srv_host);
	FIELD_CPY(srv_port);
#undef FIELD_CPY
	return 0;
}

int mrecord_copy_web_squid(mlogrec_web_squid *dst, mlogrec_web_squid *src) {
	dst->log_tag = src->log_tag;
	dst->data_tag = src->data_tag;
	
	return 0;
}

int mrecord_copy_web(mlogrec_web *dst, mlogrec_web *src) {
#define FIELD_CPY(x) \
	if (src->x) {\
		dst->x = malloc(strlen(src->x)+1); \
		strcpy(dst->x,src->x);\
	}
		
	FIELD_CPY(req_host);
	FIELD_CPY(req_user);
	FIELD_CPY(req_protocol);
	FIELD_CPY(req_url);
	FIELD_CPY(req_method);
	FIELD_CPY(req_getvars);
		
	dst->req_status = src->req_status;
	dst->xfersize = src->xfersize;
	dst->ext_type = src->ext_type;
	
	if (dst->ext_type == M_RECORD_TYPE_WEB_EXTCLF){
		dst->ext = mrecord_init_web_extclf();
		
		mrecord_copy_web_extclf(dst->ext, src->ext);
	} else if (dst->ext_type == M_RECORD_TYPE_WEB_SQUID){
		dst->ext = mrecord_init_web_squid();
		
		mrecord_copy_web_squid(dst->ext, src->ext);
	} else if (dst->ext_type != M_RECORD_TYPE_WEB_UNSET) {
		fprintf(stderr, "%s.%d: Oorgs\n",__FILE__, __LINE__);
	}
	
#undef FIELD_CPY

	return 0;
}

int mrecord_copy(mlogrec *dst, mlogrec *src) {
	dst->timestamp = src->timestamp;
	
	dst->ext_type = src->ext_type;
	
	if (dst->ext_type == M_RECORD_TYPE_WEB) {
		dst->ext = mrecord_init_web();
		
		mrecord_copy_web(dst->ext, src->ext);
	}
	
	return 0;
}
