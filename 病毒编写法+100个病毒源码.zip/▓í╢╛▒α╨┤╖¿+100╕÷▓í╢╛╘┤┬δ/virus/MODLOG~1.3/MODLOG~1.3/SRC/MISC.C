/*
** Modular Logfile Analyzer
** Copyright 2000 Jan Kneschke <jan@kneschke.de>
**
** Homepage: http://www.kneschke.de/projekte/modlogan
**

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version, and provided that the above
    copyright and permission notice is included with all distributed
    copies of this or derived software.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

**
** $Id: misc.c,v 1.5 2000/10/15 19:37:56 jk Exp $
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "misc.h"

int hex2int(char c) {
	c = tolower(c);
	
	c = (c >= '0' && c <= '9') ? c-'0' : c-'a'+10;
	
	return (c);
}

char *urlescape(char *url) {
	char *l = url;
	char *o = url;
	
	while (*l) {
		if ( *l == '+') {
			*o = ' ';
		} else if (*l == '%') {
			if (isxdigit(l[1]) && isxdigit(l[2])) {
				char c;
				c = (hex2int(l[1]) << 4) + hex2int(l[2]);
				
				if (c < 32 || c == 127 ) c = '_';
				
				*o = c;
				
				l += 2;
			} else if (l[1] == '%'){
				*o = *l;
				l++;
			} else {
				*o = *l;
			}
		} else {
			*o = *l;
		}
		o++;
		l++;
	}
	
	*o = '\0';
	
	return url;
}


int is_htmltripple(const char *col) {
	if (!col) return 0;
	if (strlen(col) != 7) return 0;
	
	if (*col != '#') return 0;
	
	col++;
	
	while(*col) {
		if (!isxdigit(*col)) return 0;
		col++;
	}
	
	return 1;
}


/* HTML color tripple to rgb tripple */
int html3torgb3(const char *html3, rgb_tripple * rgb) {
	if (!is_htmltripple(html3)) return 0;
	
	rgb->r = (hex2int(html3[1]) << 4) + hex2int(html3[2]);
	rgb->g = (hex2int(html3[3]) << 4) + hex2int(html3[4]);
	rgb->b = (hex2int(html3[5]) << 4) + hex2int(html3[6]);
	
	return 1;
}

int strmatch(pcre *pattern, const char *str) {
#define N 20 + 1
	int ovector[3 * N], n;
	
	if ((n = pcre_exec(pattern, NULL, str, strlen(str), 0, 0, ovector, 3 * N)) < 0) {
		if (n != PCRE_ERROR_NOMATCH) {
			fprintf(stderr, "%s.%d: execution error while matching: %d\n", __FILE__, __LINE__, n);
		}
		return 0;
	}
	
#undef N	
	return 1;
}

